--
-- Table structure for table `#__bsms_admin`
--

DROP TABLE IF EXISTS `#__bsms_admin`;
CREATE TABLE `#__bsms_admin` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `drop_tables` int DEFAULT '0',
  `params` text COLLATE utf8mb4_unicode_ci,
  `asset_id` int unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `access` int unsigned NOT NULL DEFAULT '0',
  `installstate` text COLLATE utf8mb4_unicode_ci,
  `debug` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_access` (`access`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


--
-- Dumping data for table `#__bsms_admin`
--

INSERT INTO `#__bsms_admin` SET `id`='1',`drop_tables`='0',`params`='{\"simple_mode\":\"0\",\"simple_mode_template\":\"simple_mode1\",\"simplegridtextoverlay\":\"1\",\"simple_mode_display\":\"1\",\"metakey\":\"\",\"metadesc\":\"\",\"compat_mode\":\"0\",\"studylistlimit\":\"10\",\"show_location_media\":\"0\",\"popular_limit\":\"\",\"character_filter\":\"1\",\"format_popular\":\"0\",\"main_image_icon_or_image\":\"0\",\"default_main_image\":\"\",\"default_series_image\":\"\",\"default_teacher_image\":\"\",\"download_show\":\"0\",\"download_use_button_icon\":\"\",\"download_button_text\":\"Audio\",\"download_button_type\":\"\",\"download_button_color\":\"\",\"download_icon_type\":\"fas fa-download\",\"download_custom_icon\":\"\",\"download_icon_text_size\":\"24\",\"default_download_image\":\"\",\"default_showHide_image\":\"\",\"thumbnail_teacher_size\":\"150\",\"thumbnail_series_size\":\"150\",\"thumbnail_study_size\":\"150\",\"location_id\":\"-1\",\"teacher_id\":\"1\",\"series_id\":\"-1\",\"booknumber\":\"-1\",\"messagetype\":\"-1\",\"default_study_image\":\"\",\"download\":\"1\",\"target\":\" \",\"server\":\"1\",\"podcast\":[\"-1\"],\"from\":\"x\",\"to\":\"x\",\"pFrom\":\"x\",\"pTo\":\"x\",\"mtFrom\":\"x\",\"mtTo\":\"x\",\"uploadpath\":\"\\/images\\/biblestudy\\/media\\/\",\"controls\":\"1\",\"jwplayer_pro\":\"0\",\"jwplayer_key\":\"\",\"jwplayer_cdn\":\"\",\"jwplayer_image\":\"\",\"jwplayer_skin\":\"\",\"jwplayer_autostart\":\"false\",\"jwplayer_playerresponsive\":\"true\",\"jwplayer_fallback\":\"true\",\"jwplayer_mute\":\"false\",\"jwplayer_stagevideo\":\"false\",\"jwplayer_primary\":\"html5\",\"playlist\":\"false\",\"jwplayer_listbar\":\"false\",\"jwplayer_logo\":\"\",\"sharing\":\"false\",\"jwplayer_related\":\"false\",\"jwplayer_advertising\":\"\",\"rtmp\":\"Comming Soon\",\"ga\":\"Comming Soon\",\"jwplayer_sitecatalyst\":\"Comming Soon\",\"captions\":\"false\",\"media_image\":\"\"}',`asset_id`='103',`access`='1',`installstate`=NULL,`debug`='0';

-- --------------------------------------------------------

--
-- Table structure for table `#__bsms_books`
--

DROP TABLE IF EXISTS `#__bsms_books`;
CREATE TABLE `#__bsms_books` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `bookname` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `booknumber` int DEFAULT NULL,
  `published` tinyint NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_state` (`published`)
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


--
-- Dumping data for table `#__bsms_books`
--

INSERT INTO `#__bsms_books` SET `id`='1',`bookname`='JBS_BBK_GENESIS',`booknumber`='101',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='2',`bookname`='JBS_BBK_EXODUS',`booknumber`='102',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='3',`bookname`='JBS_BBK_LEVITICUS',`booknumber`='103',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='4',`bookname`='JBS_BBK_NUMBERS',`booknumber`='104',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='5',`bookname`='JBS_BBK_DEUTERONOMY',`booknumber`='105',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='6',`bookname`='JBS_BBK_JOSHUA',`booknumber`='106',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='7',`bookname`='JBS_BBK_JUDGES',`booknumber`='107',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='8',`bookname`='JBS_BBK_RUTH',`booknumber`='108',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='9',`bookname`='JBS_BBK_1SAMUEL',`booknumber`='109',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='10',`bookname`='JBS_BBK_2SAMUEL',`booknumber`='110',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='11',`bookname`='JBS_BBK_1KINGS',`booknumber`='111',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='12',`bookname`='JBS_BBK_2KINGS',`booknumber`='112',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='13',`bookname`='JBS_BBK_1CHRONICLES',`booknumber`='113',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='14',`bookname`='JBS_BBK_2CHRONICLES',`booknumber`='114',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='15',`bookname`='JBS_BBK_EZRA',`booknumber`='115',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='16',`bookname`='JBS_BBK_NEHEMIAH',`booknumber`='116',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='17',`bookname`='JBS_BBK_ESTHER',`booknumber`='117',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='18',`bookname`='JBS_BBK_JOB',`booknumber`='118',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='19',`bookname`='JBS_BBK_PSALM',`booknumber`='119',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='20',`bookname`='JBS_BBK_PROVERBS',`booknumber`='120',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='21',`bookname`='JBS_BBK_ECCLESIASTES',`booknumber`='121',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='22',`bookname`='JBS_BBK_SONG_OF_SOLOMON',`booknumber`='122',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='23',`bookname`='JBS_BBK_ISAIAH',`booknumber`='123',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='24',`bookname`='JBS_BBK_JEREMIAH',`booknumber`='124',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='25',`bookname`='JBS_BBK_LAMENTATIONS',`booknumber`='125',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='26',`bookname`='JBS_BBK_EZEKIEL',`booknumber`='126',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='27',`bookname`='JBS_BBK_DANIEL',`booknumber`='127',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='28',`bookname`='JBS_BBK_HOSEA',`booknumber`='128',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='29',`bookname`='JBS_BBK_JOEL',`booknumber`='129',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='30',`bookname`='JBS_BBK_AMOS',`booknumber`='130',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='31',`bookname`='JBS_BBK_OBADIAH',`booknumber`='131',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='32',`bookname`='JBS_BBK_JONAH',`booknumber`='132',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='33',`bookname`='JBS_BBK_MICAH',`booknumber`='133',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='34',`bookname`='JBS_BBK_NAHUM',`booknumber`='134',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='35',`bookname`='JBS_BBK_HABAKKUK',`booknumber`='135',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='36',`bookname`='JBS_BBK_ZEPHANIAH',`booknumber`='136',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='37',`bookname`='JBS_BBK_HAGGAI',`booknumber`='137',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='38',`bookname`='JBS_BBK_ZECHARIAH',`booknumber`='138',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='39',`bookname`='JBS_BBK_MALACHI',`booknumber`='139',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='40',`bookname`='JBS_BBK_MATTHEW',`booknumber`='140',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='41',`bookname`='JBS_BBK_MARK',`booknumber`='141',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='42',`bookname`='JBS_BBK_LUKE',`booknumber`='142',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='43',`bookname`='JBS_BBK_JOHN',`booknumber`='143',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='44',`bookname`='JBS_BBK_ACTS',`booknumber`='144',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='45',`bookname`='JBS_BBK_ROMANS',`booknumber`='145',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='46',`bookname`='JBS_BBK_1CORINTHIANS',`booknumber`='146',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='47',`bookname`='JBS_BBK_2CORINTHIANS',`booknumber`='147',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='48',`bookname`='JBS_BBK_GALATIANS',`booknumber`='148',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='49',`bookname`='JBS_BBK_EPHESIANS',`booknumber`='149',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='50',`bookname`='JBS_BBK_PHILIPPIANS',`booknumber`='150',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='51',`bookname`='JBS_BBK_COLOSSIANS',`booknumber`='151',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='52',`bookname`='JBS_BBK_1THESSALONIANS',`booknumber`='152',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='53',`bookname`='JBS_BBK_2THESSALONIANS',`booknumber`='153',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='54',`bookname`='JBS_BBK_1TIMOTHY',`booknumber`='154',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='55',`bookname`='JBS_BBK_2TIMOTHY',`booknumber`='155',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='56',`bookname`='JBS_BBK_TITUS',`booknumber`='156',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='57',`bookname`='JBS_BBK_PHILEMON',`booknumber`='157',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='58',`bookname`='JBS_BBK_HEBREWS',`booknumber`='158',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='59',`bookname`='JBS_BBK_JAMES',`booknumber`='159',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='60',`bookname`='JBS_BBK_1PETER',`booknumber`='160',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='61',`bookname`='JBS_BBK_2PETER',`booknumber`='161',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='62',`bookname`='JBS_BBK_1JOHN',`booknumber`='162',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='63',`bookname`='JBS_BBK_2JOHN',`booknumber`='163',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='64',`bookname`='JBS_BBK_3JOHN',`booknumber`='164',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='65',`bookname`='JBS_BBK_JUDE',`booknumber`='165',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='66',`bookname`='JBS_BBK_REVELATION',`booknumber`='166',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='67',`bookname`='JBS_BBK_TOBIT',`booknumber`='167',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='68',`bookname`='JBS_BBK_JUDITH',`booknumber`='168',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='69',`bookname`='JBS_BBK_1MACCABEES',`booknumber`='169',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='70',`bookname`='JBS_BBK_2MACCABEES',`booknumber`='170',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='71',`bookname`='JBS_BBK_WISDOM',`booknumber`='171',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='72',`bookname`='JBS_BBK_SIRACH',`booknumber`='172',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='73',`bookname`='JBS_BBK_BARUCH',`booknumber`='173',`published`='1';

-- --------------------------------------------------------

--
-- Table structure for table `#__bsms_comments`
--

DROP TABLE IF EXISTS `#__bsms_comments`;
CREATE TABLE `#__bsms_comments` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `published` tinyint NOT NULL DEFAULT '0',
  `study_id` int NOT NULL DEFAULT '0',
  `user_id` int NOT NULL DEFAULT '0',
  `full_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_text` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `asset_id` int unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `access` int unsigned NOT NULL DEFAULT '0',
  `language` char(7) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The language code for the Comments.',
  PRIMARY KEY (`id`),
  KEY `idx_state` (`published`),
  KEY `idx_access` (`access`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


--
-- Dumping data for table `#__bsms_comments`
--


-- --------------------------------------------------------

--
-- Table structure for table `#__bsms_locations`
--

DROP TABLE IF EXISTS `#__bsms_locations`;
CREATE TABLE `#__bsms_locations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `location_text` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_id` int unsigned NOT NULL DEFAULT '0' COMMENT 'Used to link to com_contact',
  `address` text COLLATE utf8mb4_unicode_ci,
  `suburb` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postcode` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telephone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fax` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `misc` mediumtext COLLATE utf8mb4_unicode_ci,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_to` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `default_con` tinyint unsigned NOT NULL DEFAULT '0',
  `checked_out` int unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `params` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int NOT NULL DEFAULT '0',
  `mobile` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `webpage` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `sortname1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sortname2` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sortname3` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `language` char(7) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int unsigned NOT NULL DEFAULT '0',
  `metakey` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `metadesc` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `metadata` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `featured` tinyint unsigned NOT NULL DEFAULT '0' COMMENT 'Set if article is featured.',
  `xreference` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  `version` int unsigned NOT NULL DEFAULT '1',
  `hits` int unsigned NOT NULL DEFAULT '0',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published` tinyint NOT NULL DEFAULT '1',
  `asset_id` int unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `access` int unsigned NOT NULL DEFAULT '1',
  `ordering` int NOT NULL DEFAULT '0',
  `landing_show` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_state` (`published`),
  KEY `idx_access` (`access`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


--
-- Dumping data for table `#__bsms_locations`
--

INSERT INTO `#__bsms_locations` SET `id`='1',`location_text`='My Location',`contact_id`='0',`address`=NULL,`suburb`=NULL,`state`=NULL,`country`=NULL,`postcode`=NULL,`telephone`=NULL,`fax`=NULL,`misc`=NULL,`image`=NULL,`email_to`=NULL,`default_con`='0',`checked_out`='0',`checked_out_time`='0000-00-00 00:00:00',`params`='',`user_id`='0',`mobile`='',`webpage`='',`sortname1`='',`sortname2`='',`sortname3`='',`language`='',`created`='0000-00-00 00:00:00',`created_by`='0',`created_by_alias`='',`modified`='0000-00-00 00:00:00',`modified_by`='0',`metakey`='',`metadesc`='',`metadata`='',`featured`='0',`xreference`='',`version`='1',`hits`='0',`publish_up`='0000-00-00 00:00:00',`publish_down`='0000-00-00 00:00:00',`published`='1',`asset_id`='213',`access`='1',`ordering`='1',`landing_show`=NULL;

-- --------------------------------------------------------

--
-- Table structure for table `#__bsms_mediafiles`
--

DROP TABLE IF EXISTS `#__bsms_mediafiles`;
CREATE TABLE `#__bsms_mediafiles` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `study_id` int DEFAULT NULL,
  `server_id` int DEFAULT NULL,
  `podcast_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metadata` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `ordering` int NOT NULL DEFAULT '0',
  `createdate` datetime DEFAULT NULL,
  `hits` int DEFAULT '0',
  `published` tinyint NOT NULL DEFAULT '1',
  `comment` text COLLATE utf8mb4_unicode_ci,
  `downloads` int DEFAULT '0',
  `plays` int DEFAULT '0',
  `params` text COLLATE utf8mb4_unicode_ci,
  `asset_id` int unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `access` int unsigned NOT NULL DEFAULT '1',
  `language` char(7) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The language code for the MediaFile.',
  `created_by` int unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int unsigned NOT NULL DEFAULT '0',
  `checked_out` int unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `idx_state` (`published`),
  KEY `idx_study_id` (`study_id`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_createdby` (`created_by`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


--
-- Dumping data for table `#__bsms_mediafiles`
--

INSERT INTO `#__bsms_mediafiles` SET `id`='1',`study_id`='1',`server_id`='1',`podcast_id`='1',`metadata`='{\"plays\":\"0\", \"downloads\":\"0\"}',`ordering`='0',`createdate`='2009-09-13 00:10:00',`hits`='0',`published`='1',`comment`='Sample Media file',`downloads`='0',`plays`='10',`params`='{\"filename\":\"\\/MediaFiles\\/2015\\/2015-008.mp3\",\"mediacode\":\"\",\"size\":0,\"special\":\"\",\"player\":\"7\",\"popup\":\"3\",\"link_type\":\"\",\"media_hours\":null,\"media_minutes\":\"00\",\"media_seconds\":\"00\",\"docMan_id\":\"0\",\"article_id\":\"\",\"virtueMart_id\":\"0\",\"media_image\":\"images\\/biblestudy\\/speaker24.png\",\"media_use_button_icon\":\"\",\"media_button_text\":\"Audio\",\"media_button_type\":\"btn-link\",\"media_button_color\":\"\",\"media_icon_type\":\"fas fa-play\",\"media_custom_icon\":\"\",\"media_icon_text_size\":\"24\",\"mime_type\":\"audio\\/mp3\",\"playerwidth\":\"\",\"playerheight\":\"\",\"itempopuptitle\":\"\",\"itempopupfooter\":\"\",\"popupmargin\":\"50\",\"autostart\":\"false\"}',`asset_id`='212',`access`='1',`language`='*',`created_by`='1',`created_by_alias`='administration',`modified`='0000-00-00 00:00:00',`modified_by`='1',`checked_out`='0',`checked_out_time`='0000-00-00 00:00:00';
INSERT INTO `#__bsms_mediafiles` SET `id`='2',`study_id`='1',`server_id`='3',`podcast_id`='',`metadata`='',`ordering`='0',`createdate`='2010-03-12 18:10:00',`hits`='0',`published`='1',`comment`='',`downloads`='0',`plays`='6',`params`='{\"link_type\":\"0\",\"docMan_id\":\"0\",\"article_id\":\"-1\",\"virtueMart_id\":\"0\",\"player\":\"0\",\"popup\":\"2\",\"mediacode\":\"\",\"filename\":\"\\/images\\/growthgroupquestions\\/Colossians3_5-11Questions.pdf\",\"size\":0,\"special\":\"\",\"media_image\":\"images\\/biblestudy\\/pdf16.png\",\"mime_type\":\"application\\/pdf\",\"playerwidth\":\"\",\"playerheight\":\"\",\"itempopuptitle\":\"\",\"itempopupfooter\":\"\",\"popupmargin\":\"50\",\"autostart\":\"\"}',`asset_id`='211',`access`='1',`language`='*',`created_by`='0',`created_by_alias`='',`modified`='0000-00-00 00:00:00',`modified_by`='0',`checked_out`='0',`checked_out_time`='0000-00-00 00:00:00';
INSERT INTO `#__bsms_mediafiles` SET `id`='3',`study_id`='1',`server_id`='2',`podcast_id`='',`metadata`='',`ordering`='0',`createdate`='2015-07-28 19:18:07',`hits`='0',`published`='1',`comment`='',`downloads`='0',`plays`='0',`params`='{\"filename\":\"https:\\/\\/youtu.be\\/PsFo6MhAB9o\",\"mediacode\":\"\",\"size\":0,\"special\":\"\",\"player\":\"1\",\"popup\":\"3\",\"link_type\":\"0\",\"media_hours\":\"00\",\"media_minutes\":\"00\",\"media_seconds\":\"00\",\"docMan_id\":\"0\",\"article_id\":\"-1\",\"virtueMart_id\":\"0\",\"media_image\":\"images\\/biblestudy\\/youtube24.png\",\"media_use_button_icon\":\"\",\"media_button_text\":\"Audio\",\"media_button_type\":\"btn-link\",\"media_button_color\":\"\",\"media_icon_type\":\"fas fa-play\",\"media_custom_icon\":\"\",\"media_icon_text_size\":\"24\",\"mime_type\":\"video\\/mp4\",\"playerwidth\":\"\",\"playerheight\":\"\",\"itempopuptitle\":\"\",\"itempopupfooter\":\"\",\"popupmargin\":\"50\",\"autostart\":\"\"}',`asset_id`='104',`access`='1',`language`='*',`created_by`='0',`created_by_alias`='',`modified`='0000-00-00 00:00:00',`modified_by`='0',`checked_out`='0',`checked_out_time`='0000-00-00 00:00:00';

-- --------------------------------------------------------

--
-- Table structure for table `#__bsms_message_type`
--

DROP TABLE IF EXISTS `#__bsms_message_type`;
CREATE TABLE `#__bsms_message_type` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `message_type` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin NOT NULL DEFAULT '',
  `published` tinyint NOT NULL DEFAULT '1',
  `asset_id` int unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `access` int unsigned NOT NULL DEFAULT '1',
  `ordering` int NOT NULL DEFAULT '0',
  `landing_show` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_state` (`published`),
  KEY `idx_access` (`access`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


--
-- Dumping data for table `#__bsms_message_type`
--

INSERT INTO `#__bsms_message_type` SET `id`='1',`message_type`='Sunday',`alias`='sunday',`published`='1',`asset_id`='209',`access`='1',`ordering`='1',`landing_show`=NULL;

-- --------------------------------------------------------

--
-- Table structure for table `#__bsms_podcast`
--

DROP TABLE IF EXISTS `#__bsms_podcast`;
CREATE TABLE `#__bsms_podcast` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `podcastlink` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `subtitle` text COLLATE utf8mb4_unicode_ci,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `imageh` int DEFAULT NULL,
  `imagew` int DEFAULT NULL,
  `author` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `podcastimage` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `podcastsearch` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `filename` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `language` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT 'en-us',
  `editor_name` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `editor_email` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `podcastlimit` int DEFAULT NULL,
  `published` tinyint NOT NULL DEFAULT '1',
  `episodetitle` int DEFAULT NULL,
  `custom` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `detailstemplateid` int DEFAULT NULL,
  `asset_id` int unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `access` int unsigned NOT NULL DEFAULT '1',
  `alternatelink` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'replaces podcast file link on subscription',
  `alternateimage` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'alternate image path for podcast',
  `podcast_subscribe_show` int DEFAULT NULL,
  `podcast_image_subscribe` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'The image to use for the podcast subscription image',
  `podcast_subscribe_desc` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Words to go below podcast subscribe image',
  `alternatewords` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `episodesubtitle` int DEFAULT NULL,
  `customsubtitle` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `linktype` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_state` (`published`),
  KEY `idx_access` (`access`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


--
-- Dumping data for table `#__bsms_podcast`
--

INSERT INTO `#__bsms_podcast` SET `id`='1',`title`='My Podcast',`website`='www.mywebsite.com',`podcastlink`='www.mywebsite.com/PodcastController.php',`description`='Podcast Description goes here',`subtitle`='Short sentence about the podcast',`image`='www.mywebsite.com/myimage.jpg',`imageh`='30',`imagew`='30',`author`='Pastor Billy',`podcastimage`='www.mywebsite.com/myimage.jpg',`podcastsearch`='jesus',`filename`='mypodcast.xml',`language`='*',`editor_name`='Jim Editor',`editor_email`='jim@mywebsite.com',`podcastlimit`='50',`published`='1',`episodetitle`='0',`custom`='',`detailstemplateid`='1',`asset_id`='208',`access`='1',`alternatelink`='',`alternateimage`='',`podcast_subscribe_show`='1',`podcast_image_subscribe`='',`podcast_subscribe_desc`='',`alternatewords`='',`episodesubtitle`='0',`customsubtitle`='',`linktype`='0';

-- --------------------------------------------------------

--
-- Table structure for table `#__bsms_series`
--

DROP TABLE IF EXISTS `#__bsms_series`;
CREATE TABLE `#__bsms_series` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `series_text` text COLLATE utf8mb4_unicode_ci,
  `alias` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin NOT NULL DEFAULT '',
  `teacher` int DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `series_thumbnail` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `published` tinyint NOT NULL DEFAULT '1',
  `asset_id` int unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `ordering` int NOT NULL DEFAULT '0',
  `access` int unsigned NOT NULL DEFAULT '1',
  `language` char(7) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The language code for the Series.',
  `landing_show` int DEFAULT NULL,
  `pc_show` int NOT NULL DEFAULT '1' COMMENT 'For displaying on\n   podcasts page',
  PRIMARY KEY (`id`),
  KEY `idx_state` (`published`),
  KEY `idx_access` (`access`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


--
-- Dumping data for table `#__bsms_series`
--

INSERT INTO `#__bsms_series` SET `id`='1',`series_text`='Worship Series',`alias`='worship-series',`teacher`='-1',`description`='',`series_thumbnail`='',`published`='1',`asset_id`='207',`ordering`='1',`access`='1',`language`='*',`landing_show`=NULL,`pc_show`='1';

-- --------------------------------------------------------

--
-- Table structure for table `#__bsms_servers`
--

DROP TABLE IF EXISTS `#__bsms_servers`;
CREATE TABLE `#__bsms_servers` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `server_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `published` tinyint NOT NULL DEFAULT '1',
  `asset_id` int unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `access` int unsigned NOT NULL DEFAULT '1',
  `type` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `params` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `media` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_state` (`published`),
  KEY `idx_access` (`access`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


--
-- Dumping data for table `#__bsms_servers`
--

INSERT INTO `#__bsms_servers` SET `id`='1',`server_name`='Legacy MP3',`published`='1',`asset_id`='206',`access`='1',`type`='legacy',`params`='{\"path\":\"\\/\\/www.calvarychapelnewberg.net\\/\",\"protocol\":\"http:\\/\\/\"}',`media`='{\"link_type\":\"1\",\"player\":\"7\",\"popup\":\"3\",\"mediacode\":\"\",\"media_image\":\"images\\/biblestudy\\/mp3.png\",\"mime_type\":\"audio\\/mp3\",\"autostart\":\"1\"}';
INSERT INTO `#__bsms_servers` SET `id`='2',`server_name`='Legacy YouTube',`published`='1',`asset_id`='205',`access`='1',`type`='legacy',`params`='{\"path\":\"\",\"protocol\":\"http:\\/\\/\"}',`media`='{\"link_type\":\"0\",\"player\":\"1\",\"popup\":\"3\",\"mediacode\":\"\",\"media_image\":\"images\\/biblestudy\\/youtube24.png\",\"mime_type\":\"video\\/mp4\",\"autostart\":\"1\"}';
INSERT INTO `#__bsms_servers` SET `id`='3',`server_name`='Legacy PDF',`published`='1',`asset_id`='204',`access`='1',`type`='legacy',`params`='{\"path\":\"http:\\/\\/calvarynewberg.org\\/\",\"protocol\":\"http:\\/\\/\"}',`media`='{\"link_type\":\"1\",\"player\":\"0\",\"popup\":\"2\",\"mediacode\":\"\",\"media_image\":\"images\\/biblestudy\\/pdf16.png\",\"mime_type\":\"application\\/pdf\",\"autostart\":\"1\"}';
INSERT INTO `#__bsms_servers` SET `id`='4',`server_name`='Local Server',`published`='1',`asset_id`='214',`access`='1',`type`='local',`params`='',`media`='{\"link_type\":\"\",\"uploadpath\":\"\\/images\\/biblestudy\\/media\\/\",\"player\":\"\",\"popup\":\"\",\"media_image\":\"\",\"media_use_button_icon\":\"\",\"media_button_text\":\"Audio\",\"media_button_type\":\"btn-link\",\"media_button_color\":\"\",\"media_icon_type\":\"fas fa-play\",\"media_custom_icon\":\"\",\"media_icon_text_size\":\"24\",\"mime_type\":\"image\\/jpeg\",\"autostart\":\"\"}';

-- --------------------------------------------------------

--
-- Table structure for table `#__bsms_studies`
--

DROP TABLE IF EXISTS `#__bsms_studies`;
CREATE TABLE `#__bsms_studies` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `studydate` datetime DEFAULT NULL,
  `teacher_id` int DEFAULT '1',
  `studynumber` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `booknumber` int DEFAULT '101',
  `chapter_begin` int DEFAULT '1',
  `verse_begin` int DEFAULT '1',
  `chapter_end` int DEFAULT '1',
  `verse_end` int DEFAULT '1',
  `secondary_reference` text COLLATE utf8mb4_unicode_ci,
  `booknumber2` varchar(4) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `chapter_begin2` varchar(4) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `verse_begin2` varchar(4) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `chapter_end2` varchar(4) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `verse_end2` varchar(4) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `prod_dvd` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `prod_cd` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `server_cd` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `server_dvd` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image_cd` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image_dvd` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `studytext2` text COLLATE utf8mb4_unicode_ci,
  `comments` tinyint(1) DEFAULT '1',
  `hits` int NOT NULL DEFAULT '0',
  `user_id` int DEFAULT NULL,
  `user_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `show_level` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `location_id` int DEFAULT NULL,
  `studytitle` text COLLATE utf8mb4_unicode_ci,
  `alias` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin NOT NULL DEFAULT '',
  `studyintro` text COLLATE utf8mb4_unicode_ci,
  `messagetype` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '1',
  `series_id` int DEFAULT '0',
  `studytext` text COLLATE utf8mb4_unicode_ci,
  `thumbnailm` text COLLATE utf8mb4_unicode_ci,
  `thumbhm` int DEFAULT NULL,
  `thumbwm` int DEFAULT NULL,
  `params` text COLLATE utf8mb4_unicode_ci,
  `checked_out` int unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published` tinyint NOT NULL DEFAULT '0',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int unsigned NOT NULL DEFAULT '0',
  `asset_id` int unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `access` int unsigned NOT NULL DEFAULT '1',
  `ordering` int NOT NULL DEFAULT '0',
  `language` char(7) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The language code for the Studies.',
  `download_id` int NOT NULL DEFAULT '0' COMMENT 'Used for link to download of mediafile',
  PRIMARY KEY (`id`),
  KEY `idx_state` (`published`),
  KEY `idx_access` (`access`),
  KEY `idx_seriesid` (`series_id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_createdby` (`user_id`),
  KEY `idx_checkout` (`checked_out`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


--
-- Dumping data for table `#__bsms_studies`
--

INSERT INTO `#__bsms_studies` SET `id`='1',`studydate`='2010-03-13 00:10:00',`teacher_id`='1',`studynumber`='2015-01',`booknumber`='151',`chapter_begin`='3',`verse_begin`='5',`chapter_end`='3',`verse_end`='11',`secondary_reference`='',`booknumber2`='-1',`chapter_begin2`='',`verse_begin2`='',`chapter_end2`='',`verse_end2`='',`prod_dvd`=NULL,`prod_cd`=NULL,`server_cd`=NULL,`server_dvd`=NULL,`image_cd`=NULL,`image_dvd`='0',`studytext2`=NULL,`comments`='1',`hits`='0',`user_id`='0',`user_name`='',`show_level`='0',`location_id`='1',`studytitle`='Four Steps to Defeating the Flesh',`alias`='four-steps-to-defeating-the-flesh',`studyintro`='If you’ve lived around Oregon very long you know what Oregon mud is like. The soils in the Willamette Valley contain a fair amount of clay. I remember trying to put in a sprinkler system when we first built our house. Foolishly, I thought I could beat the winter rains and get the system put in. Such was not the case. Towards the end I remember slogging around the yard—with each step I took it got harder and harder to walk as more and more mud clung to my shoes.',`messagetype`='1',`series_id`='1',`studytext`='If you’ve lived around Oregon very long you know what Oregon mud is like. The soils in the Willamette Valley contain a fair amount of clay. I remember trying to put in a sprinkler system when we first built our house. Foolishly, I thought I could beat the winter rains and get the system put in. Such was not the case. Towards the end I remember slogging around the yard—with each step I took it got harder and harder to walk as more and more mud clung to my shoes. I use that analogy because the goal of becoming a Christian is to become like God in our character. We realize the old ways of sin just aren’t working for us and we come to Christ who forgives us and gives us eternal life. As Paul says: “old things have passed away, and look new things have come” (2 Cor 5:17). So far so good. The trouble starts when we begin walking around in this life. Instead of feeling light and free and pure—we feel the “old man” or “the flesh” sticking to our character like clay sticking to our shoes. The old ways of thinking, speaking, and acting are still with us—ready to take over at the slightest provocation or temptation. It makes it hard to walk with Christ effectively and smoothly. Paul says it well in: Romans 7:18 “For I know that nothing good lives in me, that is, in my flesh. For the desire to do what is good is with me, but there is no ability to do it. 19 For I do not do the good that I want to do, but I practice the evil that I do not want to do. 20 Now if I do what I do not want, I am no longer the one doing it, but it is the sin that lives in me.” So what’s a Christian to do? The goal is to be like Christ but the flesh seems to be so successful in holding us back. That’s what Colossians 3 and much of Chapter 4 is about. Paul outlines for us what the old character looks like, and what the new nature looks like by contrast. He describes the process of change as something as simple as changing your clothes. It’s simple in theory, difficult in practice, but totally worth the effort. He describes this change away from the old character with four actions: “put to death” (verse 5), “put away” (verse 8) and “put off” (verse 9), then we are to “put on” the new character of Christ (verse 10). The character traits that we are to kill, put away, and put off are: improper or unchecked desire, anger, and lying. From these three spring most of the things we associate with “the flesh”. 5 Paul starts off with “therefore”. In light of the fact that we are risen people, we need to start thinking like citizens of heaven (the new age), not like residents of earth (this age). Paul says for us to “put to death what belongs to your earthly nature.” The word “put to death” means: “to make dead.” How does that happen? Paul gives us a clue in Romans 8:13: “But if by the Spirit you put to death the deeds of the body, you will live.” So there is this cooperation that takes place between God’s Spirit and us. In reality, you will not be free from the presence and temptation to act in the old ways until you are given you new body. But as James 1:14 says: “But each person is tempted when he is drawn away and enticed by his own evil desires. 15 Then after desire has conceived, it gives birth to sin, and when sin is fully grown, it gives birth to death.   Evil thoughts will occur; it is what we do with them that matters. When they come we can, by the power of the Spirit, tell them they are dead and have no place in us anymore. Do it strongly; do it often. Picture those thoughts on a paper, and then nail that paper to the cross. Jesus died to rid you of acting on those thought patterns. The word “put to death” can mean: “to deprive of power.” Cut the supply lines to the old nature and it will become weak nd starve. So here is the big question: what in your life is still feeding the flesh? It’s different for everyone, mind you. Starve the flesh and it will go a long way to killing it. This is part 1: “kill the old ways, one thought at a time.” Next, Paul lists five manifestations of the flesh that we need to watch out for. Make no mistake—these are powerful forces in the human mind and are not easily dissuaded or killed. Sexual immorality. It means any sexual intimacy outside of the marriage between a man and a woman. Impurity means the character infected by immoral behavior. Lust refers to any unbridled passion but here likely refers to sexual desire that is out of bounds and out of control. Evil desire is probably better translated as lust—but could refer to the thoughts that precede lust. Remember again, it isn’t the temptation but what we do with it that matters. We sin when we focus on and even encourage impure thoughts that lead to impure actions. Greed, which is idolatry. Greed here is a general term for unchecked physical pleasure. Paul calls it greed because the worship of pleasure – the worship of anything for that matter – takes first place in front of God, and that is idolatry. In Paul’s day, literal idol worship was rampant, as was sexual immorality with temple prostitutes as part of that idolatry. And because sex is such a powerful thing, these actions led to impure thoughts, desires, and lusts. 6 God’s wrath is the natural outpouring against anyone who is not pure. Doing something that is sinful is disobeying God because He said “Be holy, even as I am holy” (Lev. 11:45). Some people say that a loving God cannot be a wrathful God. But you cannot have love without wrath against evil. Love means protecting the innocent against evil. It means coming against evil and destroying it. Just ask any parent who has lost a child to horrible violence—and you begin to understand the love and wrath of God. Before we get too smug in the opinion that we aren’t like those disobedient sinners—look at the next verse. 7 Before we knew Jesus we all disobeyed and were guilty as charged. “All have sinned and fall short of the glory of God” (Romans 3:23). We acted out these things (“walked”) because we were steeped in them. We could translate this verse as: “when your life consisted of such wretched things as these.” As fallen people we couldn’t help but act in these ways, but not anymore. Now we are steeped in the Messiah’s forgiving and cleansing love. We don’t have to act out the deeds of the flesh any more. And Paul goes onto to step 2 of how to do that next. 8 Step One is to “Kill kill, kill them all” – all the thoughts that come from the flesh and urge us to think and do things that are not like God. We should nail those thoughts to the cross. Step Two is to “put off” or “put away” the deeds of the flesh. The flesh should feel like a foreign intruder. We don’t just ignore it; we actively push it away. The Greek here is the picture of taking off your clothes. The flesh is like an old set of worn out clothes that, through the Spirit, we can literally take off. Paul helps us understand this by being very specific in another major area of the old nature: anger. He brings in five ways anger destroys us. Anger and wrath are related. Anger is Greek word for a plant that is bursting with juice. What a great picture of when we get red-hot with anger and our face literally flushes red with blood. Wrath means: “to rush in” and is what we do when we are angry. How often do we get angry and let our anger vent with hurtful words that later we wish we could take back. Malice is when we mean to hurt someone—often the result of anger. Slander is what we say about them to hurt them. It’s the Greek word: blasphema. In this case it is hurtful words about another, rather than God. Finally “filthy language” refers to the words used—words which hurt both the speaker and the hearer. Why do we get angry? There are many answers to that question—but I want to bring in four main ones: Frustration – when a goal is thwarted; like getting to work on time thwarted by heavy traffic. Hurt – when the words or actions of another wounds us. Loss – when something that we hold dear is taken away, like a job or a spouse. Victim thinking – when I don’t get what I think I deserve. Put it to death by declaring the sin nature dead on the cross. Romans 6:6 “For we know that our old self was crucified with Him in order that sin’s dominion over the body may be abolished, so that we may no longer be enslaved to sin”. Put it away by separating yourself from that old character, like you’d change out of an old set of clothes. Put it off, remove its power, by thinking of the flesh as something foreign to you, like a limb that is no longer a part of your body—gangrenous and in need of amputation. Then put on the character of Christ like putting on a costume in a play. The more you wear it the more comfortable you will be in it and the more you will own that new character Each one of us struggles with different parts of our old nature. You can be a Christian for many years and still struggle with areas of the flesh. I think that often what happens is a trigger occurs—perhaps a word or phrase that reminds our unconscious mind of an abuse from childhood. We don’t think about but that trigger dis-regulates us, our pre-frontal cortex goes offline and our fleshly nature takes over. The trick is to begin to notice it—even physically in our body—and then work with the Holy Spirit to put you back into your new-self state of mind. 9 – 10 In verse 9, Paul moves to the third major category of the flesh—our interactions with others in relation to the truth. Lying is a default human behavior that we learn at a very young age. We bend facts and manipulate the truth in order to get a result we feel we can’t get by telling the truth. We do it in big ways and in small ways all the time. But lying is not a character trait of heaven—and lying is one of the sins specifically mentioned in Revelation 21:15 as being excluded from heaven. It’s part of the old set of clothes that we need to “put off”. It means: “to wholly strip off of oneself” or “to disarm”. Does it mean we must then be completely transparently honest with everything we think at all times? Of course not. Ephesians 4:15 says: “Speaking the truth in love let us grow in every way into Him.” Be honest always, and always speak those truths in a way that will build up and encourage another’s relationship with Christ. One way we disarm lying is to think: what can I say that will benefit this person, truly. Sometimes that is saying a difficult thing, but not in a hurtful way, but a helpful one. We move now from “putting off” the old character to “putting on” a new one—which is the character of Christ. The words literally mean to put on a change of clothes. Paul uses the same Greek word in Rom. 13:14: “But put on the Lord Jesus Christ, and make no plans to satisfy the fleshly desires.” The word can also mean: “to sink into”. Believe it or not, you have the power to put on or sink into the character of Jesus—forcing out the old flesh, which is always making plans to satisfy itself. At first it might feel very foreign, like wearing a costume while playing a part in a play. But you know, that’s okay. Play the part of a person who thinks, acts, and speaks like Jesus in love, joy, peace, patience, kindness, gentleness and the like. It might feel a little hypocritical at first but the more you practice the part the more comfortable you get with it and the more it becomes part of you. All you are doing really is cooperating with the force of the Holy Spirit in you that already wants to make these changes. It is part of that “renewal” process Paul talks about here. The more we know about Jesus and His character, and the more we work towards mirroring that character, the more into His “image” we become. You’ll find in the end that this new character is the “real” new you that God has been making all along. 11 Verse 11 brings up what is often the source of the fleshly desires that run counter to the character of Christ—divisions along racial, economic, social, and religious differences. After Alexander the Great conquered much of the known world, he spread the Greek culture far and wide. So the Greeks felt very self-important culturally. The Jews also felt very superior religiously as they had the Torah and a covenant with Yahweh. This division was never so strident when it came to who was in the covenant and who was out—via circumcision. Barbarians were any non-Greek or non-Jews and Scythians were a little known race of people from the far-northern part of the Middle East who were thought to be no better than animals. Slavery was well known in that culture and separated people along socio-economic lines. Often times it is these things that cause the flesh to flare up. But Paul says Christ is in all peoples (how that could be rendered). Jesus is the great equalizer of religious, racial, cultural and socio-economic status. Also, as Paul says in Galatians 3:28, the great equalizer of gender inequalities. In Christ we should never let those things separate us. That’s the old way, not the new. So we’re talked about three ways to help rid ourselves of the old nature and one way to help nurture the new character. Try it on with something you are struggling with, like anger. Picture what it would be like if something or someone makes you angry. How would you normally react and how can these new steps intervene? What are the qualities in the new character that replace unchecked desire, anger, and dishonesty? Fidelity (commitment in your relationships with others and with God) Security (trusting that God will supply your needs) Love (self-sacrificing, other-centered affection that looks out for the good of others always) We’ll talk more about these as they relate to everyday life in the coming verses.',`thumbnailm`='',`thumbhm`=NULL,`thumbwm`=NULL,`params`='{\"metakey\":\"Rain, Flesh, \\\"Sexual immorality\\\", Impurity, Lust, \\\"Evil desire\\\", Greed, Frustration, Hurt, Loss, \\\"Victim thinking\\\", \\\"Put it to death\\\", \\\"Put it away\\\",\\\"Put it off\\\"\",\"metadesc\":\"\"}',`checked_out`='0',`checked_out_time`='0000-00-00 00:00:00',`published`='1',`publish_up`='0000-00-00 00:00:00',`publish_down`='0000-00-00 00:00:00',`modified`='2015-07-28 23:46:05',`modified_by`='627',`asset_id`='210',`access`='1',`ordering`='1',`language`='*',`download_id`='-1';

-- --------------------------------------------------------

--
-- Table structure for table `#__bsms_studytopics`
--

DROP TABLE IF EXISTS `#__bsms_studytopics`;
CREATE TABLE `#__bsms_studytopics` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `study_id` int NOT NULL DEFAULT '0',
  `topic_id` int NOT NULL DEFAULT '0',
  `asset_id` int unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `access` int unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_access` (`access`),
  KEY `idx_study` (`study_id`),
  KEY `idx_topic` (`topic_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


--
-- Dumping data for table `#__bsms_studytopics`
--

INSERT INTO `#__bsms_studytopics` SET `id`='3',`study_id`='1',`topic_id`='114',`asset_id`='7594',`access`='1';
INSERT INTO `#__bsms_studytopics` SET `id`='4',`study_id`='1',`topic_id`='114',`asset_id`='7595',`access`='1';

-- --------------------------------------------------------

--
-- Table structure for table `#__bsms_teachers`
--

DROP TABLE IF EXISTS `#__bsms_teachers`;
CREATE TABLE `#__bsms_teachers` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `teacher_image` text COLLATE utf8mb4_unicode_ci,
  `teacher_thumbnail` text COLLATE utf8mb4_unicode_ci,
  `teachername` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin NOT NULL DEFAULT '',
  `title` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website` text COLLATE utf8mb4_unicode_ci,
  `information` text COLLATE utf8mb4_unicode_ci,
  `image` text COLLATE utf8mb4_unicode_ci,
  `imageh` text COLLATE utf8mb4_unicode_ci,
  `imagew` text COLLATE utf8mb4_unicode_ci,
  `thumb` text COLLATE utf8mb4_unicode_ci,
  `thumbw` text COLLATE utf8mb4_unicode_ci,
  `thumbh` text COLLATE utf8mb4_unicode_ci,
  `short` text COLLATE utf8mb4_unicode_ci,
  `ordering` int NOT NULL DEFAULT '0',
  `catid` int DEFAULT '1',
  `list_show` tinyint(1) NOT NULL DEFAULT '1',
  `published` tinyint NOT NULL DEFAULT '1',
  `asset_id` int unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `access` int unsigned NOT NULL DEFAULT '1',
  `language` char(7) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The language code for the Teachers.',
  `facebooklink` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitterlink` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bloglink` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `link1` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `linklabel1` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `link2` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `linklabel2` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `link3` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `linklabel3` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact` int DEFAULT NULL,
  `address` mediumtext COLLATE utf8mb4_unicode_ci,
  `landing_show` int DEFAULT NULL,
  `address1` mediumtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `idx_state` (`published`),
  KEY `idx_access` (`access`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


--
-- Dumping data for table `#__bsms_teachers`
--

INSERT INTO `#__bsms_teachers` SET `id`='1',`teacher_image`='',`teacher_thumbnail`='',`teachername`='Billy Sunday',`alias`='billy-sunday',`title`='Pastor',`phone`='555-555-5555',`email`='billy@sunday.com',`website`='http://billysunday.com',`information`='William Ashley Sunday was an American athlete who after being a popular outfielder in baseballs National League during the 1880s became the most celebrated and influential American evangelist during the first two decades of the 20th century.',`image`='',`imageh`='276',`imagew`='197',`thumb`='media/com_proclaim/images/images.jpg',`thumbw`='101',`thumbh`='141',`short`='Billy Sunday: 1862-1935',`ordering`='0',`catid`='1',`list_show`='1',`published`='1',`asset_id`='203',`access`='1',`language`='*',`facebooklink`='',`twitterlink`='',`bloglink`='',`link1`='',`linklabel1`='',`link2`='',`linklabel2`='',`link3`='',`linklabel3`='',`contact`='0',`address`='',`landing_show`='1',`address1`='';

-- --------------------------------------------------------

--
-- Table structure for table `#__bsms_templatecode`
--

DROP TABLE IF EXISTS `#__bsms_templatecode`;
CREATE TABLE `#__bsms_templatecode` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `published` tinyint NOT NULL DEFAULT '1',
  `type` tinyint NOT NULL,
  `filename` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `asset_id` int unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `templatecode` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


--
-- Dumping data for table `#__bsms_templatecode`
--

INSERT INTO `#__bsms_templatecode` SET `id`='1',`published`='1',`type`='1',`filename`='easy',`asset_id`='201',`templatecode`='<?php\n\n/**\n * Helper for Template Code\n *\n * @package    Proclaim.Admin\n * @copyright  2007 - 2022 (C) CWM Team All rights reserved\n * @license    http://www.gnu.org/copyleft/gpl.html GNU/GPL\n * @link       https://www.christianwebministries.org\n * */\n// No Direct Access\ndefined(\'_JEXEC\') or die;\n\n// Do not remove\n// this is here to make sure that security of the site is maintained. It should be placed in every template file\nJHtml::addIncludePath(JPATH_COMPONENT . \'/helpers/html\');\n\nJHtml::_(\'bootstrap.tooltip\');\nJHtml::_(\'dropdown.init\');\nJHtml::_(\'behavior.multiselect\');\nJHtml::_(\'formbehavior.chosen\', \'select\');\n\n$app       = Factory::getApplication();\n$user      = $user = Factory::getApplication()->getSession()->get(\"user\");\n$userId    = $user->get(\'id\');\n$listOrder = $this->escape($this->state->get(\'list.ordering\'));\n$listDirn  = $this->escape($this->state->get(\'list.direction\'));\n$archived  = $this->state->get(\'filter.published\') == 2 ? true : false;\n$trashed   = $this->state->get(\'filter.published\') == -2 ? true : false;\n$saveOrder = $listOrder == \'study.ordering\';\n$columns   = 12;\n\n\n\n?>\n<style>img{border-radius:4px;}</style>\n\n\n  <div class=\"row-fluid span12\">\n    <h2>\n      Teachings\n    </h2>\n  </div>\n\n\n\n  <div class=\"row-fluid span12 dropdowns\" style=\"background-color:#A9A9A9; margin:0 -5px; padding:8px 8px; border:1px solid #C5C1BE; position:relative; -webkit-border-radius:10px;\">\n\n    <?php\n    echo $this->page->books;\n    echo $this->page->teachers;\n    echo $this->page->series;\n    $oddeven = \'\';\n	$class1 = \'#d3d3d3\';\n    $class2 = \'\';?>\n</div>\n<?php foreach ($this->items as $study)\n{\n\n	$oddeven = ($oddeven == $class1) ? $class2 : $class1;\n	?>\n	<div style=\"width:100%;\">\n		<div class=\"span3\"><div style=\"padding:12px 8px;line-height:22px;height:200px;\">\n				<?php if ($study->study_thumbnail) {echo \'<span style=\"max-width:250px; height:auto;\">\'.$study->study_thumbnail .\'</span>\'; echo \'<br />\';} ?>\n				<strong><?php echo $study->studytitle;?></strong><br />\n				<span style=\"color:#9b9b9b;\"><?php echo $study->scripture1;?> | <?php echo $study->studydate;?></span><br />\n				<div style=\"font-size:85%;margin-bottom:-17px;max-height:122px;overflow:hidden;\"><?php echo $study->teachername;?></div><br /><div style=\"background: rgba(0, 0, 0, 0) linear-gradient(to bottom, rgba(255, 255, 255, 0) 0%, white 100%) repeat scroll 0 0;bottom: 0;height: 32px;margin-top: -32px; position: relative;width: 100%;\"></div>\n				<?php echo $study->media; ?>\n			</div></div>\n\n\n	</div>\n<?php }?>\n<div class=\"row-fluid span12 pagination pagelinks\" style=\"background-color: #A9A9A9;\n	margin: 0 -5px;\n	padding: 8px 8px;\n	border: 1px solid #C5C1BE;\n	position: relative;\n	-webkit-border-radius: 9px;\">\n	<?php echo $this->pagination->getPageslinks();?>\n</div>';

-- --------------------------------------------------------

--
-- Table structure for table `#__bsms_templates`
--

DROP TABLE IF EXISTS `#__bsms_templates`;
CREATE TABLE `#__bsms_templates` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tmpl` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `published` tinyint NOT NULL DEFAULT '1',
  `params` longtext COLLATE utf8mb4_unicode_ci,
  `title` text COLLATE utf8mb4_unicode_ci,
  `text` text COLLATE utf8mb4_unicode_ci,
  `pdf` text COLLATE utf8mb4_unicode_ci,
  `asset_id` int unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `access` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_state` (`published`),
  KEY `idx_access` (`access`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


--
-- Dumping data for table `#__bsms_templates`
--

INSERT INTO `#__bsms_templates` SET `id`='1',`type`='tmplList',`tmpl`='',`published`='1',`params`='{\"useterms\":\"0\",\"terms\":\"\",\"css\":\"biblestudy.css\",\"studieslisttemplateid\":\"1\",\"sermonstemplate\":\"0\",\"detailstemplateid\":\"1\",\"sermontemplate\":\"0\",\"teachertemplateid\":\"1\",\"teachertemplate\":\"0\",\"teacherstemplate\":\"0\",\"serieslisttemplateid\":\"1\",\"seriesdisplaystemplate\":\"0\",\"seriesdetailtemplateid\":\"1\",\"seriesdisplaytemplate\":\"0\",\"offset\":\"false\",\"teacher_id\":[\"-1\"],\"series_id\":[\"-1\"],\"booknumber\":[\"-1\"],\"topic_id\":[\"-1\"],\"messagetype\":[\"-1\"],\"locations\":[\"-1\"],\"show_verses\":\"0\",\"stylesheet\":\"\",\"date_format\":\"2\",\"custom_date_format\":\"\",\"duration_type\":\"2\",\"protocol\":\"http:\\/\\/\",\"player\":\"0\",\"popuptype\":\"window\",\"internal_popup\":\"1\",\"special\":\"_blank\",\"autostart\":\"1\",\"playerresposive\":\"1\",\"player_width\":\"400\",\"player_height\":\"300\",\"embedshare\":\"TRUE\",\"backcolor\":\"0x287585\",\"frontcolor\":\"0xFFFFFF\",\"lightcolor\":\"0x000000\",\"screencolor\":\"0x000000\",\"popuptitle\":\"{{title}}\",\"popupfooter\":\"{{filename}}\",\"popupmargin\":\"50\",\"popupbackground\":\"black\",\"popupimage\":\"media\\/com_proclaim\\/images\\/speaker24.png\",\"show_filesize\":\"1\",\"playerposition\":\"over\",\"playeridlehide\":\"1\",\"default_order\":\"DESC\",\"default_order_secondary\":\"ASC\",\"show_page_title\":\"1\",\"show_page_image\":\"1\",\"list_page_title\":\"Bible Studies\",\"list_title_align\":\"text-align:center\",\"use_headers_list\":\"1\",\"studies_element\":\"1\",\"list_intro\":\"\",\"intro_show\":\"1\",\"list_teacher_show\":\"1\",\"listteachers\":[],\"teacherlink\":\"1\",\"showpodcastsubscribelist\":\"1\",\"subscribeintro\":\"Our Podcasts\",\"details_text\":\"Study Details\",\"show_book_search\":\"1\",\"ddbooks\":\"1\",\"booklist\":\"1\",\"use_go_button\":\"1\",\"ddgobutton\":\"2\",\"show_teacher_search\":\"1\",\"ddteachers\":\"3\",\"show_series_search\":\"1\",\"ddseries\":\"4\",\"show_type_search\":\"1\",\"ddmessagetype\":\"5\",\"show_year_search\":\"1\",\"ddyears\":\"6\",\"show_order_search\":\"1\",\"ddorder\":\"7\",\"show_topic_search\":\"1\",\"ddtopics\":\"8\",\"show_locations_search\":\"1\",\"ddlocations\":\"9\",\"show_popular\":\"1\",\"ddpopular\":\"10\",\"listlanguage\":\"0\",\"ddlanguage\":\"11\",\"show_pagination\":\"1\",\"listcolor1\":\"#8f8fb2\",\"listcolor2\":\"#ccccff\",\"rowspanitem\":\"1\",\"rowspanitemspan\":\"2\",\"rowspanitemimage\":\"img-polaroid\",\"rowspanitempull\":\"pull-left\",\"scripture1row\":\"0\",\"scripture1col\":\"3\",\"scripture1colspan\":\"2\",\"scripture1element\":\"1\",\"scripture1custom\":\"\",\"scripture1linktype\":\"0\",\"scripture2row\":\"0\",\"scripture2col\":\"1\",\"scripture2colspan\":\"3\",\"scripture2element\":\"1\",\"scripture2custom\":\"\",\"scripture2linktype\":\"0\",\"secondaryrow\":\"0\",\"secondarycol\":\"1\",\"secondarycolspan\":\"1\",\"secondaryelement\":\"1\",\"secondarycustom\":\"\",\"secondarylinktype\":\"0\",\"jbsmediarow\":\"1\",\"jbsmediacol\":\"4\",\"jbsmediacolspan\":\"4\",\"jbsmediaelement\":\"0\",\"jbsmediacustom\":\"\",\"jbsmedialinktype\":\"2\",\"titlerow\":\"1\",\"titlecol\":\"2\",\"titlecolspan\":\"4\",\"titleelement\":\"1\",\"titlecustom\":\"\",\"titlelinktype\":\"0\",\"daterow\":\"1\",\"datecol\":\"1\",\"datecolspan\":\"2\",\"dateelement\":\"1\",\"datecustom\":\"\",\"datelinktype\":\"0\",\"teacherrow\":\"0\",\"teachercol\":\"1\",\"teachercolspan\":\"1\",\"teacherelement\":\"1\",\"teachercustom\":\"\",\"teacherlinktype\":\"0\",\"teacherimagerrow\":\"0\",\"teacherimagecol\":\"1\",\"teacherimagecolspan\":\"1\",\"teacherimageelement\":\"1\",\"teacherimagecustom\":\"\",\"teacher-titlerow\":\"0\",\"teacher-titlecol\":\"1\",\"teacher-titlecolspan\":\"1\",\"teacher-titleelement\":\"1\",\"teacher-titlecustom\":\"\",\"teacher-titlelinktype\":\"0\",\"durationrow\":\"0\",\"durationcol\":\"1\",\"durationcolspan\":\"1\",\"durationelement\":\"1\",\"durationcustom\":\"\",\"durationlinktype\":\"0\",\"studyintrorow\":\"0\",\"studyintrocol\":\"1\",\"studyintrocolspan\":\"12\",\"studyintroelement\":\"1\",\"studyintrocustom\":\"\",\"studyintrolinktype\":\"0\",\"seriesrow\":\"0\",\"seriescol\":\"1\",\"seriescolspan\":\"1\",\"serieselement\":\"1\",\"seriescustom\":\"\",\"serieslinktype\":\"0\",\"seriesthumbnailrow\":\"0\",\"seriesthumbnailcol\":\"1\",\"seriesthumbnailcolspan\":\"1\",\"seriesthumbnailelement\":\"1\",\"seriesthumbnailcustom\":\"\",\"seriesthumbnaillinktype\":\"0\",\"seriesdescriptionrow\":\"0\",\"seriesdescriptioncol\":\"1\",\"seriesdescriptioncolspan\":\"1\",\"seriesdescriptionelement\":\"1\",\"seriesdescriptioncustom\":\"\",\"seriesdescriptionlinktype\":\"0\",\"submittedrow\":\"0\",\"submittedcol\":\"1\",\"submittedcolspan\":\"1\",\"submittedelement\":\"1\",\"submittedcustom\":\"\",\"submittedlinktype\":\"0\",\"hitsrow\":\"0\",\"hitscol\":\"1\",\"hitscolspan\":\"6\",\"hitselement\":\"1\",\"hitscustom\":\"\",\"hitslinktype\":\"0\",\"downloadsrow\":\"0\",\"downloadscol\":\"1\",\"downloadscolspan\":\"1\",\"downloadselement\":\"1\",\"downloadscustom\":\"\",\"downloadslinktype\":\"0\",\"studynumberrow\":\"0\",\"studynumbercol\":\"1\",\"studynumbercolspan\":\"1\",\"studynumberelement\":\"1\",\"studynumbercustom\":\"\",\"studynumberlinktype\":\"0\",\"topicrow\":\"0\",\"topiccol\":\"1\",\"topiccolspan\":\"6\",\"topicelement\":\"1\",\"topiccustom\":\"\",\"topiclinktype\":\"0\",\"locationsrow\":\"0\",\"locationscol\":\"1\",\"locationscolspan\":\"1\",\"locationselement\":\"1\",\"locationscustom\":\"\",\"locationslinktype\":\"0\",\"messagetyperow\":\"0\",\"messagetypecol\":\"1\",\"messagetypecolspan\":\"6\",\"messagetypeelement\":\"1\",\"messagetypecustom\":\"\",\"messagetypelinktype\":\"0\",\"thumbnailrow\":\"0\",\"thumbnailcol\":\"1\",\"thumbnailcolspan\":\"1\",\"thumbnailelement\":\"1\",\"thumbnailcustom\":\"\",\"thumbnaillinktype\":\"0\",\"customrow\":\"0\",\"customcol\":\"1\",\"customcolspan\":\"1\",\"customelement\":\"1\",\"customcustom\":\"\",\"customtext\":\"\",\"show_print_view\":\"1\",\"link_text\":\"Return to Studies List\",\"showrelated\":\"1\",\"showpodcastsubscribedetails\":\"1\",\"show_scripture_link\":\"0\",\"show_passage_view\":\"1\",\"bible_version\":\"51\",\"socialnetworking\":\"1\",\"sharetype\":\"1\",\"sharelabel\":\"Share This\",\"comments_type\":\"0\",\"show_comments\":\"1\",\"link_comments\":\"0\",\"comment_access\":\"1\",\"comment_publish\":\"0\",\"use_captcha\":\"1\",\"public_key\":\"\",\"private_key\":\"\",\"email_comments\":\"1\",\"recipient\":\"\",\"subject\":\"Comments on studies\",\"body\":\"Comments entered.\",\"study_detailtemplate\":\"\",\"teacher_title\":\"Our Teachers\",\"teachers_element\":\"1\",\"tsrowspanitem\":\"0\",\"tsrowspanitemspan\":\"4\",\"tsrowspanitemimage\":\"img-polaroid\",\"tsrowspanitempull\":\"pull-left\",\"use_headers_teacher_list\":\"1\",\"tslistcolor1\":\"\",\"tslistcolor2\":\"\",\"tsteacherrow\":\"1\",\"tsteachercol\":\"1\",\"tsteachercolspan\":\"2\",\"tsteacherelement\":\"1\",\"tsteachercustom\":\"\",\"tsteacherlinktype\":\"0\",\"tsteacherimagerrow\":\"0\",\"tsteacherimagecol\":\"1\",\"tsteacherimagecolspan\":\"1\",\"tsteacherimageelement\":\"1\",\"tsteacherimagecustom\":\"\",\"tsteacher-titlerow\":\"0\",\"tsteacher-titlecol\":\"1\",\"tsteacher-titlecolspan\":\"1\",\"tsteacher-titleelement\":\"1\",\"tsteacher-titlecustom\":\"\",\"tsteacher-titlelinktype\":\"0\",\"tsteacheremailrow\":\"0\",\"tsteacheremailcol\":\"1\",\"tsteacheremailcolspan\":\"1\",\"tsteacheremailelement\":\"1\",\"tsteacheremailcustom\":\"\",\"tsteacherwebrow\":\"0\",\"tsteacherwebcol\":\"1\",\"tsteacherwebcolspan\":\"1\",\"tsteacherwebelement\":\"1\",\"tsteacherphonerow\":\"0\",\"tsteacherphonecol\":\"1\",\"tsteacherphonecolspan\":\"1\",\"tsteacherphoneelement\":\"1\",\"tsteacherphonecustom\":\"\",\"tsteacherfbrow\":\"0\",\"tsteacherfbcol\":\"1\",\"tsteacherfbcolspan\":\"1\",\"tsteacherfbelement\":\"1\",\"tsteacherfbcustom\":\"\",\"tsteachertwrow\":\"0\",\"tsteachertwcol\":\"1\",\"tsteachertwcolspan\":\"1\",\"tsteachertwelement\":\"1\",\"tsteachertwcustom\":\"\",\"tsteacherblogrow\":\"0\",\"tsteacherblogcol\":\"1\",\"tsteacherblogcolspan\":\"1\",\"tsteacherblogelement\":\"1\",\"tsteacherblogcustom\":\"\",\"tsteachershortrow\":\"0\",\"tsteachershortcol\":\"1\",\"tsteachershortcolspan\":\"1\",\"tsteachershortelement\":\"1\",\"tsteachershortcustom\":\"\",\"tsteachershortlinktype\":\"0\",\"tscustomrow\":\"\",\"tscustomcol\":\"1\",\"tscustomcolspan\":\"1\",\"tscustomelement\":\"1\",\"tscustomcustom\":\"\",\"tscustomtext\":\"\",\"tsteacherallinonerow\":\"0\",\"tsteacherallinonecol\":\"1\",\"tsteacherallinonecolspan\":\"1\",\"tsteacherallinoneelement\":\"1\",\"tsteacherallinonecustom\":\"\",\"teacher_headercode\":\"\",\"teacher_templatecode\":\"           {{teacher}}     {{title}}     {{teacher}}           {{short}}     {{information}}       \",\"teacher_wrapcode\":\"0\",\"show_teacher_studies\":\"0\",\"studies\":\"\",\"label_teacher\":\"Latest Messages\",\"teacherlinkstudies\":\"1\",\"tdrowspanitem\":\"0\",\"tdrowspanitemspan\":\"4\",\"tdrowspanitemimage\":\"img-polaroid\",\"tdrowspanitempull\":\"pull-left\",\"use_headers_teacher_details\":\"1\",\"teacherdisplay_color\":\"\",\"tdteacherrow\":\"1\",\"tdteachercol\":\"1\",\"tdteachercolspan\":\"2\",\"tdteacherelement\":\"1\",\"tdteachercustom\":\"\",\"tdteacherimagerrow\":\"0\",\"tdteacherimagecol\":\"1\",\"tdteacherimagecolspan\":\"1\",\"tdteacherimageelement\":\"1\",\"tdteacherimagecustom\":\"\",\"tdteacher-titlerow\":\"0\",\"tdteacher-titlecol\":\"1\",\"tdteacher-titlecolspan\":\"1\",\"tdteacher-titleelement\":\"1\",\"tdteacher-titlecustom\":\"\",\"tdteacheremailrow\":\"0\",\"tdteacheremailcol\":\"1\",\"tdteacheremailcolspan\":\"1\",\"tdteacheremailelement\":\"1\",\"tdteacheremailcustom\":\"\",\"tdteacherwebrow\":\"0\",\"tdteacherwebcol\":\"1\",\"tdteacherwebcolspan\":\"1\",\"tdteacherwebelement\":\"1\",\"tdteacherphonerow\":\"0\",\"tdteacherphonecol\":\"1\",\"tdteacherphonecolspan\":\"1\",\"tdteacherphoneelement\":\"1\",\"tdteacherphonecustom\":\"\",\"tdteacherfbrow\":\"0\",\"tdteacherfbcol\":\"1\",\"tdteacherfbcolspan\":\"1\",\"tdteacherfbelement\":\"1\",\"tdteacherfbcustom\":\"\",\"tdteachertwrow\":\"0\",\"tdteachertwcol\":\"1\",\"tdteachertwcolspan\":\"1\",\"tdteachertwelement\":\"1\",\"tdteachertwcustom\":\"\",\"tdteacherblogrow\":\"0\",\"tdteacherblogcol\":\"1\",\"tdteacherblogcolspan\":\"1\",\"tdteacherblogelement\":\"1\",\"tdteacherblogcustom\":\"\",\"tdteachershortrow\":\"0\",\"tdteachershortcol\":\"1\",\"tdteachershortcolspan\":\"1\",\"tdteachershortelement\":\"1\",\"tdteachershortcustom\":\"\",\"tdteacherlongrow\":\"0\",\"tdteacherlongcol\":\"1\",\"tdteacherlongcolspan\":\"1\",\"tdteacherlongelement\":\"1\",\"tdteacherlongcustom\":\"\",\"tdteacheraddressrow\":\"0\",\"tdteacheraddresscol\":\"1\",\"tdteacheraddresscolspan\":\"1\",\"tdteacheraddresselement\":\"1\",\"tdteacheraddresscustom\":\"\",\"tdteacherlink1row\":\"0\",\"tdteacherlink1col\":\"1\",\"tdteacherlink1colspan\":\"1\",\"tdteacherlink1element\":\"1\",\"tdteacherlink1custom\":\"\",\"tdteacherlink2row\":\"0\",\"tdteacherlink2col\":\"1\",\"tdteacherlink2colspan\":\"1\",\"tdteacherlink2element\":\"1\",\"tdteacherlink2custom\":\"\",\"tdteacherlink3row\":\"0\",\"tdteacherlink3col\":\"1\",\"tdteacherlink3colspan\":\"1\",\"tdteacherlink3element\":\"1\",\"tdteacherlink3custom\":\"\",\"tdteacherlargeimagerow\":\"0\",\"tdteacherlargeimagecol\":\"1\",\"tdteacherlargeimagecolspan\":\"1\",\"tdteacherlargeimageelement\":\"1\",\"tdteacherlargeimagecustom\":\"\",\"tdcustomrow\":\"\",\"tdcustomcol\":\"1\",\"tdcustomcolspan\":\"1\",\"tdcustomelement\":\"1\",\"tdcustomcustom\":\"\",\"tdcustomtext\":\"\",\"tdteacherallinonerow\":\"0\",\"tdteacherallinonecol\":\"1\",\"tdteacherallinonecolspan\":\"1\",\"tdteacherallinoneelement\":\"1\",\"tdteacherallinonecustom\":\"\",\"series_title\":\"Our Series\",\"show_series_title\":\"1\",\"show_page_image_series\":\"1\",\"series_element\":\"1\",\"use_headers_series\":\"1\",\"series_show_description\":\"1\",\"series_characters\":\"\",\"search_series\":\"1\",\"series_list_teachers\":\"1\",\"series_list_years\":\"1\",\"series_list_show_pagination\":\"1\",\"series_list_order\":\"ASC\",\"series_order_field\":\"series_text\",\"srowspanitem\":\"0\",\"srowspanitemspan\":\"4\",\"srowspanitemimage\":\"img-polaroid\",\"srowspanitempull\":\"pull-left\",\"sseriesrow\":\"2\",\"sseriescol\":\"1\",\"sseriescolspan\":\"6\",\"sserieselement\":\"1\",\"sseriescustom\":\"\",\"sserieslinktype\":\"0\",\"sseriesthumbnailrow\":\"1\",\"sseriesthumbnailcol\":\"2\",\"sseriesthumbnailcolspan\":\"1\",\"sseriesthumbnailelement\":\"1\",\"sseriesthumbnailcustom\":\"\",\"sseriesthumbnaillinktype\":\"0\",\"steacherrow\":\"0\",\"steachercol\":\"1\",\"steachercolspan\":\"1\",\"steacherelement\":\"1\",\"steachercustom\":\"\",\"steacherlinktype\":\"0\",\"steacherimagerow\":\"0\",\"steacherimagecol\":\"1\",\"steacherimagecolspan\":\"1\",\"steacherimageelement\":\"1\",\"steacherimagecustom\":\"\",\"steacher-titlerow\":\"0\",\"steacher-titlecol\":\"1\",\"steacher-titlecolspan\":\"1\",\"steacher-titleelement\":\"1\",\"steacher-titlecustom\":\"\",\"steacher-titlelinktype\":\"0\",\"sdescriptionrow\":\"0\",\"sdescriptioncol\":\"1\",\"sdescriptioncolspan\":\"1\",\"sdescriptionelement\":\"1\",\"sdescriptioncustom\":\"\",\"sdescriptionlinktype\":\"0\",\"sdcustomrow\":\"0\",\"sdcustomcol\":\"1\",\"sdcustomcolspan\":\"1\",\"sdcustomelement\":\"1\",\"sdcustomcustom\":\"\",\"sdcustomtext\":\"\",\"series_detail_sort\":\"studydate\",\"series_detail_order\":\"DESC\",\"series_detail_limit\":\"\",\"series_list_return\":\"1\",\"sdrowspanitem\":\"0\",\"sdrowspanitemspan\":\"4\",\"sdrowspanitemimage\":\"img-polaroid\",\"sdrowspanitempull\":\"pull-left\",\"seriesdisplay_color\":\"\",\"use_header_seriesdisplay\":\"0\",\"sdseriesrow\":\"2\",\"sdseriescol\":\"1\",\"sdseriescolspan\":\"6\",\"sdserieselement\":\"1\",\"sdseriescustom\":\"\",\"sdserieslinktype\":\"0\",\"sdseriesthumbnailrow\":\"1\",\"sdseriesthumbnailcol\":\"2\",\"sdseriesthumbnailcolspan\":\"1\",\"sdseriesthumbnailelement\":\"1\",\"sdseriesthumbnailcustom\":\"\",\"sdseriesthumbnaillinktype\":\"0\",\"sdteacherrow\":\"0\",\"sdteachercol\":\"1\",\"sdteachercolspan\":\"1\",\"sdteacherelement\":\"1\",\"sdteachercustom\":\"\",\"sdteacherlinktype\":\"0\",\"sdteacherimagerow\":\"0\",\"sdteacherimagecol\":\"1\",\"sdteacherimagecolspan\":\"1\",\"sdteacherimageelement\":\"1\",\"sdteacherimagecustom\":\"\",\"sdteacher-titlerow\":\"0\",\"sdteacher-titlecol\":\"1\",\"sdteacher-titlecolspan\":\"1\",\"sdteacher-titleelement\":\"1\",\"sdteacher-titlecustom\":\"\",\"sdteacher-titlelinktype\":\"0\",\"sddescriptionrow\":\"0\",\"sddescriptioncol\":\"1\",\"sddescriptioncolspan\":\"1\",\"sddescriptionelement\":\"1\",\"sddescriptioncustom\":\"\",\"sddescriptionlinktype\":\"0\",\"tip_title\":\"Sermon Information\",\"tooltip\":\"1\",\"tip_item1_title\":\"Title\",\"tip_item1\":\"title\",\"tip_item2_title\":\"Details\",\"tip_item2\":\"title\",\"tip_item3_title\":\"Teacher\",\"tip_item3\":\"title\",\"tip_item4_title\":\"Reference\",\"tip_item4\":\"title\",\"tip_item5_title\":\"Date\",\"tip_item5\":\"title\",\"drowspanitem\":\"0\",\"drowspanitemspan\":\"4\",\"drowspanitemimage\":\"img-polaroid\",\"drowspanitempull\":\"pull-left\",\"dscripture1row\":\"1\",\"dscripture1col\":\"1\",\"dscripture1colspan\":\"1\",\"dscripture1element\":\"1\",\"dscripture1custom\":\"\",\"dscripture1linktype\":\"0\",\"dscripture2row\":\"0\",\"dscripture2col\":\"1\",\"dscripture2colspan\":\"1\",\"dscripture2element\":\"1\",\"dscripture2custom\":\"\",\"dscripture2linktype\":\"0\",\"dsecondaryrow\":\"0\",\"dsecondarycol\":\"1\",\"dsecondarycolspan\":\"1\",\"dsecondaryelement\":\"1\",\"dsecondarycustom\":\"\",\"dsecondarylinktype\":\"0\",\"djbsmediarow\":\"1\",\"djbsmediacol\":\"3\",\"djbsmediacolspan\":\"1\",\"djbsmediaelement\":\"1\",\"djbsmediacustom\":\"\",\"djbsmedialinktype\":\"0\",\"dcustomrow\":\"0\",\"dcustomcol\":\"1\",\"dcustomcolspan\":\"1\",\"dcustomelement\":\"1\",\"dcustomcustom\":\"\",\"dcustomtext\":\"\",\"dtitlerow\":\"1\",\"dtitlecol\":\"2\",\"dtitlecolspan\":\"3\",\"dtitleelement\":\"1\",\"dtitlecustom\":\"\",\"dtitlelinktype\":\"0\",\"ddaterow\":\"0\",\"ddatecol\":\"1\",\"ddatecolspan\":\"1\",\"ddateelement\":\"1\",\"ddatecustom\":\"\",\"ddatelinktype\":\"0\",\"dteacherrow\":\"0\",\"dteachercol\":\"1\",\"dteachercolspan\":\"1\",\"dteacherelement\":\"1\",\"dteachercustom\":\"\",\"dteacherlinktype\":\"0\",\"dteacherimagerrow\":\"0\",\"dteacherimagecol\":\"1\",\"dteacherimagecolspan\":\"1\",\"dteacherimageelement\":\"1\",\"dteacherimagecustom\":\"\",\"dteacher-titlerow\":\"0\",\"dteacher-titlecol\":\"1\",\"dteacher-titlecolspan\":\"1\",\"dteacher-titleelement\":\"1\",\"dteacher-titlecustom\":\"\",\"dteacher-titlelinktype\":\"0\",\"ddurationrow\":\"0\",\"ddurationcol\":\"1\",\"ddurationcolspan\":\"1\",\"ddurationelement\":\"1\",\"ddurationcustom\":\"\",\"ddurationlinktype\":\"0\",\"dstudyintrorow\":\"0\",\"dstudyintrocol\":\"1\",\"dstudyintrocolspan\":\"6\",\"dstudyintroelement\":\"1\",\"dstudyintrocustom\":\"\",\"dstudyintrolinktype\":\"0\",\"dseriesrow\":\"0\",\"dseriescol\":\"1\",\"dseriescolspan\":\"1\",\"dserieselement\":\"1\",\"dseriescustom\":\"\",\"dserieslinktype\":\"0\",\"dseriesthumbnailrow\":\"0\",\"dseriesthumbnailcol\":\"1\",\"dseriesthumbnailcolspan\":\"1\",\"dseriesthumbnailelement\":\"1\",\"dseriesthumbnailcustom\":\"\",\"dseriesthumbnaillinktype\":\"0\",\"dseriesdescriptionrow\":\"0\",\"dseriesdescriptioncol\":\"1\",\"dseriesdescriptioncolspan\":\"1\",\"dseriesdescriptionelement\":\"1\",\"dseriesdescriptioncustom\":\"\",\"dseriesdescriptionlinktype\":\"0\",\"dsubmittedrow\":\"0\",\"dsubmittedcol\":\"1\",\"dsubmittedcolspan\":\"1\",\"dsubmittedelement\":\"1\",\"dsubmittedcustom\":\"\",\"dsubmittedlinktype\":\"0\",\"dhitsrow\":\"0\",\"dhitscol\":\"1\",\"dhitscolspan\":\"6\",\"dhitselement\":\"1\",\"dhitscustom\":\"\",\"dhitslinktype\":\"0\",\"ddownloadsrow\":\"0\",\"ddownloadscol\":\"1\",\"ddownloadscolspan\":\"1\",\"ddownloadselement\":\"1\",\"ddownloadscustom\":\"\",\"ddownloadslinktype\":\"0\",\"dstudynumberrow\":\"0\",\"dstudynumbercol\":\"1\",\"dstudynumbercolspan\":\"1\",\"dstudynumberelement\":\"1\",\"dstudynumbercustom\":\"\",\"dstudynumberlinktype\":\"0\",\"dtopicrow\":\"0\",\"dtopiccol\":\"1\",\"dtopiccolspan\":\"6\",\"dtopicelement\":\"1\",\"dtopiccustom\":\"\",\"dtopiclinktype\":\"0\",\"dlocationsrow\":\"0\",\"dlocationscol\":\"1\",\"dlocationscolspan\":\"1\",\"dlocationselement\":\"1\",\"dlocationscustom\":\"\",\"dlocationslinktype\":\"0\",\"dmessagetyperow\":\"0\",\"dmessagetypecol\":\"1\",\"dmessagetypecolspan\":\"6\",\"dmessagetypeelement\":\"1\",\"dmessagetypecustom\":\"\",\"dmessagetypelinktype\":\"0\",\"dthumbnailrow\":\"0\",\"dthumbnailcol\":\"1\",\"dthumbnailcolspan\":\"1\",\"dthumbnailelement\":\"1\",\"dthumbnailcustom\":\"\",\"dthumbnaillinktype\":\"0\",\"landing_hide\":\"0\",\"landing_default_order\":\"ASC\",\"landing_hidelabel\":\"Show\\/Hide All\",\"headingorder_1\":\"teachers\",\"headingorder_2\":\"series\",\"headingorder_3\":\"books\",\"headingorder_4\":\"topics\",\"headingorder_5\":\"locations\",\"headingorder_6\":\"messagetypes\",\"headingorder_7\":\"years\",\"showteachers\":\"1\",\"landingteachersuselimit\":\"0\",\"landingteacherslimit\":\"\",\"teacherslabel\":\"Speakers\",\"linkto\":\"1\",\"showseries\":\"1\",\"landingseriesuselimit\":\"0\",\"landingserieslimit\":\"\",\"serieslabel\":\"Series\",\"series_linkto\":\"0\",\"showbooks\":\"1\",\"landingbookslimit\":\"\",\"bookslabel\":\"Books\",\"showtopics\":\"1\",\"landingtopicslimit\":\"\",\"topicslabel\":\"Topics\",\"showlocations\":\"1\",\"landinglocationsuselimit\":\"0\",\"landinglocationslimit\":\"\",\"locationslabel\":\"Locations\",\"showmessagetypes\":\"1\",\"landingmessagetypeuselimit\":\"0\",\"landingmessagetypeslimit\":\"\",\"messagetypeslabel\":\"Message Types\",\"showyears\":\"1\",\"landingyearslimit\":\"\",\"yearslabel\":\"Years\",\"series_order\":\"2\",\"books_order\":\"2\",\"teachers_order\":\"2\",\"years_order\":\"1\",\"topics_order\":\"2\",\"locations_order\":\"2\",\"messagetypes_order\":\"2\"}',`title`='Default',`text`='textfile24.png',`pdf`='pdf24.png',`asset_id`='202',`access`='1';

-- --------------------------------------------------------

--
-- Table structure for table `#__bsms_timeset`
--

DROP TABLE IF EXISTS `#__bsms_timeset`;
CREATE TABLE `#__bsms_timeset` (
  `timeset` varchar(14) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `backup` varchar(14) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`timeset`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


--
-- Dumping data for table `#__bsms_timeset`
--

INSERT INTO `#__bsms_timeset` SET `timeset`='1281646339',`backup`='1281646339';

-- --------------------------------------------------------

--
-- Table structure for table `#__bsms_topics`
--

DROP TABLE IF EXISTS `#__bsms_topics`;
CREATE TABLE `#__bsms_topics` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `topic_text` text COLLATE utf8mb4_unicode_ci,
  `published` tinyint NOT NULL DEFAULT '1',
  `params` varchar(511) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `asset_id` int unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `language` char(7) COLLATE utf8mb4_unicode_ci DEFAULT '*',
  `access` int unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_state` (`published`),
  KEY `idx_access` (`access`)
) ENGINE=InnoDB AUTO_INCREMENT=115 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


--
-- Dumping data for table `#__bsms_topics`
--

INSERT INTO `#__bsms_topics` SET `id`='1',`topic_text`='JBS_TOP_ABORTION',`published`='1',`params`=NULL,`asset_id`='200',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='2',`topic_text`='JBS_TOP_GODS_ACTIVITY',`published`='1',`params`=NULL,`asset_id`='199',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='3',`topic_text`='JBS_TOP_ADDICTION',`published`='1',`params`=NULL,`asset_id`='198',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='4',`topic_text`='JBS_TOP_AFTERLIFE',`published`='1',`params`=NULL,`asset_id`='197',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='5',`topic_text`='JBS_TOP_APOLOGETICS',`published`='1',`params`=NULL,`asset_id`='196',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='6',`topic_text`='JBS_TOP_GODS_ATTRIBUTES',`published`='1',`params`=NULL,`asset_id`='195',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='7',`topic_text`='JBS_TOP_BAPTISM',`published`='1',`params`=NULL,`asset_id`='194',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='8',`topic_text`='JBS_TOP_BASICS_OF_CHRISTIANITY',`published`='1',`params`=NULL,`asset_id`='193',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='9',`topic_text`='JBS_TOP_BECOMING_A_CHRISTIAN',`published`='1',`params`=NULL,`asset_id`='192',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='10',`topic_text`='JBS_TOP_BIBLE',`published`='1',`params`=NULL,`asset_id`='191',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='11',`topic_text`='JBS_TOP_JESUS_BIRTH',`published`='1',`params`=NULL,`asset_id`='190',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='12',`topic_text`='JBS_TOP_CHILDREN',`published`='1',`params`=NULL,`asset_id`='189',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='13',`topic_text`='JBS_TOP_CHRIST',`published`='1',`params`=NULL,`asset_id`='269',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='14',`topic_text`='JBS_TOP_CHRISTIAN_CHARACTER_FRUITS',`published`='1',`params`=NULL,`asset_id`='187',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='15',`topic_text`='JBS_TOP_CHRISTIAN_VALUES',`published`='1',`params`=NULL,`asset_id`='186',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='16',`topic_text`='JBS_TOP_CHRISTMAS_SEASON',`published`='1',`params`=NULL,`asset_id`='185',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='17',`topic_text`='JBS_TOP_CHURCH',`published`='1',`params`=NULL,`asset_id`='184',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='18',`topic_text`='JBS_TOP_COMMUNICATION',`published`='1',`params`=NULL,`asset_id`='183',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='19',`topic_text`='JBS_TOP_COMMUNION___LORDS_SUPPER',`published`='1',`params`=NULL,`asset_id`='182',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='21',`topic_text`='JBS_TOP_CREATION',`published`='1',`params`=NULL,`asset_id`='181',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='22',`topic_text`='JBS_TOP_JESUS_CROSS_FINAL_WEEK',`published`='1',`params`=NULL,`asset_id`='180',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='23',`topic_text`='JBS_TOP_CULTS',`published`='1',`params`=NULL,`asset_id`='179',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='24',`topic_text`='JBS_TOP_DEATH',`published`='1',`params`=NULL,`asset_id`='178',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='26',`topic_text`='JBS_TOP_DESCRIPTIONS_OF_GOD',`published`='1',`params`=NULL,`asset_id`='177',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='27',`topic_text`='JBS_TOP_DISCIPLES',`published`='1',`params`=NULL,`asset_id`='176',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='28',`topic_text`='JBS_TOP_DISCIPLESHIP',`published`='1',`params`=NULL,`asset_id`='175',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='29',`topic_text`='JBS_TOP_JESUS_DIVINITY',`published`='1',`params`=NULL,`asset_id`='174',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='30',`topic_text`='JBS_TOP_DIVORCE',`published`='1',`params`=NULL,`asset_id`='173',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='32',`topic_text`='JBS_TOP_EASTER_SEASON',`published`='1',`params`=NULL,`asset_id`='172',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='33',`topic_text`='JBS_TOP_EMOTIONS',`published`='1',`params`=NULL,`asset_id`='171',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='34',`topic_text`='JBS_TOP_ENTERTAINMENT',`published`='1',`params`=NULL,`asset_id`='170',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='35',`topic_text`='JBS_TOP_EVANGELISM',`published`='1',`params`=NULL,`asset_id`='169',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='36',`topic_text`='JBS_TOP_FAITH',`published`='1',`params`=NULL,`asset_id`='168',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='37',`topic_text`='JBS_TOP_BLENDED_FAMILY_RELATIONSHIPS',`published`='1',`params`=NULL,`asset_id`='167',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='39',`topic_text`='JBS_TOP_FORGIVING_OTHERS',`published`='1',`params`=NULL,`asset_id`='166',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='40',`topic_text`='JBS_TOP_GODS_FORGIVENESS',`published`='1',`params`=NULL,`asset_id`='165',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='41',`topic_text`='JBS_TOP_FRIENDSHIP',`published`='1',`params`=NULL,`asset_id`='164',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='42',`topic_text`='JBS_TOP_FULFILLMENT_IN_LIFE',`published`='1',`params`=NULL,`asset_id`='163',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='43',`topic_text`='JBS_TOP_FUND_RAISING_RALLY',`published`='1',`params`=NULL,`asset_id`='162',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='44',`topic_text`='JBS_TOP_FUNERALS',`published`='1',`params`=NULL,`asset_id`='161',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='45',`topic_text`='JBS_TOP_GIVING',`published`='1',`params`=NULL,`asset_id`='160',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='46',`topic_text`='JBS_TOP_GODS_WILL',`published`='1',`params`=NULL,`asset_id`='159',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='47',`topic_text`='JBS_TOP_HARDSHIP_OF_LIFE',`published`='1',`params`=NULL,`asset_id`='158',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='48',`topic_text`='JBS_TOP_HOLY_SPIRIT',`published`='1',`params`=NULL,`asset_id`='157',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='50',`topic_text`='JBS_TOP_JESUS_HUMANITY',`published`='1',`params`=NULL,`asset_id`='156',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='52',`topic_text`='JBS_TOP_KINGDOM_OF_GOD',`published`='1',`params`=NULL,`asset_id`='155',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='55',`topic_text`='JBS_TOP_LEADERSHIP_ESSENTIALS',`published`='1',`params`=NULL,`asset_id`='154',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='56',`topic_text`='JBS_TOP_JESUS_LIFE',`published`='1',`params`=NULL,`asset_id`='153',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='57',`topic_text`='JBS_TOP_LOVE',`published`='1',`params`=NULL,`asset_id`='152',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='58',`topic_text`='JBS_TOP_GODS_LOVE',`published`='1',`params`=NULL,`asset_id`='151',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='59',`topic_text`='JBS_TOP_MARRIAGE',`published`='1',`params`=NULL,`asset_id`='150',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='61',`topic_text`='JBS_TOP_JESUS_MIRACLES',`published`='1',`params`=NULL,`asset_id`='149',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='62',`topic_text`='JBS_TOP_MISCONCEPTIONS_OF_CHRISTIANITY',`published`='1',`params`=NULL,`asset_id`='148',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='63',`topic_text`='JBS_TOP_MONEY',`published`='1',`params`=NULL,`asset_id`='147',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='65',`topic_text`='JBS_TOP_GODS_NATURE',`published`='1',`params`=NULL,`asset_id`='146',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='66',`topic_text`='JBS_TOP_OUR_NEED_FOR_GOD',`published`='1',`params`=NULL,`asset_id`='145',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='69',`topic_text`='JBS_TOP_PARABLES',`published`='1',`params`=NULL,`asset_id`='144',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='70',`topic_text`='JBS_TOP_PARANORMAL',`published`='1',`params`=NULL,`asset_id`='143',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='71',`topic_text`='JBS_TOP_PARENTING',`published`='1',`params`=NULL,`asset_id`='142',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='73',`topic_text`='JBS_TOP_POVERTY',`published`='1',`params`=NULL,`asset_id`='141',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='74',`topic_text`='JBS_TOP_PRAYER',`published`='1',`params`=NULL,`asset_id`='140',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='76',`topic_text`='JBS_TOP_PROMINENT_N_T__MEN',`published`='1',`params`=NULL,`asset_id`='139',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='77',`topic_text`='JBS_TOP_PROMINENT_N_T__WOMEN',`published`='1',`params`=NULL,`asset_id`='138',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='78',`topic_text`='JBS_TOP_PROMINENT_O_T__MEN',`published`='1',`params`=NULL,`asset_id`='137',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='79',`topic_text`='JBS_TOP_PROMINENT_O_T__WOMEN',`published`='1',`params`=NULL,`asset_id`='136',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='82',`topic_text`='JBS_TOP_MESSIANIC_PROPHECIES',`published`='1',`params`=NULL,`asset_id`='135',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='83',`topic_text`='JBS_TOP_RACISM',`published`='1',`params`=NULL,`asset_id`='134',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='84',`topic_text`='JBS_TOP_JESUS_RESURRECTION',`published`='1',`params`=NULL,`asset_id`='133',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='85',`topic_text`='JBS_TOP_SECOND_COMING',`published`='1',`params`=NULL,`asset_id`='132',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='86',`topic_text`='JBS_TOP_SEXUALITY',`published`='1',`params`=NULL,`asset_id`='131',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='87',`topic_text`='JBS_TOP_SIN',`published`='1',`params`=NULL,`asset_id`='130',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='88',`topic_text`='JBS_TOP_SINGLENESS',`published`='1',`params`=NULL,`asset_id`='129',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='89',`topic_text`='JBS_TOP_SMALL_GROUPS',`published`='1',`params`=NULL,`asset_id`='128',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='90',`topic_text`='JBS_TOP_SPIRITUAL_DISCIPLINES',`published`='1',`params`=NULL,`asset_id`='127',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='91',`topic_text`='JBS_TOP_SPIRITUAL_GIFTS',`published`='1',`params`=NULL,`asset_id`='126',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='92',`topic_text`='JBS_TOP_SUPERNATURAL',`published`='1',`params`=NULL,`asset_id`='125',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='93',`topic_text`='JBS_TOP_JESUS_TEACHING',`published`='1',`params`=NULL,`asset_id`='124',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='94',`topic_text`='JBS_TOP_TEMPTATION',`published`='1',`params`=NULL,`asset_id`='123',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='95',`topic_text`='JBS_TOP_TEN_COMMANDMENTS',`published`='1',`params`=NULL,`asset_id`='122',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='97',`topic_text`='JBS_TOP_TRUTH',`published`='1',`params`=NULL,`asset_id`='121',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='98',`topic_text`='JBS_TOP_TWELVE_APOSTLES',`published`='1',`params`=NULL,`asset_id`='120',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='100',`topic_text`='JBS_TOP_WEDDINGS',`published`='1',`params`=NULL,`asset_id`='119',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='101',`topic_text`='JBS_TOP_WORKPLACE_ISSUES',`published`='1',`params`=NULL,`asset_id`='118',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='102',`topic_text`='JBS_TOP_WORLD_RELIGIONS',`published`='1',`params`=NULL,`asset_id`='117',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='103',`topic_text`='JBS_TOP_FAMILY',`published`='1',`params`=NULL,`asset_id`='116',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='104',`topic_text`='JBS_TOP_FREEDOM',`published`='1',`params`=NULL,`asset_id`='115',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='105',`topic_text`='JBS_TOP_STEWARDSHIP',`published`='1',`params`=NULL,`asset_id`='114',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='106',`topic_text`='JBS_TOP_WORSHIP',`published`='1',`params`=NULL,`asset_id`='113',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='107',`topic_text`='JBS_TOP_HOLIDAYS',`published`='1',`params`=NULL,`asset_id`='112',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='108',`topic_text`='JBS_TOP_SPECIAL_SERVICES',`published`='1',`params`=NULL,`asset_id`='111',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='109',`topic_text`='JBS_TOP_MEN',`published`='1',`params`=NULL,`asset_id`='110',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='110',`topic_text`='JBS_TOP_WOMEN',`published`='1',`params`=NULL,`asset_id`='109',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='111',`topic_text`='JBS_TOP_HOT_TOPICS',`published`='1',`params`=NULL,`asset_id`='108',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='112',`topic_text`='JBS_TOP_NARNIA',`published`='1',`params`=NULL,`asset_id`='107',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='113',`topic_text`='JBS_TOP_DA_VINCI_CODE',`published`='1',`params`=NULL,`asset_id`='106',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='114',`topic_text`='JBS_TOP_RAIN',`published`='1',`params`=NULL,`asset_id`='105',`language`='*',`access`='1';

-- --------------------------------------------------------

