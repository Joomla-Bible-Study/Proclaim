# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 9.1.x   | :white_check_mark: |
| 7.0.x   | :x:                |
| 8.0.x   | :white_check_mark: |
| < 6.x   | :x:                |

## Reporting a Vulnerability

Info coming soon.
