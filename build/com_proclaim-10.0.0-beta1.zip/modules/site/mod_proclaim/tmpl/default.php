<?php

/**
 * Default View
 *
 * @package     Proclaim
 * @subpackage  mod_proclaim
 * @copyright   (C) 2007 CWM Team All rights reserved
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @link        https://www.christianwebministries.org
 * */

\defined('_JEXEC') or die();

echo "hit default";
