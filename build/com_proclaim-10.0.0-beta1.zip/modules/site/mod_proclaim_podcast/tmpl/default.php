<?php

/**
 * Podcast Model default
 *
 * @package         Proclaim
 * @subpackage      mod_proclaim_podcast
 * @copyright   (C) 2007 CWM Team All rights reserved
 * @license         GNU General Public License version 2 or later; see LICENSE.txt
 * @link            https://www.christianwebministries.org
 */

// phpcs:disable PSR1.Files.SideEffects
\defined('_JEXEC') or die;
// phpcs:enable PSR1.Files.SideEffects

if (!$list) {
    return;
}

?>

<?php
echo $list; ?>
