<?php
defined('_JEXEC') or die;

class JBSServerLocal extends JBSServer {
    public $name = 'local';

    protected function __construct($options) {

    }

    protected function upload($target, $overwrite = true)
    {
        // TODO: Implement upload() method.
    }
}