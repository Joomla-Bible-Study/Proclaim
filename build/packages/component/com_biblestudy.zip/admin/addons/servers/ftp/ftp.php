<?php
defined('_JEXEC') or die;

class JBSServerFtp extends JBSServer {
    public $name = 'ftp';

    protected function __construct($options) {

    }

    protected function upload($target, $overwrite = true)
    {
        // TODO: Implement upload() method.
    }
}