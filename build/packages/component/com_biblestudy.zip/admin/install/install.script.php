<?php
/**
 * BibleStudy Component
 *
 * @package       BibleStudy.Installer
 *
 * @copyright (C) 2008 - 2016 BibleStudy Team. All rights reserved.
 * @license       http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link          http://www.joomlabiblestudy.org
 **/
defined('_JEXEC') or die ();

jimport('joomla.filesystem.folder');
jimport('joomla.filesystem.file');

/**
 * Class Com_BibleStudyInstallerScript
 */
class Com_BibleStudyInstallerScript
{
	protected $versions = array(
		'PHP'     => array(
			'5.3' => '5.3.1',
			'0'   => '5.4.23' // Preferred version
		),
		'MySQL'   => array(
			'5.1' => '5.1',
			'0'   => '5.5' // Preferred version
		),
		'Joomla!' => array(
			'3.4' => '3.4.1',
			'3.3' => '3.3.6',
			'2.5' => '2.5.28',
			'0'   => '3.4.1' // Preferred version
		)
	);
	protected $extensions = array('dom', 'gd', 'json', 'pcre', 'SimpleXML');

	/**
	 * JBSM Installer
	 *
	 * @param $parent
	 *
	 * @return bool
	 */
	public function install($parent)
	{
		// Delete all cached files.
		$cacheDir = JPATH_CACHE . '/jbsm';
		if (is_dir($cacheDir))
		{
			JFolder::delete($cacheDir);
		}
		JFolder::create($cacheDir);

		return true;
	}

	/**
	 * Installer Script Dicover
	 *
	 * @param $parent
	 *
	 * @return bool
	 */
	public function discover_install($parent)
	{
		return self::install($parent);
	}

	/**
	 * Update
	 *
	 * @param $parent
	 *
	 * @return bool
	 */
	public function update($parent)
	{
		return self::install($parent);
	}

	/**
	 * Uninstaller
	 *
	 * @param $parent
	 *
	 * @return bool
	 */
	public function uninstall($parent)
	{
		$adminpath = $parent->getParent()->getPath('extension_administrator');
		$model     = "{$adminpath}/install/model.php";
		if (file_exists($model))
		{
			require_once($model);
			$installer = new JBSMModelInstall();
			$installer->uninstall();
		}

		return true;
	}

	/**
	 * PreFlight
	 *
	 * @param $type
	 * @param $parent
	 *
	 * @return bool
	 */
	public function preflight($type, $parent)
	{
		$parent   = $parent->getParent();
		$manifest = $parent->getManifest();

		// Prevent installation if requirements are not met.
		if (!$this->checkRequirements($manifest->version))
		{
			return false;
		}

		$adminPath = $parent->getPath('extension_administrator');
		$sitePath  = $parent->getPath('extension_site');

		if (is_file($adminPath . '/biblestudy.php'))
		{
			// Kunena 2.0 or older release found, clean up the directories.
			static $ignoreAdmin = array('index.html', 'biblestudy.xml', 'archive');
			if (is_file($adminPath . '/install.script.php'))
			{
				// Kunena 1.7 or older release..
				$ignoreAdmin[] = 'install.script.php';
				$ignoreAdmin[] = 'biblestudy.php';
			}
			static $ignoreSite = array('index.html', 'biblestudy.php', 'router.php', 'COPYRIGHT.php', 'CHANGELOG.php');
			$this->deleteFolder($adminPath, $ignoreAdmin);
			$this->deleteFolder($sitePath, $ignoreSite);
		}

		// Prepare installation.
		$model = "{$adminPath}/install/model.php";
		if (file_exists($model))
		{
			require_once($model);
			$installer = new JBSMModelInstall();
			$installer->install();
		}

		return true;
	}

	/**
	 * Postflight
	 *
	 * @param $type
	 * @param $parent
	 *
	 * @return bool
	 */
	public function postflight($type, $parent)
	{
		return true;
	}

	/**
	 * Check Requirements
	 *
	 * @param $version
	 *
	 * @return bool|int
	 */
	public function checkRequirements($version)
	{
		$db   = JFactory::getDbo();
		$pass = $this->checkVersion('PHP', phpversion());
		$pass &= $this->checkVersion('Joomla!', JVERSION);
		$pass &= $this->checkVersion('MySQL', $db->getVersion());
		$pass &= $this->checkDbo($db->name, array('mysql', 'mysqli'));
		$pass &= $this->checkExtensions($this->extensions);
		$pass &= $this->checkJBSM($version);

		return $pass;
	}

	// Internal functions

	/**
	 * Check Version
	 *
	 * @param $name
	 * @param $version
	 *
	 * @return bool
	 * @throws \Exception
	 */
	protected function checkVersion($name, $version)
	{
		$app = JFactory::getApplication();

		$major = $minor = 0;
		foreach ($this->versions[$name] as $major => $minor)
		{
			if (!$major || version_compare($version, $major, '<'))
			{
				continue;
			}

			if (version_compare($version, $minor, '>='))
			{
				return true;
			}

			break;
		}
		if (!$major)
		{
			$minor = reset($this->versions[$name]);
		}
		$recommended = end($this->versions[$name]);
		$app->enqueueMessage(sprintf("%s %s is not supported. Minimum required version is %s %s, but it is higly recommended to use %s %s or later.", $name, $version, $name, $minor, $name, $recommended), 'notice');

		return false;
	}

	/**
	 * Check DBo
	 *
	 * @param $name
	 * @param $types
	 *
	 * @return bool
	 * @throws \Exception
	 */
	protected function checkDbo($name, $types)
	{
		$app = JFactory::getApplication();

		if (in_array($name, $types))
		{
			return true;
		}

		$app->enqueueMessage(sprintf("Database driver '%s' is not supported. Please use MySQL instead.", $name), 'notice');

		return false;
	}

	/**
	 * Check PHP Extensions
	 *
	 * @param $extensions
	 *
	 * @return int
	 * @throws \Exception
	 */
	protected function checkExtensions($extensions)
	{
		$app = JFactory::getApplication();

		$pass = 1;
		foreach ($extensions as $name)
		{
			if (!extension_loaded($name))
			{
				$pass = 0;
				$app->enqueueMessage(sprintf("Required PHP extension '%s' is missing. Please install it into your system.", $name), 'notice');
			}
		}

		return $pass;
	}

	/**
	 * Check to see if JBSM is correct
	 *
	 * @param $version
	 *
	 * @return bool
	 * @throws \Exception
	 */
	protected function checkJBSM($version)
	{
		$app = JFactory::getApplication();

		// Always load JBSM API if it exists.
		$api = JPATH_ADMINISTRATOR . '/components/com_biblestudy/api.php';

		if (file_exists($api))
		{
			require_once $api;
		}

		// Do not install over Git repository (K1.6+).
		if (class_exists('JBSM') && method_exists('JBSM', 'isDev') && JBSM::isDev())
		{
			$app->enqueueMessage('Oops! You should not install JBSM over your Git reporitory!', 'notice');

			return false;
		}

		$db = JFactory::getDBO();

		// Check if Kunena can be found from the database
		$table = $db->getPrefix() . 'bsms_version';
		$db->setQuery("SHOW TABLES LIKE {$db->quote($table)}");

		if ($db->loadResult() != $table)
		{
			return true;
		}

		// Get installed JBSM version
		$db->setQuery("SELECT version FROM {$db->quoteName($table)} ORDER BY `id` DESC", 0, 1);
		$installed = $db->loadResult();

		if (!$installed)
		{
			return true;
		}

		// Always allow upgrade to the newer version
		if (version_compare($version, $installed, '>='))
		{
			return true;
		}

		// Check if we can downgrade to the current version
		if (class_exists('JBSMInstaller'))
		{
			if (JBSMInstaller::canDowngrade($version))
			{
				return true;
			}
		}
		else
		{
			// Workaround when Kunena files were removed to allow downgrade between bugfix versions.
			$major = preg_replace('/(\d+.\d+)\..*$/', '\\1', $version);

			if (version_compare($installed, $major, '>'))
			{
				return true;
			}
		}

		$app->enqueueMessage(sprintf('Sorry, it is not possible to downgrade JBSM %s to version %s.', $installed, $version), 'notice');

		return false;
	}

	/**
	 * Delete Files not needed
	 *
	 * @param       $path
	 * @param array $ignore
	 */
	public function deleteFiles($path, $ignore = array())
	{
		$ignore = array_merge($ignore, array('.git', '.svn', 'CVS', '.DS_Store', '__MACOSX'));

		if (JFolder::exists($path))
		{
			foreach (JFolder::files($path, '.', false, true, $ignore) as $file)
			{
				if (JFile::exists($file))
				{
					JFile::delete($file);
				}
			}
		}
	}

	/**
	 * Delete Folders not Needed.
	 *
	 * @param       $path
	 * @param array $ignore
	 */
	public function deleteFolders($path, $ignore = array())
	{
		$ignore = array_merge($ignore, array('.git', '.svn', 'CVS', '.DS_Store', '__MACOSX'));

		if (JFolder::exists($path))
		{
			foreach (JFolder::folders($path, '.', false, true, $ignore) as $folder)
			{
				if (JFolder::exists($folder))
				{
					JFolder::delete($folder);
				}
			}
		}
	}

	/**
	 * Delete Individual Folder
	 *
	 * @param       $path
	 * @param array $ignore
	 */
	public function deleteFolder($path, $ignore = array())
	{
		$this->deleteFiles($path, $ignore);
		$this->deleteFolders($path, $ignore);
	}
}
