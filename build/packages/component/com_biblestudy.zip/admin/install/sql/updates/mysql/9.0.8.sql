INSERT INTO `#__bsms_update` (id, version) VALUES ('21', '9.0.8')
ON DUPLICATE KEY UPDATE version = '9.0.8';