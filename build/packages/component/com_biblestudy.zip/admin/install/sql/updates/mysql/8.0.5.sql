INSERT INTO `#__bsms_update` (id, version) VALUES (16, '8.0.5')
ON DUPLICATE KEY UPDATE version= '8.0.5';
