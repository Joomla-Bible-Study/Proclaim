INSERT INTO `#__bsms_update` (id, version) VALUES (11, '7.0.3')
ON DUPLICATE KEY UPDATE version= '7.0.3';
