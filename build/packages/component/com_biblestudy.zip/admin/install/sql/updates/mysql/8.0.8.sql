INSERT INTO `#__bsms_update` (id, version) VALUES (18, '8.0.8')
ON DUPLICATE KEY UPDATE version = '8.0.8';
