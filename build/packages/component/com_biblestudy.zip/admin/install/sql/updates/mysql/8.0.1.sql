INSERT INTO `#__bsms_update` (id, version) VALUES (12, '8.0.1')
ON DUPLICATE KEY UPDATE version= '8.0.1';
