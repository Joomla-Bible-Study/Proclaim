INSERT INTO `#__bsms_update` (id, version) VALUES (15, '7.1.2')
ON DUPLICATE KEY UPDATE version= '7.1.2';
