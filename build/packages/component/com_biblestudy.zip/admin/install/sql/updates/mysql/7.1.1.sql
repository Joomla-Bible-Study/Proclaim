INSERT INTO `#__bsms_update` (id, version) VALUES (14, '7.1.1')
ON DUPLICATE KEY UPDATE version = '7.1.1';
