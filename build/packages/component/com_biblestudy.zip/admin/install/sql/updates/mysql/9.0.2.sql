INSERT INTO `#__bsms_update` (id, version) VALUES ('20', '9.0.2')
ON DUPLICATE KEY UPDATE version = '9.0.2';