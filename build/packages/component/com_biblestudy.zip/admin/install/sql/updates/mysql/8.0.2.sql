INSERT INTO `#__bsms_update` (id, version) VALUES (13, '8.0.2')
ON DUPLICATE KEY UPDATE version= '8.0.2';
