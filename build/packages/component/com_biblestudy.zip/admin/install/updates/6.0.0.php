<?php
defined('_JEXEC') or die;


class Migration600 {

	function up($db) {
		return "6.0.0 up complete";
	}

	function down() {
		return "down complete";
	}
}
?>