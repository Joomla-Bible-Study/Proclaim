<?php
defined('_JEXEC') or die;


class Migration601 {
	function up() {
		return "6.0.1 up complete";
	}

	function down() {
		return "down complete";
	}
}
?>