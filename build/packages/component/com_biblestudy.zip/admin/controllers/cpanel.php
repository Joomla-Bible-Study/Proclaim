<?php
/**
 * Part of Joomla BibleStudy Package
 *
 * @package    BibleStudy.Admin
 * @copyright  2007 - 2016 (C) Joomla Bible Study Team All rights reserved
 * @license    http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link       http://www.JoomlaBibleStudy.org
 * */
// No Direct Access
defined('_JEXEC') or die;

/**
 * Controller for the cPanel
 *
 * @package  BibleStudy.Admin
 * @since    7.0.0
 */
class BiblestudyControllerCpanel extends JControllerForm
{
	// Holder for new controllers.
}
