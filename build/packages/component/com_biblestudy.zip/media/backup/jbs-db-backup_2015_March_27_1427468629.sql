
--
-- JBS Version 9.0.0
--

--
-- Table structure for table `#__bsms_admin`
--

DROP TABLE IF EXISTS `#__bsms_admin`;
CREATE TABLE `#__bsms_admin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `drop_tables` int(3) DEFAULT '0',
  `params` text,
  `asset_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `installstate` text,
  `debug` tinyint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_access` (`access`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


--
-- Dumping data for table `#__bsms_admin`
--

INSERT INTO `#__bsms_admin` SET `id`='1',`drop_tables`='0',`params`='{\"metakey\":\"\",\"metadesc\":\"\",\"compat_mode\":\"0\",\"jbsmigrationshow\":\"0\",\"studylistlimit\":\"10\",\"show_location_media\":\"0\",\"popular_limit\":\"\",\"character_filter\":\"1\",\"format_popular\":\"0\",\"default_main_image\":\"\",\"default_series_image\":\"\",\"default_teacher_image\":\"\",\"default_download_image\":\"\",\"default_showHide_image\":\"\",\"thumbnail_teacher_size\":\"150\",\"thumbnail_series_size\":\"150\",\"thumbnail_study_size\":\"150\",\"location_id\":\"-1\",\"teacher_id\":\"1\",\"series_id\":\"-1\",\"booknumber\":\"-1\",\"messagetype\":\"-1\",\"default_study_image\":\"\",\"download\":\"1\",\"target\":\" \",\"server\":\"1\",\"podcast\":[\"-1\"],\"from\":\"x\",\"to\":\"x\",\"pFrom\":\"x\",\"pTo\":\"x\",\"controls\":\"1\",\"jwplayer_pro\":\"0\",\"jwplayer_key\":\"\",\"jwplayer_cdn\":\"\",\"jwplayer_image\":\"\",\"jwplayer_skin\":\"\",\"jwplayer_autostart\":\"false\",\"jwplayer_fallback\":\"true\",\"jwplayer_mute\":\"false\",\"jwplayer_stagevideo\":\"false\",\"jwplayer_primary\":\"html5\",\"playlist\":\"false\",\"jwplayer_logo\":\"\",\"sharing\":\"false\",\"jwplayer_related\":\"false\",\"jwplayer_advertising\":\"\",\"rtmp\":\"Comming Soon\",\"ga\":\"Comming Soon\",\"jwplayer_sitecatalyst\":\"Comming Soon\",\"captions\":\"false\"}',`asset_id`='182',`access`='1',`installstate`=NULL,`debug`='0';

-- --------------------------------------------------------

--
-- Table structure for table `#__bsms_books`
--

DROP TABLE IF EXISTS `#__bsms_books`;
CREATE TABLE `#__bsms_books` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bookname` varchar(250) DEFAULT NULL,
  `booknumber` int(5) DEFAULT NULL,
  `published` tinyint(3) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_state` (`published`)
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8;


--
-- Dumping data for table `#__bsms_books`
--

INSERT INTO `#__bsms_books` SET `id`='1',`bookname`='JBS_BBK_GENESIS',`booknumber`='101',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='2',`bookname`='JBS_BBK_EXODUS',`booknumber`='102',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='3',`bookname`='JBS_BBK_LEVITICUS',`booknumber`='103',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='4',`bookname`='JBS_BBK_NUMBERS',`booknumber`='104',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='5',`bookname`='JBS_BBK_DEUTERONOMY',`booknumber`='105',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='6',`bookname`='JBS_BBK_JOSHUA',`booknumber`='106',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='7',`bookname`='JBS_BBK_JUDGES',`booknumber`='107',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='8',`bookname`='JBS_BBK_RUTH',`booknumber`='108',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='9',`bookname`='JBS_BBK_1SAMUEL',`booknumber`='109',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='10',`bookname`='JBS_BBK_2SAMUEL',`booknumber`='110',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='11',`bookname`='JBS_BBK_1KINGS',`booknumber`='111',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='12',`bookname`='JBS_BBK_2KINGS',`booknumber`='112',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='13',`bookname`='JBS_BBK_1CHRONICLES',`booknumber`='113',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='14',`bookname`='JBS_BBK_2CHRONICLES',`booknumber`='114',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='15',`bookname`='JBS_BBK_EZRA',`booknumber`='115',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='16',`bookname`='JBS_BBK_NEHEMIAH',`booknumber`='116',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='17',`bookname`='JBS_BBK_ESTHER',`booknumber`='117',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='18',`bookname`='JBS_BBK_JOB',`booknumber`='118',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='19',`bookname`='JBS_BBK_PSALM',`booknumber`='119',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='20',`bookname`='JBS_BBK_PROVERBS',`booknumber`='120',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='21',`bookname`='JBS_BBK_ECCLESIASTES',`booknumber`='121',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='22',`bookname`='JBS_BBK_SONG_OF_SOLOMON',`booknumber`='122',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='23',`bookname`='JBS_BBK_ISAIAH',`booknumber`='123',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='24',`bookname`='JBS_BBK_JEREMIAH',`booknumber`='124',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='25',`bookname`='JBS_BBK_LAMENTATIONS',`booknumber`='125',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='26',`bookname`='JBS_BBK_EZEKIEL',`booknumber`='126',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='27',`bookname`='JBS_BBK_DANIEL',`booknumber`='127',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='28',`bookname`='JBS_BBK_HOSEA',`booknumber`='128',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='29',`bookname`='JBS_BBK_JOEL',`booknumber`='129',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='30',`bookname`='JBS_BBK_AMOS',`booknumber`='130',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='31',`bookname`='JBS_BBK_OBADIAH',`booknumber`='131',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='32',`bookname`='JBS_BBK_JONAH',`booknumber`='132',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='33',`bookname`='JBS_BBK_MICAH',`booknumber`='133',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='34',`bookname`='JBS_BBK_NAHUM',`booknumber`='134',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='35',`bookname`='JBS_BBK_HABAKKUK',`booknumber`='135',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='36',`bookname`='JBS_BBK_ZEPHANIAH',`booknumber`='136',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='37',`bookname`='JBS_BBK_HAGGAI',`booknumber`='137',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='38',`bookname`='JBS_BBK_ZECHARIAH',`booknumber`='138',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='39',`bookname`='JBS_BBK_MALACHI',`booknumber`='139',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='40',`bookname`='JBS_BBK_MATTHEW',`booknumber`='140',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='41',`bookname`='JBS_BBK_MARK',`booknumber`='141',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='42',`bookname`='JBS_BBK_LUKE',`booknumber`='142',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='43',`bookname`='JBS_BBK_JOHN',`booknumber`='143',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='44',`bookname`='JBS_BBK_ACTS',`booknumber`='144',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='45',`bookname`='JBS_BBK_ROMANS',`booknumber`='145',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='46',`bookname`='JBS_BBK_1CORINTHIANS',`booknumber`='146',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='47',`bookname`='JBS_BBK_2CORINTHIANS',`booknumber`='147',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='48',`bookname`='JBS_BBK_GALATIANS',`booknumber`='148',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='49',`bookname`='JBS_BBK_EPHESIANS',`booknumber`='149',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='50',`bookname`='JBS_BBK_PHILIPPIANS',`booknumber`='150',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='51',`bookname`='JBS_BBK_COLOSSIANS',`booknumber`='151',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='52',`bookname`='JBS_BBK_1THESSALONIANS',`booknumber`='152',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='53',`bookname`='JBS_BBK_2THESSALONIANS',`booknumber`='153',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='54',`bookname`='JBS_BBK_1TIMOTHY',`booknumber`='154',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='55',`bookname`='JBS_BBK_2TIMOTHY',`booknumber`='155',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='56',`bookname`='JBS_BBK_TITUS',`booknumber`='156',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='57',`bookname`='JBS_BBK_PHILEMON',`booknumber`='157',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='58',`bookname`='JBS_BBK_HEBREWS',`booknumber`='158',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='59',`bookname`='JBS_BBK_JAMES',`booknumber`='159',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='60',`bookname`='JBS_BBK_1PETER',`booknumber`='160',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='61',`bookname`='JBS_BBK_2PETER',`booknumber`='161',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='62',`bookname`='JBS_BBK_1JOHN',`booknumber`='162',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='63',`bookname`='JBS_BBK_2JOHN',`booknumber`='163',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='64',`bookname`='JBS_BBK_3JOHN',`booknumber`='164',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='65',`bookname`='JBS_BBK_JUDE',`booknumber`='165',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='66',`bookname`='JBS_BBK_REVELATION',`booknumber`='166',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='67',`bookname`='JBS_BBK_TOBIT',`booknumber`='167',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='68',`bookname`='JBS_BBK_JUDITH',`booknumber`='168',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='69',`bookname`='JBS_BBK_1MACCABEES',`booknumber`='169',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='70',`bookname`='JBS_BBK_2MACCABEES',`booknumber`='170',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='71',`bookname`='JBS_BBK_WISDOM',`booknumber`='171',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='72',`bookname`='JBS_BBK_SIRACH',`booknumber`='172',`published`='1';
INSERT INTO `#__bsms_books` SET `id`='73',`bookname`='JBS_BBK_BARUCH',`booknumber`='173',`published`='1';

-- --------------------------------------------------------

--
-- Table structure for table `#__bsms_comments`
--

DROP TABLE IF EXISTS `#__bsms_comments`;
CREATE TABLE `#__bsms_comments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `published` tinyint(3) NOT NULL DEFAULT '0',
  `study_id` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `full_name` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_text` text NOT NULL,
  `asset_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `language` char(7) NOT NULL COMMENT 'The language code for the Comments.',
  PRIMARY KEY (`id`),
  KEY `idx_state` (`published`),
  KEY `idx_access` (`access`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


--
-- Dumping data for table `#__bsms_comments`
--


-- --------------------------------------------------------

--
-- Table structure for table `#__bsms_locations`
--

DROP TABLE IF EXISTS `#__bsms_locations`;
CREATE TABLE `#__bsms_locations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `location_text` varchar(250) DEFAULT NULL,
  `contact_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Used to link to com_contact',
  `address` text,
  `suburb` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `postcode` varchar(100) DEFAULT NULL,
  `telephone` varchar(255) DEFAULT NULL,
  `fax` varchar(255) DEFAULT NULL,
  `misc` mediumtext,
  `image` varchar(255) DEFAULT NULL,
  `email_to` varchar(255) DEFAULT NULL,
  `default_con` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `params` text NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `mobile` varchar(255) NOT NULL DEFAULT '',
  `webpage` varchar(255) NOT NULL DEFAULT '',
  `sortname1` varchar(255) NOT NULL,
  `sortname2` varchar(255) NOT NULL,
  `sortname3` varchar(255) NOT NULL,
  `language` char(7) NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `metadata` text NOT NULL,
  `featured` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Set if article is featured.',
  `xreference` varchar(50) NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published` tinyint(3) NOT NULL DEFAULT '1',
  `asset_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `access` int(10) unsigned NOT NULL DEFAULT '1',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `landing_show` int(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_state` (`published`),
  KEY `idx_access` (`access`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;


--
-- Dumping data for table `#__bsms_locations`
--

INSERT INTO `#__bsms_locations` SET `id`='1',`location_text`='My Location',`contact_id`='0',`address`=NULL,`suburb`=NULL,`state`=NULL,`country`=NULL,`postcode`=NULL,`telephone`=NULL,`fax`=NULL,`misc`=NULL,`image`=NULL,`email_to`=NULL,`default_con`='0',`checked_out`='0',`checked_out_time`='0000-00-00 00:00:00',`params`='',`user_id`='0',`mobile`='',`webpage`='',`sortname1`='',`sortname2`='',`sortname3`='',`language`='',`created`='0000-00-00 00:00:00',`created_by`='0',`created_by_alias`='',`modified`='0000-00-00 00:00:00',`modified_by`='0',`metakey`='',`metadesc`='',`metadata`='',`featured`='0',`xreference`='',`version`='1',`hits`='0',`publish_up`='0000-00-00 00:00:00',`publish_down`='0000-00-00 00:00:00',`published`='1',`asset_id`='2145',`access`='1',`ordering`='1',`landing_show`=NULL;
INSERT INTO `#__bsms_locations` SET `id`='2',`location_text`='Second Campus',`contact_id`='0',`address`=NULL,`suburb`=NULL,`state`=NULL,`country`=NULL,`postcode`=NULL,`telephone`=NULL,`fax`=NULL,`misc`=NULL,`image`=NULL,`email_to`=NULL,`default_con`='0',`checked_out`='0',`checked_out_time`='0000-00-00 00:00:00',`params`='',`user_id`='0',`mobile`='',`webpage`='',`sortname1`='',`sortname2`='',`sortname3`='',`language`='*',`created`='0000-00-00 00:00:00',`created_by`='0',`created_by_alias`='',`modified`='0000-00-00 00:00:00',`modified_by`='0',`metakey`='',`metadesc`='',`metadata`='',`featured`='0',`xreference`='',`version`='1',`hits`='0',`publish_up`='0000-00-00 00:00:00',`publish_down`='0000-00-00 00:00:00',`published`='1',`asset_id`='3866',`access`='1',`ordering`='0',`landing_show`='1';

-- --------------------------------------------------------

--
-- Table structure for table `#__bsms_mediafiles`
--

DROP TABLE IF EXISTS `#__bsms_mediafiles`;
CREATE TABLE `#__bsms_mediafiles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `study_id` int(5) DEFAULT NULL,
  `server_id` int(5) DEFAULT NULL,
  `podcast_id` varchar(50) DEFAULT NULL,
  `params` text,
  `metadata` text,
  `downloads` int(10) DEFAULT '0',
  `plays` int(10) DEFAULT '0',
  `hits` int(10) DEFAULT '0',
  `player` int(2) DEFAULT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0',
  `createdate` datetime DEFAULT NULL,
  `published` tinyint(3) NOT NULL DEFAULT '1',
  `comment` text,
  `asset_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `access` int(10) unsigned NOT NULL DEFAULT '1',
  `language` char(7) NOT NULL COMMENT 'The language code for the MediaFile.',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_state` (`published`),
  KEY `idx_study_id` (`study_id`),
  KEY `idx_access` (`access`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


--
-- Dumping data for table `#__bsms_mediafiles`
--

INSERT INTO `#__bsms_mediafiles` SET `id`='1',`study_id`='1',`server_id`='1',`podcast_id`='1',`params`='{\"link_type\":\"\",\"docMan_id\":\"-1\",\"article_id\":\"-1\",\"virtueMart_id\":\"0\",\"player\":\"\",\"popup\":\"\",\"mediacode\":\"\",\"filename\":\"www.calvarychapelnewberg.net\\/MediaFiles\\/2014\\/2014-004.mp3\",\"size\":\"\",\"special\":\"\",\"localFolder\":\"\",\"media_image\":\"\",\"mime_type\":\"\",\"playerwidth\":\"\",\"playerheight\":\"\",\"itempopuptitle\":\"\",\"itempopupfooter\":\"\",\"popupmargin\":\"50\",\"autostart\":\"\"}',`metadata`='{statistics: {plays: 0, downloads: 0}}',`downloads`='0',`plays`='0',`hits`='0',`player`='1',`ordering`='0',`createdate`='2009-09-13 00:10:00',`published`='1',`comment`='Sample Media file',`asset_id`='61',`access`='1',`language`='*',`created_by`='1',`created_by_alias`='admin',`modified`='0000-00-00 00:00:00',`modified_by`='1';

-- --------------------------------------------------------

--
-- Table structure for table `#__bsms_message_type`
--

DROP TABLE IF EXISTS `#__bsms_message_type`;
CREATE TABLE `#__bsms_message_type` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `message_type` text NOT NULL,
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `published` tinyint(3) NOT NULL DEFAULT '1',
  `asset_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `access` int(10) unsigned NOT NULL DEFAULT '1',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `landing_show` int(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_state` (`published`),
  KEY `idx_access` (`access`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;


--
-- Dumping data for table `#__bsms_message_type`
--

INSERT INTO `#__bsms_message_type` SET `id`='1',`message_type`='Sunday',`alias`='sunday',`published`='1',`asset_id`='2147',`access`='1',`ordering`='1',`landing_show`=NULL;
INSERT INTO `#__bsms_message_type` SET `id`='2',`message_type`='Wednesday',`alias`='wednesday',`published`='1',`asset_id`='1200',`access`='1',`ordering`='2',`landing_show`='1';

-- --------------------------------------------------------

--
-- Table structure for table `#__bsms_order`
--

DROP TABLE IF EXISTS `#__bsms_order`;
CREATE TABLE `#__bsms_order` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `value` varchar(15) DEFAULT '',
  `text` varchar(50) DEFAULT '',
  `asset_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_access` (`access`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;


--
-- Dumping data for table `#__bsms_order`
--

INSERT INTO `#__bsms_order` SET `id`='1',`value`='ASC',`text`='JBS_CMN_ASCENDING',`asset_id`='0',`access`='1';
INSERT INTO `#__bsms_order` SET `id`='2',`value`='DESC',`text`='JBS_CMN_DESCENDING',`asset_id`='0',`access`='1';

-- --------------------------------------------------------

--
-- Table structure for table `#__bsms_podcast`
--

DROP TABLE IF EXISTS `#__bsms_podcast`;
CREATE TABLE `#__bsms_podcast` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) DEFAULT NULL,
  `website` varchar(100) DEFAULT NULL,
  `description` text,
  `image` varchar(130) DEFAULT NULL,
  `imageh` int(3) DEFAULT NULL,
  `imagew` int(3) DEFAULT NULL,
  `author` varchar(100) DEFAULT NULL,
  `podcastimage` varchar(130) DEFAULT NULL,
  `podcastsearch` varchar(255) DEFAULT NULL,
  `filename` varchar(150) DEFAULT NULL,
  `language` varchar(10) DEFAULT 'en-us',
  `editor_name` varchar(150) DEFAULT NULL,
  `editor_email` varchar(150) DEFAULT NULL,
  `podcastlimit` int(5) DEFAULT NULL,
  `published` tinyint(3) NOT NULL DEFAULT '1',
  `episodetitle` int(11) DEFAULT NULL,
  `custom` varchar(200) DEFAULT NULL,
  `detailstemplateid` int(11) DEFAULT NULL,
  `asset_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `access` int(10) unsigned NOT NULL DEFAULT '1',
  `alternatelink` varchar(300) DEFAULT NULL COMMENT 'replaces podcast file link on subscription',
  `alternateimage` varchar(150) DEFAULT NULL COMMENT 'alternate image path for podcast',
  `podcast_subscribe_show` int(3) DEFAULT NULL,
  `podcast_image_subscribe` varchar(150) DEFAULT NULL COMMENT 'The image to use for the podcast subscription image',
  `podcast_subscribe_desc` varchar(150) DEFAULT NULL COMMENT 'Words to go below podcast subscribe image',
  `alternatewords` varchar(20) DEFAULT NULL,
  `episodesubtitle` int(11) DEFAULT NULL,
  `customsubtitle` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_state` (`published`),
  KEY `idx_access` (`access`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


--
-- Dumping data for table `#__bsms_podcast`
--

INSERT INTO `#__bsms_podcast` SET `id`='1',`title`='My Podcast',`website`='www.mywebsite.com',`description`='Podcast Description goes here',`image`='www.mywebsite.com/myimage.jpg',`imageh`='30',`imagew`='30',`author`='Pastor Billy',`podcastimage`='www.mywebsite.com/myimage.jpg',`podcastsearch`='jesus',`filename`='mypodcast.xml',`language`='*',`editor_name`='Jim Editor',`editor_email`='jim@mywebsite.com',`podcastlimit`='50',`published`='1',`episodetitle`='0',`custom`='',`detailstemplateid`='1',`asset_id`='2148',`access`='1',`alternatelink`=NULL,`alternateimage`=NULL,`podcast_subscribe_show`=NULL,`podcast_image_subscribe`=NULL,`podcast_subscribe_desc`=NULL,`alternatewords`=NULL,`episodesubtitle`=NULL,`customsubtitle`=NULL;

-- --------------------------------------------------------

--
-- Table structure for table `#__bsms_series`
--

DROP TABLE IF EXISTS `#__bsms_series`;
CREATE TABLE `#__bsms_series` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `series_text` text,
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `teacher` int(3) DEFAULT NULL,
  `description` text,
  `series_thumbnail` varchar(150) DEFAULT NULL,
  `published` tinyint(3) NOT NULL DEFAULT '1',
  `asset_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `access` int(10) unsigned NOT NULL DEFAULT '1',
  `language` char(7) NOT NULL COMMENT 'The language code for the Series.',
  `landing_show` int(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_state` (`published`),
  KEY `idx_access` (`access`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;


--
-- Dumping data for table `#__bsms_series`
--

INSERT INTO `#__bsms_series` SET `id`='1',`series_text`='Worship Series',`alias`='worship-series',`teacher`='1',`description`='',`series_thumbnail`='',`published`='1',`asset_id`='79',`ordering`='1',`access`='1',`language`='*',`landing_show`='1';
INSERT INTO `#__bsms_series` SET `id`='2',`series_text`='Colossians',`alias`='colossians',`teacher`='2',`description`='<p>A series on Colossians</p>',`series_thumbnail`='',`published`='1',`asset_id`='1201',`ordering`='2',`access`='1',`language`='*',`landing_show`='1';

-- --------------------------------------------------------

--
-- Table structure for table `#__bsms_servers`
--

DROP TABLE IF EXISTS `#__bsms_servers`;
CREATE TABLE `#__bsms_servers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `server_name` varchar(250) NOT NULL DEFAULT '',
  `type` char(255) NOT NULL,
  `published` tinyint(3) NOT NULL DEFAULT '1',
  `asset_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `access` int(10) unsigned NOT NULL DEFAULT '1',
  `params` text NOT NULL,
  `media` text,
  PRIMARY KEY (`id`),
  KEY `idx_state` (`published`),
  KEY `idx_access` (`access`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;


--
-- Dumping data for table `#__bsms_servers`
--

INSERT INTO `#__bsms_servers` SET `id`='1',`server_name`='Legacy',`type`='legacy',`published`='1',`asset_id`='2143',`access`='1',`params`='{\"path\":\"//www.calvarychapelnewberg.net/\"}',`media`=NULL;
INSERT INTO `#__bsms_servers` SET `id`='2',`server_name`='Server1',`type`='local',`published`='1',`asset_id`='1216',`access`='1',`params`='',`media`='{\"baseurl\":\"www.CalvaryNewberg.net\"}';

-- --------------------------------------------------------

--
-- Table structure for table `#__bsms_share`
--

DROP TABLE IF EXISTS `#__bsms_share`;
CREATE TABLE `#__bsms_share` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT NULL,
  `params` text,
  `published` tinyint(3) NOT NULL DEFAULT '1',
  `asset_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `access` int(10) unsigned NOT NULL DEFAULT '1',
  `ordering` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_state` (`published`),
  KEY `idx_access` (`access`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;


--
-- Dumping data for table `#__bsms_share`
--

INSERT INTO `#__bsms_share` SET `id`='1',`name`='FaceBook',`params`='{\"mainlink\":\"http://www.facebook.com/sharer.php?\",\"item1prefix\":\"u=\",\"item1\":200,\"item1custom\":\"\",\"item2prefix\":\"t=\",\"item2\":5,\"item2custom\":\"\",\"item3prefix\":\"\",\"item3\":6,\"item3custom\":\"\",\"item4prefix\":\"\",\"item4\":8,\"item4custom\":\"\",\"use_bitly\":0,\"username\":\"\",\"api\":\"\",\"shareimage\":\"media/com_biblestudy/images/facebook.png\",\"shareimageh\":\"33px\",\"shareimagew\":\"33px\",\"totalcharacters\":\"\",\"alttext\":\"FaceBook\"}',`published`='1',`asset_id`='2150',`access`='1',`ordering`='1';
INSERT INTO `#__bsms_share` SET `id`='2',`name`='Twitter',`params`='{\"mainlink\":\"http://twitter.com/nfsda?\",\"item1prefix\":\"status=\",\"item1\":200,\"item1custom\":\"\",\"item2prefix\":\"\",\"item2\":5,\"item2custom\":\"\",\"item3prefix\":\"\",\"item3\":1,\"item3custom\":\"\",\"item4prefix\":\"\",\"item4\":0,\"item4custom\":\"\",\"use_bitly\":0,\"username\":\"\",\"api\":\"\",\"shareimage\":\"media/com_biblestudy/images/twitter.png\",\"shareimageh\":\"33px\",\"shareimagew\":\"33px\",\"totalcharacters\":140,\"alttext\":\"Twitter\"}',`published`='1',`asset_id`='2151',`access`='1',`ordering`='2';
INSERT INTO `#__bsms_share` SET `id`='3',`name`='Delicious',`params`='{\"mainlink\":\"http://delicious.com/save?\",\"item1prefix\":\"url=\",\"item1\":200,\"item1custom\":\"\",\"item2prefix\":\"&title=\",\"item2\":5,\"item2custom\":\"\",\"item3prefix\":\"\",\"item3\":6,\"item3custom\":\"\",\"item4prefix\":\"\",\"item4\":\"\",\"item4custom\":\"\",\"use_bitly\":0,\"username\":\"\",\"api\":\"\",\"shareimage\":\"media/com_biblestudy/images/delicious.png\",\"shareimagew\":\"33px\",\"shareimageh\":\"33px\",\"totalcharacters\":\"\",\"alttext\":\"Delicious\"}',`published`='1',`asset_id`='2152',`access`='1',`ordering`='3';
INSERT INTO `#__bsms_share` SET `id`='4',`name`='MySpace',`params`='{\"mainlink\":\"http://www.myspace.com/index.cfm?\",\"item1prefix\":\"fuseaction=postto&t=\",\"item1\":5,\"item1custom\":\"\",\"item2prefix\":\"&c=\",\"item2\":6,\"item2custom\":\"\",\"item3prefix\":\"&u=\",\"item3\":200,\"item3custom\":\"\",\"item4prefix\":\"&l=1\",\"item4\":\"\",\"item4custom\":\"\",\"use_bitly\":0,\"username\":\"\",\"api\":\"\",\"shareimage\":\"media/com_biblestudy/images/myspace.png\",\"shareimagew\":\"33px\",\"shareimageh\":\"33px\",\"totalcharacters\":\"\",\"alttext\":\"MySpace\"}',`published`='1',`asset_id`='2153',`access`='1',`ordering`='4';

-- --------------------------------------------------------

--
-- Table structure for table `#__bsms_studies`
--

DROP TABLE IF EXISTS `#__bsms_studies`;
CREATE TABLE `#__bsms_studies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `studydate` datetime DEFAULT NULL,
  `teacher_id` int(11) DEFAULT '1',
  `studynumber` varchar(100) DEFAULT '',
  `booknumber` int(3) DEFAULT '101',
  `chapter_begin` int(3) DEFAULT '1',
  `verse_begin` int(3) DEFAULT '1',
  `chapter_end` int(3) DEFAULT '1',
  `verse_end` int(3) DEFAULT '1',
  `secondary_reference` text,
  `booknumber2` varchar(4) DEFAULT NULL,
  `chapter_begin2` varchar(4) DEFAULT NULL,
  `verse_begin2` varchar(4) DEFAULT NULL,
  `chapter_end2` varchar(4) DEFAULT NULL,
  `verse_end2` varchar(4) DEFAULT NULL,
  `prod_dvd` varchar(100) DEFAULT NULL,
  `prod_cd` varchar(100) DEFAULT NULL,
  `server_cd` varchar(10) DEFAULT NULL,
  `server_dvd` varchar(10) DEFAULT NULL,
  `image_cd` varchar(10) DEFAULT NULL,
  `image_dvd` varchar(10) DEFAULT '0',
  `studytext2` text,
  `comments` tinyint(1) DEFAULT '1',
  `hits` int(10) NOT NULL DEFAULT '0',
  `user_id` int(10) DEFAULT NULL,
  `user_name` varchar(50) DEFAULT NULL,
  `show_level` varchar(100) NOT NULL DEFAULT '0',
  `location_id` int(3) DEFAULT NULL,
  `studytitle` text,
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `studyintro` text,
  `media_hours` varchar(2) DEFAULT NULL,
  `media_minutes` varchar(2) DEFAULT NULL,
  `media_seconds` varchar(2) DEFAULT NULL,
  `messagetype` varchar(100) DEFAULT '1',
  `series_id` int(3) DEFAULT '0',
  `studytext` text,
  `thumbnailm` text,
  `thumbhm` int(11) DEFAULT NULL,
  `thumbwm` int(11) DEFAULT NULL,
  `params` text,
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published` tinyint(3) NOT NULL DEFAULT '0',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `asset_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `access` int(10) unsigned NOT NULL DEFAULT '1',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `language` char(7) NOT NULL COMMENT 'The language code for the Studies.',
  `download_id` int(10) NOT NULL DEFAULT '0' COMMENT 'Used for link to download of mediafile',
  PRIMARY KEY (`id`),
  KEY `idx_state` (`published`),
  KEY `idx_access` (`access`),
  KEY `idx_seriesid` (`series_id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_createdby` (`user_id`),
  KEY `idx_checkout` (`checked_out`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;


--
-- Dumping data for table `#__bsms_studies`
--

INSERT INTO `#__bsms_studies` SET `id`='1',`studydate`='2010-03-13 00:10:00',`teacher_id`='2',`studynumber`='2010-001',`booknumber`='151',`chapter_begin`='1',`verse_begin`='1',`chapter_end`='1',`verse_end`='14',`secondary_reference`='',`booknumber2`='101',`chapter_begin2`='1',`verse_begin2`='2',`chapter_end2`='3',`verse_end2`='4',`prod_dvd`=NULL,`prod_cd`=NULL,`server_cd`=NULL,`server_dvd`=NULL,`image_cd`=NULL,`image_dvd`='0',`studytext2`=NULL,`comments`='1',`hits`='0',`user_id`='0',`user_name`='',`show_level`='0',`location_id`='-1',`studytitle`='Sample Study Title',`alias`='sample-study-title',`studyintro`='<p>Sample text you can use as an introduction to your study</p>',`media_hours`='',`media_minutes`='',`media_seconds`='',`messagetype`='1',`series_id`='1',`studytext`='<p style=\"text-align: center;\" align=\"center\">Colossians 1:1-14</p><p>Do you ever feel insignificant? Do you ever feel that everything you do for the Lord is not noticed and not important? Such might have been the feeling of those living in Colossae and serving the Lord Jesus. Colossae, located in Asia Minor, was once an important city on a major trade route. But over time it slipped into second-class status—becoming just a “small town”—outshined by nearby Laodicea and Hierapolis.</p><p>When the Apostle Paul visited Ephesus (Acts 19 &amp; 20) the gospel message was so powerful that it spread throughout the region. One of Paul’s workers, Epaphras, visited Colosse, share the gospel, and a church was born. But Paul never visited this church in person, so both from a political and even spiritual standpoint, the church and the town were unimportant.</p><p>Colosse itself has never been excavated so we know relatively little about it. In fact, you’d probably never know about it at all were it not for the letter we are beginning today. Despite it’s relative obscurity, Paul wrote this magnificent letter and God inspired the words to ring down through the ages in order to help us, warn us, and grow us in our faith.</p><p>Many times God uses the insignificant and unimportant—which means He can use you too! In fact, Epaphras and Philemon were two lay people, who started the church. The church met in Philemon’s house with Archippus (his son) as the pastor (Col 4:7). Philemon’s wife is also mentioned in Paul’s little letter to Philemon.</p><p>So why did Paul write this little letter? There were two major events taking place. While Paul was a prisoner in Rome, he met a runaway slave named Onesimus. Paul wrote to Onesimus’ owner, Philemon, asking that the master receive the slave back, now a brother in Christ. Secondly, Epaphras came to tell Paul that some people had introduced some bad teaching in Colosse that threatened to destroy the ministry.</p><p>Two ideas had been introduced: an early form of Gnosticism, which said that only people “in the know” of special knowledge and ceremonies could have a deep relationship with God. They felt that matter was evil and to deal with it you either subjected your body to severe treatment (asceticism) or ignored it altogether and did whatever felt right at the time (hedonism). The other involved Jewish legalism, which said that in order to complete yourself as a Christian you needed to observe the Mosaic Law. We’ll get more into both of these as we go through the letter.</p>',`thumbnailm`='',`thumbhm`=NULL,`thumbwm`=NULL,`params`='{\"metakey\":\"\",\"metadesc\":\"\"}',`checked_out`='0',`checked_out_time`='0000-00-00 00:00:00',`published`='1',`publish_up`='0000-00-00 00:00:00',`publish_down`='0000-00-00 00:00:00',`modified`='2015-03-23 21:30:57',`modified_by`='714',`asset_id`='46',`access`='1',`ordering`='1',`language`='*',`download_id`='-1';
INSERT INTO `#__bsms_studies` SET `id`='2',`studydate`='2015-03-17 14:26:08',`teacher_id`='1',`studynumber`='',`booknumber`='151',`chapter_begin`='1',`verse_begin`='1',`chapter_end`='1',`verse_end`='2',`secondary_reference`='',`booknumber2`='-1',`chapter_begin2`='',`verse_begin2`='',`chapter_end2`='',`verse_end2`='',`prod_dvd`=NULL,`prod_cd`=NULL,`server_cd`=NULL,`server_dvd`=NULL,`image_cd`=NULL,`image_dvd`='0',`studytext2`=NULL,`comments`='1',`hits`='5',`user_id`='714',`user_name`='',`show_level`='0',`location_id`='-1',`studytitle`='Guest Study',`alias`='guest-study',`studyintro`='',`media_hours`='',`media_minutes`='',`media_seconds`='',`messagetype`='-1',`series_id`='2',`studytext`='',`thumbnailm`='',`thumbhm`=NULL,`thumbwm`=NULL,`params`='{\"metakey\":\"\",\"metadesc\":\"\"}',`checked_out`='0',`checked_out_time`='0000-00-00 00:00:00',`published`='1',`publish_up`='0000-00-00 00:00:00',`publish_down`='0000-00-00 00:00:00',`modified`='2015-03-18 05:25:04',`modified_by`='714',`asset_id`='1235',`access`='5',`ordering`='2',`language`='*',`download_id`='-1';

-- --------------------------------------------------------

--
-- Table structure for table `#__bsms_studytopics`
--

DROP TABLE IF EXISTS `#__bsms_studytopics`;
CREATE TABLE `#__bsms_studytopics` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `study_id` int(3) NOT NULL DEFAULT '0',
  `topic_id` int(3) NOT NULL DEFAULT '0',
  `asset_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `access` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_access` (`access`),
  KEY `idx_study` (`study_id`),
  KEY `idx_topic` (`topic_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


--
-- Dumping data for table `#__bsms_studytopics`
--


-- --------------------------------------------------------

--
-- Table structure for table `#__bsms_styles`
--

DROP TABLE IF EXISTS `#__bsms_styles`;
CREATE TABLE `#__bsms_styles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `published` tinyint(3) NOT NULL DEFAULT '1',
  `filename` text NOT NULL,
  `stylecode` longtext NOT NULL,
  `asset_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  PRIMARY KEY (`id`),
  KEY `idx_state` (`published`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


--
-- Dumping data for table `#__bsms_styles`
--

INSERT INTO `#__bsms_styles` SET `id`='1',`published`='1',`filename`='biblestudy',`stylecode`='/* New Teacher Codes */#bsm_teachertable_list .bsm_teachername{font-weight: bold;font-size: 14px;color: #000000;}#bsm_teachertable_list{margin: 0;border-collapse:separate;}#bsm_teachertable_list td {text-align:left;padding:0 5px 0 5px;border:none;}#bsm_teachertable_list .titlerow{border-bottom: thick;}#bsm_teachertable_list .title{font-size:18px;font-weight:bold;border-bottom: 3px solid #999999;padding: 4px 0px 4px 4px;}#bsm_teachertable_list .bsm_separator{border-bottom: 1px solid #999999;}.bsm_teacherthumbnail_list{}#bsm_teachertable_list .bsm_teacheremail{font-weight:normal;font-size: 11px;}#bsm_teachertable_list .bsm_teacherwebsite{font-weight:normal;font-size: 11px;}#bsm_teachertable_list .bsm_teacherphone{font-weight:normal;font-size: 11px;}#bsm_teachertable_list .bsm_short{padding: 8px 4px 4px;}#bsm_teachertable .bsm_studiestitlerow {background-color: #666;}#bsm_teachertable_list .bsm_titletitle{font-weight:bold;color:#FFFFFF;}#bsm_teachertable_list .bsm_titlescripture{font-weight:bold;color:#FFFFFF;}#bsm_teachertable_list .bsm_titledate{font-weight:bold;color:#FFFFFF;}#bsm_teachertable_list .bsm_teacherlong{padding: 8px 4px 4px;border-bottom: 1px solid #999999;}#bsm_teachertable_list tr.bsodd {background-color:#FFFFFF;border-bottom: 1px solid #999999;}#bsm_teachertable_list tr.bseven {background-color:#FFFFF0;border-bottom: 1px solid #999999;}#bsm_teachertable_list .lastrow td {border-bottom:1px solid grey;padding-bottom:7px;padding-top:7px;}#bsm_teachertable_list .bsm_teacherfooter{border-top: 1px solid #999999;padding: 4px 1px 1px 4px;}/* New Teacher Details Codes */#bsm_teachertable .teacheraddress{text-align:left;}#bsm_teachertable .teacherwebsite{text-align:left;}#bsm_teachertable .teacherfacebook{text-align:left;}#bsm_teachertable .bsm_teachertwitter{text-align:left;}#bsm_teachertable .bsm_teacherblog{text-align:left;}#bsm_teachertable .bsm_teacherlink1{text-align:left;}/* New Landing Page CSS */.landingtable {clear:both;width:auto;display:table;}.landingrow {display:inline;padding: 1em;}.landingcell {display:table-cell;}.landinglink a{display:inline;}/* Terms of use or donate display settings */.termstext {}.termslink{}/* Podcast Subscription Display Settings */.podcastsubscribe{clear:both;display:table;width:100%;background-color:#eee;border-radius: 15px 15px 15px 15px;border: 1px solid grey;padding: 1em;}.podcastsubscribe .image {float: left;padding-right: 5px;display: inline;}.podcastsubscribe .image .text {display:inline;position:relative;right:50px;bottom:-10px;}.podcastsubscribe .prow {display: table-row;width:auto;clear:both;}.podcastsubscribe .pcell {display: table-cell;float:left;background-color:#e3e2e2;border-radius: 15px 15px 15px 15px;border: 1px solid grey;padding: 1em;margin-right: 5px;}.podcastheader h3{display:table-header;text-align:center;}.podcastheader{font-weight: bold;}.podcastlinks{display: inline;}.fltlft {float:left;padding-right: 5px;}/* Listing Page Items */#subscribelinks {}div.listingfooter ul li {list-style: none outside none;}/* Listing Page Items */#listintro p, #listintro td {margin: 0;font-weight: bold;color: black;}#listingfooter li, #listingfooter ul{display: inline;}#main ul, #main li{display: inline;}#bsdropdownmenu {margin-bottom: 10px;}.bslisttable {margin: 0;border-collapse:separate;}.bslisttable th, .bslisttable td {text-align:left;padding:0 5px 0 5px;border:none;}.bslisttable .row1col1,.bslisttable .row2col1,.bslisttable .row3col1,.bslisttable .row4col1 {border-left: grey 2px solid;}.bslisttable .lastcol {border-right: grey 2px solid;}.bslisttable .lastrow td {border-bottom:2px solid grey;padding-bottom:7px;}.bslisttable th {background-color:#707070;font-weight:bold;color:white;}.bslisttable th.row1col1,.bslisttable th.row1col2,.bslisttable th.row1col3,.bslisttable th.row1col4 {border-top: grey 2px solid;padding-top:3px;}.bslisttable th.firstrow {border-bottom: grey 2px solid;}.bslisttable tr.lastrow th {border-bottom:2px solid grey;padding-bottom:3px;}.bslisttable tr.bsodd td {background-color:#FFFFFF;}.bslisttable tr.bseven td {background-color:#FFFFF0;}.bslisttable .date {white-space:nowrap;font-size:1.2em;color:grey;font-weight:bold;}.bslisttable .scripture1 {white-space:nowrap;color:#c02121;font-weight:bold;}.bslisttable .scripture2 {white-space:nowrap;color:#c02121;font-weight:bold;}.bslisttable .title {font-size:1.2em;color:#707070;font-weight:bold;}.bslisttable .series_text {white-space:nowrap;color:grey;}.bslisttable .duration {white-space:nowrap;font-style:italic;}.bslisttable .studyintro {}.bslisttable .teacher {white-space:nowrap;}.bslisttable .location_text {white-space:nowrap;}.bslisttable .topic_text {white-space:nowrap;}.bslisttable .message_type {white-space:nowrap;}.bslisttable .jbsmedia {white-space:nowrap;}.bslisttable .store {white-space:nowrap;}.bslisttable .details-text {white-space:nowrap;}.bslisttable .details-pdf {white-space:nowrap;}.bslisttable .details-text-pdf {white-space:nowrap;}.bslisttable .detailstable td {border: none;padding: 0 2px 0 0;}.bslisttable .secondary_reference {white-space:nowrap;}.bslisttable .teacher-title-name {white-space:nowrap;}.bslisttable .submitted {white-space:nowrap;}.bslisttable .hits {white-space:nowrap;}.bslisttable .studynumber {white-space:nowrap;}.bslisttable .filesize {white-space:nowrap;}.bslisttable .custom {white-space:nowrap;}.bslisttable .commentshead {font-size: 2em;font-weight:bold;}.bslisttable .thumbnail {white-space:nowrap;}.bslisttable .mediatable td {border: none;padding: 0 6px 0 0;}.bslisttable .mediatable span.bsfilesize {font-size:0.6em;position:relative; bottom: 7px;}.component-content ul{text-align: center;}.component-content li{display: inline;}.pagenav{margin-left: 10px;margin-right: 10px;}/* Study Details CSS */#bsmsdetailstable {margin: 0;border-collapse:separate;}#bsmsdetailstable th, #bsmsdetailstable td {text-align:left;padding:0 5px 0 5px;border:none;}#bsmsdetailstable .row1col1,#bsmsdetailstable .row2col1,#bsmsdetailstable .row3col1,#bsmsdetailstable .row4col1 {border-left: grey 2px solid;}#bsmsdetailstable .lastcol {border-right: grey 2px solid;}#bsmsdetailstable .lastrow td {border-bottom:2px solid grey;padding-bottom:7px;}#bsmsdetailstable th {background-color:#707070;font-weight:bold;color:white;}#bsmsdetailstable th.row1col1,#bsmsdetailstable th.row1col2,#bsmsdetailstable th.row1col3,#bsmsdetailstable th.row1col4 {border-top: grey 2px solid;padding-top:3px;}#bsmsdetailstable tr.lastrow th {border-bottom:2px solid grey;padding-bottom:3px;}#bsmsdetailstable th.firstrow {border-bottom: grey 2px solid;}#bsmsdetailstable tr.bsodd td {background-color:#FFFFFF;}#bsmsdetailstable tr.bseven td {background-color:#FFFFF0;}#bsmsdetailstable .date {white-space:nowrap;font-size:1.2em;color:grey;font-weight:bold;}#bsmsdetailstable .scripture1 {white-space:nowrap;color:#c02121;font-weight:bold;}#bsmsdetailstable .scripture2 {white-space:nowrap;color:#c02121;font-weight:bold;}#bsmsdetailstable .title {font-size:1.2em;color:#707070;font-weight:bold;}#bsmsdetailstable .series_text {white-space:nowrap;color:grey;}#bsmsdetailstable .duration {white-space:nowrap;font-style:italic;}#bsmsdetailstable .studyintro {}#bsmsdetailstable .teacher {white-space:nowrap;}#bsmsdetailstable .location_text {white-space:nowrap;}#bsmsdetailstable .topic_text {white-space:nowrap;}#bsmsdetailstable .message_type {white-space:nowrap;}#bsmsdetailstable .jbsmedia {white-space:nowrap;}#bsmsdetailstable .store {white-space:nowrap;}#bsmsdetailstable .details-text {white-space:nowrap;}#bsmsdetailstable .details-pdf {white-space:nowrap;}#bsmsdetailstable .details-text-pdf {white-space:nowrap;}#bsmsdetailstable .detailstable td {border: none;padding: 0 2px 0 0;}#bsmsdetailstable .secondary_reference {white-space:nowrap;}#bsmsdetailstable .teacher-title-name {white-space:nowrap;}#bsmsdetailstable .submitted {white-space:nowrap;}#bsmsdetailstable .hits {white-space:nowrap;}#bsmsdetailstable .studynumber {white-space:nowrap;}#bsmsdetailstable .filesize {white-space:nowrap;}#bsmsdetailstable .custom {white-space:nowrap;}#bsmsdetailstable .commentshead {font-size: 2em;font-weight:bold;}#bsmsdetailstable .thumbnail {white-space:nowrap;}#bsmsdetailstable .mediatable td {border: none;padding: 0 6px 0 0;}#bsmsdetailstable .mediatable span.bsfilesize {font-size:0.6em;position:relative; bottom: 7px;}#bsdetailstable th, #bsdetailstable td {text-align:left;padding:0 5px 0 5px;border:none;}#bsdetailstable .studydetailstext td {font-size:1.2em;color:#707070;font-family:Verdana, Geneva, sans-serif;}#titletable {margin: 0;border-collapse:separate;}#titletable th, #titletable td {text-align:left;padding:0 5px 0 5px;border:none;}#titletable .titlesecondline {font-weight: bold;}#titletable .titlefirstline {font-size:20px;font-weight:bold;}#recaptcha_widget_div {position:static !important;}/* Module Style Settings */#bsmsmoduletable {margin: 0;border-collapse:separate;}#bsmsmoduletable th, #bsmsmoduletable td {text-align:left;padding:0 5px 0 5px;border:none;}#bsmsmoduletable .row1col1,#bsmsmoduletable .row2col1,#bsmsmoduletable .row3col1,#bsmsmoduletable .row4col1 {border-left: grey 2px solid;}#bsmsmoduletable .lastcol {border-right: grey 2px solid;}#bsmsmoduletable .lastrow td {border-bottom:2px solid grey;padding-bottom:7px;}#bsmsmoduletable th {background-color:#707070;font-weight:bold;color:white;}#bsmsmoduletable th.row1col1,#bsmsmoduletable th.row1col2,#bsmsmoduletable th.row1col3,#bsmsmoduletable th.row1col4 {border-top: grey 2px solid;padding-top:3px;}#bsmsmoduletable th.firstrow {border-bottom: grey 2px solid;}#bsmsmoduletable tr.lastrow th {border-bottom:2px solid grey;padding-bottom:3px;}#bsmsmoduletable tr.bsodd td {background-color:#FFFFFF;}#bsmsmoduletable tr.bseven td {background-color:#FFFFF0;}#bsmsmoduletable .date {white-space:nowrap;font-size:1.2em;color:grey;font-weight:bold;}#bsmsmoduletable .scripture1 {white-space:nowrap;color:#c02121;font-weight:bold;}#bsmsmoduletable .scripture2 {white-space:nowrap;color:#c02121;font-weight:bold;}#bsmsmoduletable .title {font-size:1.2em;color:#707070;font-weight:bold;}#bsmsmoduletable .series_text {white-space:nowrap;color:grey;}#bsmsmoduletable .duration {white-space:nowrap;font-style:italic;}#bsmsmoduletable .studyintro {}#bsmsmoduletable .teacher {white-space:nowrap;}#bsmsmoduletable .location_text {white-space:nowrap;}#bsmsmoduletable .topic_text {white-space:nowrap;}#bsmsmoduletable .message_type {white-space:nowrap;}#bsmsmoduletable .jbsmedia {white-space:nowrap;}#bsmsmoduletable .store {white-space:nowrap;}#bsmsmoduletable .details-text {white-space:nowrap;}#bsmsmoduletable .details-pdf {white-space:nowrap;}#bsmsmoduletable .details-text-pdf {white-space:nowrap;}#bsmsmoduletable .detailstable td {border: none;padding: 0 2px 0 0;}#bsmsmoduletable .secondary_reference {white-space:nowrap;}#bsmsmoduletable .teacher-title-name {white-space:nowrap;}#bsmsmoduletable .submitted {white-space:nowrap;}#bsmsmoduletable .hits {white-space:nowrap;}#bsmsmoduletable .studynumber {white-space:nowrap;}#bsmsmoduletable .filesize {white-space:nowrap;}#bsmsmoduletable .custom {white-space:nowrap;}#bsmsmoduletable .commentshead {font-size: 2em;font-weight:bold;}#bsmsmoduletable .thumbnail {white-space:nowrap;}#bsmsmoduletable .mediatable td {border: none;padding: 0 6px 0 0;}#bsmsmoduletable .mediatable span.bsfilesize {font-size:0.6em;position:relative; bottom: 7px;}/* Series List-Details Items */#seriestable {margin: 0;border-collapse:separate;}#seriestable th, #seriestable td {text-align:left;padding: 3px 3px 3px 3px;border:none;}#seriestable .firstrow td {border-top: grey 2px solid;}#seriestable .firstcol {border-left: grey 2px solid;}#seriestable .lastcol {border-right: grey 2px solid;}#seriestable .lastrow td {border-bottom:2px solid grey;border-left: 2px solid grey;border-right: 2px solid grey;padding-bottom:3px;}#seriesttable tr.bsodd td {background-color:#FFFFFF;}#seriestable tr.bseven td {background-color:#FFFFF0;}#seriestable tr.onlyrow td {border-bottom: 2px solid grey;border-top:grey 2px solid;}#seriestable .thumbnail img {border: 1px solid grey;}#seriestable .teacher img {border: 1px solid grey;}#seriestable .title {font-weight: bold;font-size: larger;}#seriestable tr.noborder td{border: none;}#seriestable .description p{width:500px;}#seriestable .teacher {font-weight: bold;}/* Series Detail Study Links Items */#seriesstudytable {margin: 0;border-collapse:separate;}#seriesstudytable th, #seriesstudytable td {text-align:left;padding:0 5px 0 5px;border:none;}#seriesstudytable .row1col1,#seriesstudytable .row2col1,#seriesstudytable .row3col1,#seriesstudytable .row4col1 {border-left: grey 2px solid;}#seriesstudytable .lastcol {border-right: grey 2px solid;}#seriesstudytable .lastrow td {border-bottom:2px solid grey;padding-bottom:7px;}#seriesstudytable th {background-color:#707070;font-weight:bold;color:white;}#seriesstudytable th.row1col1,#seriesstudytable th.row1col2,#seriesstudytable th.row1col3,#seriesstudytable th.row1col4 {border-top: grey 2px solid;padding-top:3px;}#seriesstudytable th.firstrow {border-bottom: grey 2px solid;}#seriesstudytable tr.lastrow th {border-bottom:2px solid grey;padding-bottom:3px;}#seriesstudytable tr.bsodd td {background-color:#FFFFFF;}#seriesstudytable tr.bseven td {background-color:#FFFFF0;}#seriesstudytable .date {white-space:nowrap;font-size:1.2em;color:grey;font-weight:bold;}#seriesstudytable .scripture1 {white-space:nowrap;color:#c02121;font-weight:bold;}#seriesstudytable .scripture2 {white-space:nowrap;color:#c02121;font-weight:bold;}#seriesstudytable .title {font-size:1.2em;color:#707070;font-weight:bold;font-style:italic;}#seriesstudytable .series_text {white-space:nowrap;color:grey;}#seriesstudytable .duration {white-space:nowrap;font-style:italic;}#seriesstudytable .studyintro {}#seriesstudytable .teacher {white-space:nowrap;}#seriesstudytable .location_text {white-space:nowrap;}#seriesstudytable .topic_text {white-space:nowrap;}#seriesstudytable .message_type {white-space:nowrap;}#seriesstudytable .jbsmedia {white-space:nowrap;}#seriesstudytable .store {white-space:nowrap;}#seriesstudytable .details-text {white-space:nowrap;}#seriesstudytable .details-pdf {white-space:nowrap;}#seriesstudytable .details-text-pdf {white-space:nowrap;}#seriesstudytable .detailstable td {border: none;padding: 0 2px 0 0;}#seriesstudytable .secondary_reference {white-space:nowrap;}#seriesstudytable .teacher-title-name {white-space:nowrap;}#seriesstudytable .submitted {white-space:nowrap;}#seriesstudytable .hits {white-space:nowrap;}#seriesstudytable .studynumber {white-space:nowrap;}#seriesstudytable .filesize {white-space:nowrap;}#seriesstudytable .custom {white-space:nowrap;}#seriesstudytable .commentshead {font-size: 2em;font-weight:bold;}#seriesstudytable .thumbnail {white-space:nowrap;}#seriesstudytable .mediatable td {border: none;padding: 0 6px 0 0;}#seriesstudytable .mediatable span.bsfilesize {font-size:0.6em;position:relative; bottom: 7px;}#seriesstudytable .studyrow {}.tool-tip {color: #fff;width: 300px;z-index: 13000;}/* Tooltip Styles *//* @todo need to find these files */.tool-title {font-weight: bold;font-size: 11px;margin: 0;color: #9FD4FF;padding: 8px 8px 4px;background: url(/images/tooltip/bubble.gif) top left;}.tool-text {font-size: 11px;padding: 4px 8px 8px;background: url(/images/tooltip/bubble_filler.gif) bottom right;}.custom-tip {color: #000;width: 300px;z-index: 13000;border: 2px solid #666666;background-color: white;}.custom-title {font-weight: bold;font-size: 11px;margin: 0;color: #000000;padding: 8px 8px 4px;background: #666666;border-bottom: 1px solid #999999;}.custom-text {font-size: 11px;padding: 4px 8px 8px;background: #999999;}/* Teacher List Styles */#bsm_teachertable{margin: 0;border-collapse:separate;}#bsm_teachertable td {text-align:left;padding:0 5px 0 5px;border:none;}#bsm_teachertable .titlerow{border-bottom: thick;}#bsm_teachertable .title{font-size:18px;font-weight:bold;border-bottom: 3px solid #999999;padding: 4px 0px 4px 4px;}#bsm_teachertable .bsm_separator{border-bottom: 1px solid #999999;}.bsm_teacherthumbnail{}#bsm_teachertable .bsm_teachername{font-weight: bold;font-size: 14px;color: #000000;white-space:nowrap;}#bsm_teachertable .bsm_teacheremail{font-weight:normal;font-size: 11px;}#bsm_teachertable .bsm_teacherwebsite{font-weight:normal;font-size: 11px;}#bsm_teachertable .bsm_teacherphone{font-weight:normal;font-size: 11px;}#bsm_teachertable .bsm_short{padding: 8px 4px 4px;}#bsm_teachertable .bsm_studiestitlerow {background-color: #666;}#bsm_teachertable .bsm_titletitle{font-weight:bold;color:#FFFFFF;}#bsm_teachertable .bsm_titlescripture{font-weight:bold;color:#FFFFFF;}#bsm_teachertable .bsm_titledate{font-weight:bold;color:#FFFFFF;}#bsm_teachertable .bsm_teacherlong{padding: 8px 4px 4px;border-bottom: 1px solid #999999;}#bsm_teachertable tr.bsodd {background-color:#FFFFFF;border-bottom: 1px solid #999999;}#bsm_teachertable tr.bseven {background-color:#FFFFF0;border-bottom: 1px solid #999999;}#bsm_teachertable .lastrow td {border-bottom:1px solid grey;padding-bottom:7px;padding-top:7px;}#bsm_teachertable .bsm_teacherfooter{border-top: 1px solid #999999;padding: 4px 1px 1px 4px;}/*Study Edit CSS */.bsmbutton{background-color:white;}#toolbar td.white {background-color:#FFFFFF;}#toolbar a hover visited{color:#0B55C4;}/*Social Networking Items */#bsmsshare {margin: 0;border-collapse:separate;float:right;border: 1px solid #CFCFCF;background-color: #F5F5F5;}#bsmsshare th, #bsmsshare td {text-align:center;padding:0 0 0 0;border:none;}#bsmsshare th {color:#0b55c4;font-weight:bold;}/* Landing Page Items */.landinglist {}#landing_label {}.landing_item {}.landing_title {font-family:arial;font-size:16px;font-weight:bold;}#biblestudy_landing {}#showhide {font-family:arial;font-size:12px;font-weight:bold;text-decoration:none;}#showhide .showhideheadingbutton img {vertical-align:bottom;}.landing_table {}#landing_td {width: 33%;}.landing_separator {height:15px;}/* Popup Window Items */.popupwindow{margin: 5px;text-align:center;}p.popuptitle {font-weight: bold;color: black;}.popupfooter{margin: 5px;text-align:center;}p.popupfooter {font-weight: bold;color: grey;}#main ul, #main li{display: inline;}.component-content ul{text-align: center;}.component-content li{display: inline;}.pagenav{margin-left: 10px;margin-right: 10px;}#recaptcha_widget_div {position:static !important;}',`asset_id`='2251';

-- --------------------------------------------------------

--
-- Table structure for table `#__bsms_teachers`
--

DROP TABLE IF EXISTS `#__bsms_teachers`;
CREATE TABLE `#__bsms_teachers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `teacher_image` text,
  `teacher_thumbnail` text,
  `teachername` varchar(250) NOT NULL DEFAULT '',
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `title` varchar(250) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `website` text,
  `information` text,
  `image` text,
  `imageh` text,
  `imagew` text,
  `thumb` text,
  `thumbw` text,
  `thumbh` text,
  `short` text,
  `ordering` int(11) NOT NULL DEFAULT '0',
  `catid` int(3) DEFAULT '1',
  `list_show` tinyint(1) NOT NULL DEFAULT '1',
  `published` tinyint(3) NOT NULL DEFAULT '1',
  `asset_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `access` int(10) unsigned NOT NULL DEFAULT '1',
  `language` char(7) NOT NULL COMMENT 'The language code for the Teachers.',
  `facebooklink` varchar(150) DEFAULT NULL,
  `twitterlink` varchar(150) DEFAULT NULL,
  `bloglink` varchar(150) DEFAULT NULL,
  `link1` varchar(150) DEFAULT NULL,
  `linklabel1` varchar(150) DEFAULT NULL,
  `link2` varchar(150) DEFAULT NULL,
  `linklabel2` varchar(150) DEFAULT NULL,
  `link3` varchar(150) DEFAULT NULL,
  `linklabel3` varchar(150) DEFAULT NULL,
  `contact` int(11) DEFAULT NULL,
  `address` mediumtext NOT NULL,
  `landing_show` int(3) DEFAULT NULL,
  `address1` mediumtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_state` (`published`),
  KEY `idx_access` (`access`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;


--
-- Dumping data for table `#__bsms_teachers`
--

INSERT INTO `#__bsms_teachers` SET `id`='1',`teacher_image`='',`teacher_thumbnail`='',`teachername`='Billy Sunday',`alias`='billy-sunday',`title`='Pastor',`phone`='555-555-5555',`email`='billy@sunday.com',`website`='http://billysunday.com',`information`='William Ashley Sunday was an American athlete who after being a popular outfielder in baseballs National League during the 1880s became the most celebrated and influential American evangelist during the first two decades of the 20th century.',`image`='media/com_biblestudy/images/billy_sunday11.jpg',`imageh`='276',`imagew`='197',`thumb`='media/com_biblestudy/images/images.jpg',`thumbw`='101',`thumbh`='141',`short`='Billy Sunday: 1862-1935',`ordering`='0',`catid`='1',`list_show`='1',`published`='1',`asset_id`='2154',`access`='1',`language`='*',`facebooklink`=NULL,`twitterlink`=NULL,`bloglink`=NULL,`link1`=NULL,`linklabel1`=NULL,`link2`=NULL,`linklabel2`=NULL,`link3`=NULL,`linklabel3`=NULL,`contact`=NULL,`address`='',`landing_show`=NULL,`address1`='';
INSERT INTO `#__bsms_teachers` SET `id`='2',`teacher_image`='',`teacher_thumbnail`=NULL,`teachername`='Tom Fuller',`alias`='tom-fuller',`title`='Pastor',`phone`='',`email`='',`website`='',`information`='',`image`=NULL,`imageh`=NULL,`imagew`=NULL,`thumb`=NULL,`thumbw`=NULL,`thumbh`=NULL,`short`='',`ordering`='1',`catid`='1',`list_show`='1',`published`='1',`asset_id`='3820',`access`='1',`language`='*',`facebooklink`='',`twitterlink`='',`bloglink`='',`link1`='',`linklabel1`='',`link2`='',`linklabel2`='',`link3`='',`linklabel3`='',`contact`='0',`address`='',`landing_show`='1',`address1`='';

-- --------------------------------------------------------

--
-- Table structure for table `#__bsms_templatecode`
--

DROP TABLE IF EXISTS `#__bsms_templatecode`;
CREATE TABLE `#__bsms_templatecode` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `published` tinyint(3) NOT NULL DEFAULT '1',
  `type` tinyint(3) NOT NULL,
  `filename` text NOT NULL,
  `asset_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `templatecode` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


--
-- Dumping data for table `#__bsms_templatecode`
--


-- --------------------------------------------------------

--
-- Table structure for table `#__bsms_templates`
--

DROP TABLE IF EXISTS `#__bsms_templates`;
CREATE TABLE `#__bsms_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `tmpl` longtext NOT NULL,
  `published` tinyint(3) NOT NULL DEFAULT '1',
  `params` longtext,
  `title` text,
  `text` text,
  `pdf` text,
  `asset_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_state` (`published`),
  KEY `idx_access` (`access`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


--
-- Dumping data for table `#__bsms_templates`
--

INSERT INTO `#__bsms_templates` SET `id`='1',`type`='tmplList',`tmpl`='',`published`='1',`params`='{\"useterms\":\"0\",\"terms\":\"\",\"css\":\"biblestudy.css\",\"studieslisttemplateid\":\"1\",\"sermonstemplate\":\"0\",\"detailstemplateid\":\"1\",\"sermontemplate\":\"0\",\"teachertemplateid\":\"1\",\"teachertemplate\":\"0\",\"teacherstemplate\":\"0\",\"serieslisttemplateid\":\"1\",\"seriesdisplaystemplate\":\"0\",\"seriesdetailtemplateid\":\"1\",\"seriesdisplaytemplate\":\"0\",\"offset\":\"false\",\"teacher_id\":[\"-1\"],\"series_id\":[\"-1\"],\"booknumber\":[\"-1\"],\"topic_id\":[\"-1\"],\"messagetype\":[\"-1\"],\"locations\":[\"-1\"],\"show_verses\":\"0\",\"stylesheet\":\"\",\"date_format\":\"2\",\"custom_date_format\":\"\",\"duration_type\":\"2\",\"protocol\":\"http:\\/\\/\",\"player\":\"0\",\"popuptype\":\"window\",\"internal_popup\":\"1\",\"autostart\":\"1\",\"playerresposive\":\"1\",\"player_width\":\"400\",\"player_height\":\"300\",\"embedshare\":\"TRUE\",\"backcolor\":\"0x287585\",\"frontcolor\":\"0xFFFFFF\",\"lightcolor\":\"0x000000\",\"screencolor\":\"0x000000\",\"popuptitle\":\"{{title}}\",\"popupfooter\":\"{{filename}}\",\"popupmargin\":\"50\",\"popupbackground\":\"black\",\"popupimage\":\"components\\/com_biblestudy\\/images\\/speaker24.png\",\"show_filesize\":\"1\",\"playerposition\":\"over\",\"playeridlehide\":\"1\",\"useexpert_list\":\"0\",\"headercode\":\"\",\"templatecode\":\"{{teacher}}{{title}}{{date}}{{studyintro}}{{scripture}}\",\"wrapcode\":\"0\",\"default_order\":\"DESC\",\"default_order_secondary\":\"ASC\",\"show_page_title\":\"1\",\"show_page_image\":\"1\",\"page_title\":\"Bible Studies\",\"use_headers_list\":\"1\",\"list_intro\":\"\",\"intro_show\":\"1\",\"list_teacher_show\":\"1\",\"teacherlink\":\"1\",\"showpodcastsubscribelist\":\"1\",\"subscribeintro\":\"Our Podcasts\",\"details_text\":\"Study Details\",\"show_book_search\":\"1\",\"ddbooks\":\"1\",\"booklist\":\"1\",\"use_go_button\":\"1\",\"ddgobutton\":\"2\",\"show_teacher_search\":\"1\",\"ddteachers\":\"3\",\"show_series_search\":\"1\",\"ddseries\":\"4\",\"show_type_search\":\"1\",\"ddmessagetype\":\"5\",\"show_year_search\":\"1\",\"ddyears\":\"6\",\"show_order_search\":\"1\",\"ddorder\":\"7\",\"show_topic_search\":\"1\",\"ddtopics\":\"8\",\"show_locations_search\":\"1\",\"ddlocations\":\"9\",\"show_popular\":\"1\",\"ddpopular\":\"10\",\"listlanguage\":\"0\",\"ddlanguage\":\"11\",\"show_pagination\":\"1\",\"listcolor1\":\"\",\"listcolor2\":\"\",\"rowspanitem\":\"0\",\"rowspanitemspan\":\"1\",\"rowspanitemimage\":\"img-polaroid\",\"rowspanitempull\":\"pull-left\",\"scripture1row\":\"1\",\"scripture1col\":\"1\",\"scripture1colspan\":\"3\",\"scripture1element\":\"0\",\"scripture1custom\":\"\",\"scripture1linktype\":\"1\",\"scripture2row\":\"4\",\"scripture2col\":\"1\",\"scripture2colspan\":\"5\",\"scripture2element\":\"1\",\"scripture2custom\":\"\",\"scripture2linktype\":\"0\",\"secondaryrow\":\"0\",\"secondarycol\":\"1\",\"secondarycolspan\":\"1\",\"secondaryelement\":\"1\",\"secondarycustom\":\"\",\"secondarylinktype\":\"0\",\"jbsmediarow\":\"1\",\"jbsmediacol\":\"2\",\"jbsmediacolspan\":\"5\",\"jbsmediaelement\":\"0\",\"jbsmediacustom\":\"\",\"jbsmedialinktype\":\"0\",\"titlerow\":\"1\",\"titlecol\":\"1\",\"titlecolspan\":\"2\",\"titleelement\":\"1\",\"titlecustom\":\"\",\"titlelinktype\":\"0\",\"daterow\":\"1\",\"datecol\":\"1\",\"datecolspan\":\"1\",\"dateelement\":\"1\",\"datecustom\":\"\",\"datelinktype\":\"0\",\"teacherrow\":\"0\",\"teachercol\":\"1\",\"teachercolspan\":\"1\",\"teacherelement\":\"1\",\"teachercustom\":\"\",\"teacherlinktype\":\"0\",\"teacherimagerrow\":\"0\",\"teacherimagecol\":\"1\",\"teacherimagecolspan\":\"1\",\"teacherimageelement\":\"1\",\"teacherimagecustom\":\"\",\"teacher-titlerow\":\"0\",\"teacher-titlecol\":\"1\",\"teacher-titlecolspan\":\"1\",\"teacher-titleelement\":\"1\",\"teacher-titlecustom\":\"\",\"teacher-titlelinktype\":\"0\",\"durationrow\":\"0\",\"durationcol\":\"1\",\"durationcolspan\":\"1\",\"durationelement\":\"1\",\"durationcustom\":\"\",\"durationlinktype\":\"0\",\"studyintrorow\":\"2\",\"studyintrocol\":\"1\",\"studyintrocolspan\":\"12\",\"studyintroelement\":\"1\",\"studyintrocustom\":\"\",\"studyintrolinktype\":\"0\",\"seriesrow\":\"0\",\"seriescol\":\"1\",\"seriescolspan\":\"1\",\"serieselement\":\"1\",\"seriescustom\":\"\",\"serieslinktype\":\"0\",\"seriesthumbnailrow\":\"0\",\"seriesthumbnailcol\":\"1\",\"seriesthumbnailcolspan\":\"1\",\"seriesthumbnailelement\":\"1\",\"seriesthumbnailcustom\":\"\",\"seriesthumbnaillinktype\":\"0\",\"seriesdescriptionrow\":\"0\",\"seriesdescriptioncol\":\"1\",\"seriesdescriptioncolspan\":\"1\",\"seriesdescriptionelement\":\"1\",\"seriesdescriptioncustom\":\"\",\"seriesdescriptionlinktype\":\"0\",\"submittedrow\":\"0\",\"submittedcol\":\"1\",\"submittedcolspan\":\"1\",\"submittedelement\":\"1\",\"submittedcustom\":\"\",\"submittedlinktype\":\"0\",\"hitsrow\":\"0\",\"hitscol\":\"1\",\"hitscolspan\":\"6\",\"hitselement\":\"1\",\"hitscustom\":\"\",\"hitslinktype\":\"0\",\"downloadsrow\":\"0\",\"downloadscol\":\"1\",\"downloadscolspan\":\"1\",\"downloadselement\":\"1\",\"downloadscustom\":\"\",\"downloadslinktype\":\"0\",\"studynumberrow\":\"0\",\"studynumbercol\":\"1\",\"studynumbercolspan\":\"1\",\"studynumberelement\":\"1\",\"studynumbercustom\":\"\",\"studynumberlinktype\":\"0\",\"topicrow\":\"0\",\"topiccol\":\"1\",\"topiccolspan\":\"6\",\"topicelement\":\"1\",\"topiccustom\":\"\",\"topiclinktype\":\"0\",\"locationsrow\":\"0\",\"locationscol\":\"1\",\"locationscolspan\":\"1\",\"locationselement\":\"1\",\"locationscustom\":\"\",\"locationslinktype\":\"0\",\"messagetyperow\":\"0\",\"messagetypecol\":\"1\",\"messagetypecolspan\":\"6\",\"messagetypeelement\":\"1\",\"messagetypecustom\":\"\",\"messagetypelinktype\":\"0\",\"thumbnailrow\":\"0\",\"thumbnailcol\":\"1\",\"thumbnailcolspan\":\"1\",\"thumbnailelement\":\"1\",\"thumbnailcustom\":\"\",\"thumbnaillinktype\":\"0\",\"customrow\":\"0\",\"customcol\":\"1\",\"customcolspan\":\"1\",\"customelement\":\"1\",\"customcustom\":\"\",\"customtext\":\"\",\"show_print_view\":\"1\",\"link_text\":\"Return to Studies List\",\"showrelated\":\"1\",\"showpodcastsubscribedetails\":\"1\",\"show_scripture_link\":\"0\",\"show_passage_view\":\"0\",\"bible_version\":\"31\",\"socialnetworking\":\"1\",\"sharetype\":\"1\",\"sharelabel\":\"Share This\",\"comments_type\":\"0\",\"show_comments\":\"1\",\"link_comments\":\"0\",\"comment_access\":\"1\",\"comment_publish\":\"0\",\"use_captcha\":\"0\",\"public_key\":\"\",\"private_key\":\"\",\"email_comments\":\"1\",\"recipient\":\"\",\"subject\":\"Comments on studies\",\"body\":\"Comments entered.\",\"useexpert_details\":\"0\",\"study_detailtemplate\":\"\",\"teacher_title\":\"Our Teachers\",\"useexpert_teacherlist\":\"0\",\"tsrowspanitem\":\"0\",\"tsrowspanitemspan\":\"4\",\"tsrowspanitemimage\":\"img-polaroid\",\"tsrowspanitempull\":\"pull-left\",\"use_headers_teacher_list\":\"1\",\"tslistcolor1\":\"\",\"tslistcolor2\":\"\",\"tsteacherrow\":\"1\",\"tsteachercol\":\"1\",\"tsteachercolspan\":\"3\",\"tsteacherelement\":\"1\",\"tsteachercustom\":\"\",\"tsteacherlinktype\":\"3\",\"tsteacherimagerrow\":\"0\",\"tsteacherimagecol\":\"1\",\"tsteacherimagecolspan\":\"4\",\"tsteacherimageelement\":\"1\",\"tsteacherimagecustom\":\"\",\"tsteacher-titlerow\":\"0\",\"tsteacher-titlecol\":\"1\",\"tsteacher-titlecolspan\":\"1\",\"tsteacher-titleelement\":\"1\",\"tsteacher-titlecustom\":\"\",\"tsteacher-titlelinktype\":\"0\",\"tsteacheremailrow\":\"0\",\"tsteacheremailcol\":\"1\",\"tsteacheremailcolspan\":\"1\",\"tsteacheremailelement\":\"1\",\"tsteacheremailcustom\":\"\",\"tsteacherwebrow\":\"0\",\"tsteacherwebcol\":\"1\",\"tsteacherwebcolspan\":\"1\",\"tsteacherwebelement\":\"1\",\"tsteacherphonerow\":\"0\",\"tsteacherphonecol\":\"1\",\"tsteacherphonecolspan\":\"1\",\"tsteacherphoneelement\":\"1\",\"tsteacherphonecustom\":\"\",\"tsteacherfbrow\":\"0\",\"tsteacherfbcol\":\"1\",\"tsteacherfbcolspan\":\"1\",\"tsteacherfbelement\":\"1\",\"tsteacherfbcustom\":\"\",\"tsteachertwrow\":\"0\",\"tsteachertwcol\":\"1\",\"tsteachertwcolspan\":\"1\",\"tsteachertwelement\":\"1\",\"tsteachertwcustom\":\"\",\"tsteacherblogrow\":\"0\",\"tsteacherblogcol\":\"1\",\"tsteacherblogcolspan\":\"1\",\"tsteacherblogelement\":\"1\",\"tsteacherblogcustom\":\"\",\"tsteachershortrow\":\"0\",\"tsteachershortcol\":\"1\",\"tsteachershortcolspan\":\"1\",\"tsteachershortelement\":\"1\",\"tsteachershortcustom\":\"\",\"tsteachershortlinktype\":\"0\",\"tscustomrow\":\"\",\"tscustomcol\":\"1\",\"tscustomcolspan\":\"1\",\"tscustomelement\":\"1\",\"tscustomcustom\":\"\",\"tscustomtext\":\"\",\"tsteacherallinonerow\":\"0\",\"tsteacherallinonecol\":\"1\",\"tsteacherallinonecolspan\":\"1\",\"tsteacherallinoneelement\":\"1\",\"tsteacherallinonecustom\":\"\",\"teacher_headercode\":\"\",\"teacher_templatecode\":\"{{teacher}}{{title}}{{teacher}}{{short}}{{information}}\",\"teacher_wrapcode\":\"0\",\"show_teacher_studies\":\"0\",\"studies\":\"5\",\"label_teacher\":\"Latest Messages\",\"teacherlinkstudies\":\"1\",\"tdrowspanitem\":\"0\",\"tdrowspanitemspan\":\"4\",\"tdrowspanitemimage\":\"img-polaroid\",\"tdrowspanitempull\":\"pull-left\",\"use_headers_teacher_details\":\"1\",\"teacherdisplay_color\":\"\",\"tdteacherrow\":\"1\",\"tdteachercol\":\"1\",\"tdteachercolspan\":\"2\",\"tdteacherelement\":\"1\",\"tdteachercustom\":\"\",\"tdteacherimagerrow\":\"0\",\"tdteacherimagecol\":\"1\",\"tdteacherimagecolspan\":\"1\",\"tdteacherimageelement\":\"1\",\"tdteacherimagecustom\":\"\",\"tdteacher-titlerow\":\"0\",\"tdteacher-titlecol\":\"1\",\"tdteacher-titlecolspan\":\"1\",\"tdteacher-titleelement\":\"1\",\"tdteacher-titlecustom\":\"\",\"tdteacheremailrow\":\"0\",\"tdteacheremailcol\":\"1\",\"tdteacheremailcolspan\":\"1\",\"tdteacheremailelement\":\"1\",\"tdteacheremailcustom\":\"\",\"tdteacherwebrow\":\"0\",\"tdteacherwebcol\":\"1\",\"tdteacherwebcolspan\":\"1\",\"tdteacherwebelement\":\"1\",\"tdteacherphonerow\":\"0\",\"tdteacherphonecol\":\"1\",\"tdteacherphonecolspan\":\"1\",\"tdteacherphoneelement\":\"1\",\"tdteacherphonecustom\":\"\",\"tdteacherfbrow\":\"0\",\"tdteacherfbcol\":\"1\",\"tdteacherfbcolspan\":\"1\",\"tdteacherfbelement\":\"1\",\"tdteacherfbcustom\":\"\",\"tdteachertwrow\":\"0\",\"tdteachertwcol\":\"1\",\"tdteachertwcolspan\":\"1\",\"tdteachertwelement\":\"1\",\"tdteachertwcustom\":\"\",\"tdteacherblogrow\":\"0\",\"tdteacherblogcol\":\"1\",\"tdteacherblogcolspan\":\"1\",\"tdteacherblogelement\":\"1\",\"tdteacherblogcustom\":\"\",\"tdteachershortrow\":\"0\",\"tdteachershortcol\":\"1\",\"tdteachershortcolspan\":\"1\",\"tdteachershortelement\":\"1\",\"tdteachershortcustom\":\"\",\"tdteacherlongrow\":\"0\",\"tdteacherlongcol\":\"1\",\"tdteacherlongcolspan\":\"1\",\"tdteacherlongelement\":\"1\",\"tdteacherlongcustom\":\"\",\"tdteacheraddressrow\":\"0\",\"tdteacheraddresscol\":\"1\",\"tdteacheraddresscolspan\":\"1\",\"tdteacheraddresselement\":\"1\",\"tdteacheraddresscustom\":\"\",\"tdteacherlink1row\":\"0\",\"tdteacherlink1col\":\"1\",\"tdteacherlink1colspan\":\"1\",\"tdteacherlink1element\":\"1\",\"tdteacherlink1custom\":\"\",\"tdteacherlink2row\":\"0\",\"tdteacherlink2col\":\"1\",\"tdteacherlink2colspan\":\"1\",\"tdteacherlink2element\":\"1\",\"tdteacherlink2custom\":\"\",\"tdteacherlink3row\":\"0\",\"tdteacherlink3col\":\"1\",\"tdteacherlink3colspan\":\"1\",\"tdteacherlink3element\":\"1\",\"tdteacherlink3custom\":\"\",\"tdteacherlargeimagerow\":\"0\",\"tdteacherlargeimagecol\":\"1\",\"tdteacherlargeimagecolspan\":\"1\",\"tdteacherlargeimageelement\":\"1\",\"tdteacherlargeimagecustom\":\"\",\"tdcustomrow\":\"\",\"tdcustomcol\":\"1\",\"tdcustomcolspan\":\"1\",\"tdcustomelement\":\"1\",\"tdcustomcustom\":\"\",\"tdcustomtext\":\"\",\"tdteacherallinonerow\":\"0\",\"tdteacherallinonecol\":\"1\",\"tdteacherallinonecolspan\":\"1\",\"tdteacherallinoneelement\":\"1\",\"tdteacherallinonecustom\":\"\",\"useexpert_teacherdetail\":\"0\",\"teacher_detailtemplate\":\"{{teacher}}{{title}}{{teacher}}{{short}}{{information}}\",\"slistcolor1\":\"\",\"slistcolor2\":\"\",\"series_title\":\"Our Series\",\"show_series_title\":\"1\",\"show_page_image_series\":\"1\",\"use_headers_series\":\"1\",\"series_show_description\":\"1\",\"series_characters\":\"\",\"search_series\":\"1\",\"series_list_teachers\":\"1\",\"series_list_years\":\"1\",\"series_list_show_pagination\":\"1\",\"series_list_order\":\"ASC\",\"series_order_field\":\"t.teachername\",\"srowspanitem\":\"0\",\"srowspanitemspan\":\"4\",\"srowspanitemimage\":\"img-polaroid\",\"srowspanitempull\":\"pull-left\",\"sseriesrow\":\"2\",\"sseriescol\":\"1\",\"sseriescolspan\":\"6\",\"sserieselement\":\"1\",\"sseriescustom\":\"\",\"sserieslinktype\":\"0\",\"sseriesthumbnailrow\":\"1\",\"sseriesthumbnailcol\":\"2\",\"sseriesthumbnailcolspan\":\"1\",\"sseriesthumbnailelement\":\"1\",\"sseriesthumbnailcustom\":\"\",\"sseriesthumbnaillinktype\":\"0\",\"steacherrow\":\"0\",\"steachercol\":\"1\",\"steachercolspan\":\"1\",\"steacherelement\":\"1\",\"steachercustom\":\"\",\"steacherlinktype\":\"0\",\"steacherimagerow\":\"0\",\"steacherimagecol\":\"1\",\"steacherimagecolspan\":\"1\",\"steacherimageelement\":\"1\",\"steacherimagecustom\":\"\",\"steacher-titlerow\":\"0\",\"steacher-titlecol\":\"1\",\"steacher-titlecolspan\":\"1\",\"steacher-titleelement\":\"1\",\"steacher-titlecustom\":\"\",\"steacher-titlelinktype\":\"0\",\"sdescriptionrow\":\"0\",\"sdescriptioncol\":\"1\",\"sdescriptioncolspan\":\"1\",\"sdescriptionelement\":\"1\",\"sdescriptioncustom\":\"\",\"sdescriptionlinktype\":\"0\",\"sdcustomrow\":\"0\",\"sdcustomcol\":\"1\",\"sdcustomcolspan\":\"1\",\"sdcustomelement\":\"1\",\"sdcustomcustom\":\"\",\"sdcustomtext\":\"\",\"series_detail_sort\":\"studydate\",\"series_detail_order\":\"DESC\",\"series_detail_limit\":\"\",\"series_list_return\":\"1\",\"sdrowspanitem\":\"0\",\"sdrowspanitemspan\":\"4\",\"sdrowspanitemimage\":\"img-polaroid\",\"sdrowspanitempull\":\"pull-left\",\"seriesdisplay_color\":\"\",\"use_header_seriesdisplay\":\"0\",\"sdseriesrow\":\"2\",\"sdseriescol\":\"1\",\"sdseriescolspan\":\"6\",\"sdserieselement\":\"1\",\"sdseriescustom\":\"\",\"sdserieslinktype\":\"0\",\"sdseriesthumbnailrow\":\"1\",\"sdseriesthumbnailcol\":\"2\",\"sdseriesthumbnailcolspan\":\"1\",\"sdseriesthumbnailelement\":\"1\",\"sdseriesthumbnailcustom\":\"\",\"sdseriesthumbnaillinktype\":\"0\",\"sdteacherrow\":\"0\",\"sdteachercol\":\"1\",\"sdteachercolspan\":\"1\",\"sdteacherelement\":\"1\",\"sdteachercustom\":\"\",\"sdteacherlinktype\":\"0\",\"sdteacherimagerow\":\"0\",\"sdteacherimagecol\":\"1\",\"sdteacherimagecolspan\":\"1\",\"sdteacherimageelement\":\"1\",\"sdteacherimagecustom\":\"\",\"sdteacher-titlerow\":\"0\",\"sdteacher-titlecol\":\"1\",\"sdteacher-titlecolspan\":\"1\",\"sdteacher-titleelement\":\"1\",\"sdteacher-titlecustom\":\"\",\"sdteacher-titlelinktype\":\"0\",\"sddescriptionrow\":\"0\",\"sddescriptioncol\":\"1\",\"sddescriptioncolspan\":\"1\",\"sddescriptionelement\":\"1\",\"sddescriptioncustom\":\"\",\"sddescriptionlinktype\":\"0\",\"tip_title\":\"Sermon Information\",\"tooltip\":\"1\",\"tip_item1_title\":\"Title\",\"tip_item1\":\"title\",\"tip_item2_title\":\"Details\",\"tip_item2\":\"title\",\"tip_item3_title\":\"Teacher\",\"tip_item3\":\"title\",\"tip_item4_title\":\"Reference\",\"tip_item4\":\"title\",\"tip_item5_title\":\"Date\",\"tip_item5\":\"title\",\"drowspanitem\":\"0\",\"drowspanitemspan\":\"4\",\"drowspanitemimage\":\"img-polaroid\",\"drowspanitempull\":\"pull-left\",\"dscripture1row\":\"1\",\"dscripture1col\":\"1\",\"dscripture1colspan\":\"1\",\"dscripture1element\":\"1\",\"dscripture1custom\":\"\",\"dscripture1linktype\":\"0\",\"dscripture2row\":\"0\",\"dscripture2col\":\"1\",\"dscripture2colspan\":\"1\",\"dscripture2element\":\"1\",\"dscripture2custom\":\"\",\"dscripture2linktype\":\"0\",\"dsecondaryrow\":\"0\",\"dsecondarycol\":\"1\",\"dsecondarycolspan\":\"1\",\"dsecondaryelement\":\"1\",\"dsecondarycustom\":\"\",\"dsecondarylinktype\":\"0\",\"djbsmediarow\":\"1\",\"djbsmediacol\":\"3\",\"djbsmediacolspan\":\"1\",\"djbsmediaelement\":\"1\",\"djbsmediacustom\":\"\",\"djbsmedialinktype\":\"0\",\"dcustomrow\":\"0\",\"dcustomcol\":\"1\",\"dcustomcolspan\":\"1\",\"dcustomelement\":\"1\",\"dcustomcustom\":\"\",\"dcustomtext\":\"\",\"dtitlerow\":\"1\",\"dtitlecol\":\"2\",\"dtitlecolspan\":\"3\",\"dtitleelement\":\"1\",\"dtitlecustom\":\"\",\"dtitlelinktype\":\"0\",\"ddaterow\":\"0\",\"ddatecol\":\"1\",\"ddatecolspan\":\"1\",\"ddateelement\":\"1\",\"ddatecustom\":\"\",\"ddatelinktype\":\"0\",\"dteacherrow\":\"0\",\"dteachercol\":\"1\",\"dteachercolspan\":\"1\",\"dteacherelement\":\"1\",\"dteachercustom\":\"\",\"dteacherlinktype\":\"0\",\"dteacherimagerrow\":\"0\",\"dteacherimagecol\":\"1\",\"dteacherimagecolspan\":\"1\",\"dteacherimageelement\":\"1\",\"dteacherimagecustom\":\"\",\"dteacher-titlerow\":\"0\",\"dteacher-titlecol\":\"1\",\"dteacher-titlecolspan\":\"1\",\"dteacher-titleelement\":\"1\",\"dteacher-titlecustom\":\"\",\"dteacher-titlelinktype\":\"0\",\"ddurationrow\":\"0\",\"ddurationcol\":\"1\",\"ddurationcolspan\":\"1\",\"ddurationelement\":\"1\",\"ddurationcustom\":\"\",\"ddurationlinktype\":\"0\",\"dstudyintrorow\":\"0\",\"dstudyintrocol\":\"1\",\"dstudyintrocolspan\":\"6\",\"dstudyintroelement\":\"1\",\"dstudyintrocustom\":\"\",\"dstudyintrolinktype\":\"0\",\"dseriesrow\":\"0\",\"dseriescol\":\"1\",\"dseriescolspan\":\"1\",\"dserieselement\":\"1\",\"dseriescustom\":\"\",\"dserieslinktype\":\"0\",\"dseriesthumbnailrow\":\"0\",\"dseriesthumbnailcol\":\"1\",\"dseriesthumbnailcolspan\":\"1\",\"dseriesthumbnailelement\":\"1\",\"dseriesthumbnailcustom\":\"\",\"dseriesthumbnaillinktype\":\"0\",\"dseriesdescriptionrow\":\"0\",\"dseriesdescriptioncol\":\"1\",\"dseriesdescriptioncolspan\":\"1\",\"dseriesdescriptionelement\":\"1\",\"dseriesdescriptioncustom\":\"\",\"dseriesdescriptionlinktype\":\"0\",\"dsubmittedrow\":\"0\",\"dsubmittedcol\":\"1\",\"dsubmittedcolspan\":\"1\",\"dsubmittedelement\":\"1\",\"dsubmittedcustom\":\"\",\"dsubmittedlinktype\":\"0\",\"dhitsrow\":\"0\",\"dhitscol\":\"1\",\"dhitscolspan\":\"6\",\"dhitselement\":\"1\",\"dhitscustom\":\"\",\"dhitslinktype\":\"0\",\"ddownloadsrow\":\"0\",\"ddownloadscol\":\"1\",\"ddownloadscolspan\":\"1\",\"ddownloadselement\":\"1\",\"ddownloadscustom\":\"\",\"ddownloadslinktype\":\"0\",\"dstudynumberrow\":\"0\",\"dstudynumbercol\":\"1\",\"dstudynumbercolspan\":\"1\",\"dstudynumberelement\":\"1\",\"dstudynumbercustom\":\"\",\"dstudynumberlinktype\":\"0\",\"dtopicrow\":\"0\",\"dtopiccol\":\"1\",\"dtopiccolspan\":\"6\",\"dtopicelement\":\"1\",\"dtopiccustom\":\"\",\"dtopiclinktype\":\"0\",\"dlocationsrow\":\"0\",\"dlocationscol\":\"1\",\"dlocationscolspan\":\"1\",\"dlocationselement\":\"1\",\"dlocationscustom\":\"\",\"dlocationslinktype\":\"0\",\"dmessagetyperow\":\"0\",\"dmessagetypecol\":\"1\",\"dmessagetypecolspan\":\"6\",\"dmessagetypeelement\":\"1\",\"dmessagetypecustom\":\"\",\"dmessagetypelinktype\":\"0\",\"dthumbnailrow\":\"0\",\"dthumbnailcol\":\"1\",\"dthumbnailcolspan\":\"1\",\"dthumbnailelement\":\"1\",\"dthumbnailcustom\":\"\",\"dthumbnaillinktype\":\"0\",\"landing_hide\":\"0\",\"landing_default_order\":\"ASC\",\"landing_hidelabel\":\"Show\\/Hide All\",\"headingorder_1\":\"teachers\",\"headingorder_2\":\"series\",\"headingorder_3\":\"books\",\"headingorder_4\":\"topics\",\"headingorder_5\":\"locations\",\"headingorder_6\":\"messagetypes\",\"headingorder_7\":\"years\",\"showteachers\":\"1\",\"landingteachersuselimit\":\"0\",\"landingteacherslimit\":\"\",\"teacherslabel\":\"Speakers\",\"linkto\":\"1\",\"showseries\":\"1\",\"landingseriesuselimit\":\"0\",\"landingserieslimit\":\"\",\"serieslabel\":\"Series\",\"series_linkto\":\"0\",\"showbooks\":\"1\",\"landingbookslimit\":\"\",\"bookslabel\":\"Books\",\"showtopics\":\"1\",\"landingtopicslimit\":\"\",\"topicslabel\":\"Topics\",\"showlocations\":\"1\",\"landinglocationsuselimit\":\"0\",\"landinglocationslimit\":\"\",\"locationslabel\":\"Locations\",\"showmessagetypes\":\"1\",\"landingmessagetypeuselimit\":\"0\",\"landingmessagetypeslimit\":\"\",\"messagetypeslabel\":\"Message Types\",\"showyears\":\"1\",\"landingyearslimit\":\"\",\"yearslabel\":\"Years\"}',`title`='Default',`text`='textfile24.png',`pdf`='pdf24.png',`asset_id`='85',`access`='1';

-- --------------------------------------------------------

--
-- Table structure for table `#__bsms_timeset`
--

DROP TABLE IF EXISTS `#__bsms_timeset`;
CREATE TABLE `#__bsms_timeset` (
  `timeset` varchar(14) NOT NULL DEFAULT '',
  `backup` varchar(14) DEFAULT NULL,
  PRIMARY KEY (`timeset`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


--
-- Dumping data for table `#__bsms_timeset`
--

INSERT INTO `#__bsms_timeset` SET `timeset`='1281646339',`backup`='1281646339';

-- --------------------------------------------------------

--
-- Table structure for table `#__bsms_topics`
--

DROP TABLE IF EXISTS `#__bsms_topics`;
CREATE TABLE `#__bsms_topics` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `topic_text` text,
  `published` tinyint(3) NOT NULL DEFAULT '1',
  `params` varchar(511) DEFAULT NULL,
  `asset_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `language` char(7) DEFAULT '*',
  `access` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_state` (`published`),
  KEY `idx_access` (`access`)
) ENGINE=InnoDB AUTO_INCREMENT=114 DEFAULT CHARSET=utf8;


--
-- Dumping data for table `#__bsms_topics`
--

INSERT INTO `#__bsms_topics` SET `id`='1',`topic_text`='JBS_TOP_ABORTION',`published`='1',`params`=NULL,`asset_id`='2156',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='2',`topic_text`='JBS_TOP_GODS_ACTIVITY',`published`='1',`params`=NULL,`asset_id`='2157',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='3',`topic_text`='JBS_TOP_ADDICTION',`published`='1',`params`=NULL,`asset_id`='2158',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='4',`topic_text`='JBS_TOP_AFTERLIFE',`published`='1',`params`=NULL,`asset_id`='2159',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='5',`topic_text`='JBS_TOP_APOLOGETICS',`published`='1',`params`=NULL,`asset_id`='2160',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='6',`topic_text`='JBS_TOP_GODS_ATTRIBUTES',`published`='1',`params`=NULL,`asset_id`='2161',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='7',`topic_text`='JBS_TOP_BAPTISM',`published`='1',`params`=NULL,`asset_id`='2162',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='8',`topic_text`='JBS_TOP_BASICS_OF_CHRISTIANITY',`published`='1',`params`=NULL,`asset_id`='2163',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='9',`topic_text`='JBS_TOP_BECOMING_A_CHRISTIAN',`published`='1',`params`=NULL,`asset_id`='2164',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='10',`topic_text`='JBS_TOP_BIBLE',`published`='1',`params`=NULL,`asset_id`='2165',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='11',`topic_text`='JBS_TOP_JESUS_BIRTH',`published`='1',`params`=NULL,`asset_id`='2166',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='12',`topic_text`='JBS_TOP_CHILDREN',`published`='1',`params`=NULL,`asset_id`='2167',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='13',`topic_text`='JBS_TOP_CHRIST',`published`='1',`params`=NULL,`asset_id`='2168',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='14',`topic_text`='JBS_TOP_CHRISTIAN_CHARACTER_FRUITS',`published`='1',`params`=NULL,`asset_id`='2169',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='15',`topic_text`='JBS_TOP_CHRISTIAN_VALUES',`published`='1',`params`=NULL,`asset_id`='2170',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='16',`topic_text`='JBS_TOP_CHRISTMAS_SEASON',`published`='1',`params`=NULL,`asset_id`='2171',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='17',`topic_text`='JBS_TOP_CHURCH',`published`='1',`params`=NULL,`asset_id`='2172',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='18',`topic_text`='JBS_TOP_COMMUNICATION',`published`='1',`params`=NULL,`asset_id`='2173',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='19',`topic_text`='JBS_TOP_COMMUNION___LORDS_SUPPER',`published`='1',`params`=NULL,`asset_id`='2174',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='21',`topic_text`='JBS_TOP_CREATION',`published`='1',`params`=NULL,`asset_id`='2175',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='22',`topic_text`='JBS_TOP_JESUS_CROSS_FINAL_WEEK',`published`='1',`params`=NULL,`asset_id`='2176',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='23',`topic_text`='JBS_TOP_CULTS',`published`='1',`params`=NULL,`asset_id`='2177',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='24',`topic_text`='JBS_TOP_DEATH',`published`='1',`params`=NULL,`asset_id`='2178',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='26',`topic_text`='JBS_TOP_DESCRIPTIONS_OF_GOD',`published`='1',`params`=NULL,`asset_id`='2179',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='27',`topic_text`='JBS_TOP_DISCIPLES',`published`='1',`params`=NULL,`asset_id`='2180',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='28',`topic_text`='JBS_TOP_DISCIPLESHIP',`published`='1',`params`=NULL,`asset_id`='2181',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='29',`topic_text`='JBS_TOP_JESUS_DIVINITY',`published`='1',`params`=NULL,`asset_id`='2182',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='30',`topic_text`='JBS_TOP_DIVORCE',`published`='1',`params`=NULL,`asset_id`='2183',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='32',`topic_text`='JBS_TOP_EASTER_SEASON',`published`='1',`params`=NULL,`asset_id`='2184',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='33',`topic_text`='JBS_TOP_EMOTIONS',`published`='1',`params`=NULL,`asset_id`='2185',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='34',`topic_text`='JBS_TOP_ENTERTAINMENT',`published`='1',`params`=NULL,`asset_id`='2186',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='35',`topic_text`='JBS_TOP_EVANGELISM',`published`='1',`params`=NULL,`asset_id`='2187',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='36',`topic_text`='JBS_TOP_FAITH',`published`='1',`params`=NULL,`asset_id`='2188',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='37',`topic_text`='JBS_TOP_BLENDED_FAMILY_RELATIONSHIPS',`published`='1',`params`=NULL,`asset_id`='2189',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='39',`topic_text`='JBS_TOP_FORGIVING_OTHERS',`published`='1',`params`=NULL,`asset_id`='2190',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='40',`topic_text`='JBS_TOP_GODS_FORGIVENESS',`published`='1',`params`=NULL,`asset_id`='2191',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='41',`topic_text`='JBS_TOP_FRIENDSHIP',`published`='1',`params`=NULL,`asset_id`='2192',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='42',`topic_text`='JBS_TOP_FULFILLMENT_IN_LIFE',`published`='1',`params`=NULL,`asset_id`='2193',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='43',`topic_text`='JBS_TOP_FUND_RAISING_RALLY',`published`='1',`params`=NULL,`asset_id`='2194',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='44',`topic_text`='JBS_TOP_FUNERALS',`published`='1',`params`=NULL,`asset_id`='2195',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='45',`topic_text`='JBS_TOP_GIVING',`published`='1',`params`=NULL,`asset_id`='2196',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='46',`topic_text`='JBS_TOP_GODS_WILL',`published`='1',`params`=NULL,`asset_id`='2197',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='47',`topic_text`='JBS_TOP_HARDSHIP_OF_LIFE',`published`='1',`params`=NULL,`asset_id`='2198',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='48',`topic_text`='JBS_TOP_HOLY_SPIRIT',`published`='1',`params`=NULL,`asset_id`='2199',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='50',`topic_text`='JBS_TOP_JESUS_HUMANITY',`published`='1',`params`=NULL,`asset_id`='2200',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='52',`topic_text`='JBS_TOP_KINGDOM_OF_GOD',`published`='1',`params`=NULL,`asset_id`='2201',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='55',`topic_text`='JBS_TOP_LEADERSHIP_ESSENTIALS',`published`='1',`params`=NULL,`asset_id`='2202',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='56',`topic_text`='JBS_TOP_JESUS_LIFE',`published`='1',`params`=NULL,`asset_id`='2203',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='57',`topic_text`='JBS_TOP_LOVE',`published`='1',`params`=NULL,`asset_id`='2204',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='58',`topic_text`='JBS_TOP_GODS_LOVE',`published`='1',`params`=NULL,`asset_id`='2205',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='59',`topic_text`='JBS_TOP_MARRIAGE',`published`='1',`params`=NULL,`asset_id`='2206',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='61',`topic_text`='JBS_TOP_JESUS_MIRACLES',`published`='1',`params`=NULL,`asset_id`='2207',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='62',`topic_text`='JBS_TOP_MISCONCEPTIONS_OF_CHRISTIANITY',`published`='1',`params`=NULL,`asset_id`='2208',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='63',`topic_text`='JBS_TOP_MONEY',`published`='1',`params`=NULL,`asset_id`='2209',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='65',`topic_text`='JBS_TOP_GODS_NATURE',`published`='1',`params`=NULL,`asset_id`='2210',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='66',`topic_text`='JBS_TOP_OUR_NEED_FOR_GOD',`published`='1',`params`=NULL,`asset_id`='2211',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='69',`topic_text`='JBS_TOP_PARABLES',`published`='1',`params`=NULL,`asset_id`='2212',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='70',`topic_text`='JBS_TOP_PARANORMAL',`published`='1',`params`=NULL,`asset_id`='2213',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='71',`topic_text`='JBS_TOP_PARENTING',`published`='1',`params`=NULL,`asset_id`='2214',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='73',`topic_text`='JBS_TOP_POVERTY',`published`='1',`params`=NULL,`asset_id`='2215',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='74',`topic_text`='JBS_TOP_PRAYER',`published`='1',`params`=NULL,`asset_id`='2216',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='76',`topic_text`='JBS_TOP_PROMINENT_N_T__MEN',`published`='1',`params`=NULL,`asset_id`='2217',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='77',`topic_text`='JBS_TOP_PROMINENT_N_T__WOMEN',`published`='1',`params`=NULL,`asset_id`='2218',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='78',`topic_text`='JBS_TOP_PROMINENT_O_T__MEN',`published`='1',`params`=NULL,`asset_id`='2219',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='79',`topic_text`='JBS_TOP_PROMINENT_O_T__WOMEN',`published`='1',`params`=NULL,`asset_id`='2220',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='82',`topic_text`='JBS_TOP_MESSIANIC_PROPHECIES',`published`='1',`params`=NULL,`asset_id`='2221',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='83',`topic_text`='JBS_TOP_RACISM',`published`='1',`params`=NULL,`asset_id`='2222',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='84',`topic_text`='JBS_TOP_JESUS_RESURRECTION',`published`='1',`params`=NULL,`asset_id`='2223',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='85',`topic_text`='JBS_TOP_SECOND_COMING',`published`='1',`params`=NULL,`asset_id`='2224',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='86',`topic_text`='JBS_TOP_SEXUALITY',`published`='1',`params`=NULL,`asset_id`='2225',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='87',`topic_text`='JBS_TOP_SIN',`published`='1',`params`=NULL,`asset_id`='2226',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='88',`topic_text`='JBS_TOP_SINGLENESS',`published`='1',`params`=NULL,`asset_id`='2227',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='89',`topic_text`='JBS_TOP_SMALL_GROUPS',`published`='1',`params`=NULL,`asset_id`='2228',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='90',`topic_text`='JBS_TOP_SPIRITUAL_DISCIPLINES',`published`='1',`params`=NULL,`asset_id`='2229',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='91',`topic_text`='JBS_TOP_SPIRITUAL_GIFTS',`published`='1',`params`=NULL,`asset_id`='2230',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='92',`topic_text`='JBS_TOP_SUPERNATURAL',`published`='1',`params`=NULL,`asset_id`='2231',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='93',`topic_text`='JBS_TOP_JESUS_TEACHING',`published`='1',`params`=NULL,`asset_id`='2232',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='94',`topic_text`='JBS_TOP_TEMPTATION',`published`='1',`params`=NULL,`asset_id`='2233',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='95',`topic_text`='JBS_TOP_TEN_COMMANDMENTS',`published`='1',`params`=NULL,`asset_id`='2234',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='97',`topic_text`='JBS_TOP_TRUTH',`published`='1',`params`=NULL,`asset_id`='2235',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='98',`topic_text`='JBS_TOP_TWELVE_APOSTLES',`published`='1',`params`=NULL,`asset_id`='2236',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='100',`topic_text`='JBS_TOP_WEDDINGS',`published`='1',`params`=NULL,`asset_id`='2237',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='101',`topic_text`='JBS_TOP_WORKPLACE_ISSUES',`published`='1',`params`=NULL,`asset_id`='2238',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='102',`topic_text`='JBS_TOP_WORLD_RELIGIONS',`published`='1',`params`=NULL,`asset_id`='2239',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='103',`topic_text`='JBS_TOP_FAMILY',`published`='1',`params`=NULL,`asset_id`='2240',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='104',`topic_text`='JBS_TOP_FREEDOM',`published`='1',`params`=NULL,`asset_id`='2241',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='105',`topic_text`='JBS_TOP_STEWARDSHIP',`published`='1',`params`=NULL,`asset_id`='2242',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='106',`topic_text`='JBS_TOP_WORSHIP',`published`='1',`params`=NULL,`asset_id`='2243',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='107',`topic_text`='JBS_TOP_HOLIDAYS',`published`='1',`params`=NULL,`asset_id`='2244',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='108',`topic_text`='JBS_TOP_SPECIAL_SERVICES',`published`='1',`params`=NULL,`asset_id`='2245',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='109',`topic_text`='JBS_TOP_MEN',`published`='1',`params`=NULL,`asset_id`='2246',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='110',`topic_text`='JBS_TOP_WOMEN',`published`='1',`params`=NULL,`asset_id`='2247',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='111',`topic_text`='JBS_TOP_HOT_TOPICS',`published`='1',`params`=NULL,`asset_id`='2248',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='112',`topic_text`='JBS_TOP_NARNIA',`published`='1',`params`=NULL,`asset_id`='2249',`language`='*',`access`='1';
INSERT INTO `#__bsms_topics` SET `id`='113',`topic_text`='JBS_TOP_DA_VINCI_CODE',`published`='1',`params`=NULL,`asset_id`='2250',`language`='*',`access`='1';

-- --------------------------------------------------------

--
-- Table structure for table `#__bsms_update`
--

DROP TABLE IF EXISTS `#__bsms_update`;
CREATE TABLE `#__bsms_update` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;


--
-- Dumping data for table `#__bsms_update`
--

INSERT INTO `#__bsms_update` SET `id`='1',`version`='7.0.0';
INSERT INTO `#__bsms_update` SET `id`='2',`version`='7.0.1';
INSERT INTO `#__bsms_update` SET `id`='3',`version`='7.0.1.1';
INSERT INTO `#__bsms_update` SET `id`='4',`version`='7.0.2';
INSERT INTO `#__bsms_update` SET `id`='5',`version`='7.0.3';
INSERT INTO `#__bsms_update` SET `id`='6',`version`='7.0.4';
INSERT INTO `#__bsms_update` SET `id`='7',`version`='7.1.0';
INSERT INTO `#__bsms_update` SET `id`='8',`version`='7.1.1';
INSERT INTO `#__bsms_update` SET `id`='9',`version`='7.1.2';
INSERT INTO `#__bsms_update` SET `id`='10',`version`='7.1.3';
INSERT INTO `#__bsms_update` SET `id`='11',`version`='8.0.0';
INSERT INTO `#__bsms_update` SET `id`='12',`version`='8.0.1';
INSERT INTO `#__bsms_update` SET `id`='13',`version`='8.0.2';
INSERT INTO `#__bsms_update` SET `id`='14',`version`='8.0.3';
INSERT INTO `#__bsms_update` SET `id`='15',`version`='8.1.0';

-- --------------------------------------------------------

