<?php
/**
 * Controller for Seriesdisplay
 *
 * @package    BibleStudy.Site
 * @copyright  2007 - 2019 (C) CWM Team All rights reserved
 * @license    http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link       https://www.christianwebministries.org
 * */
// No Direct Access
defined('_JEXEC') or die;

/**
 * Controller for Seriesdisplay
 *
 * @package  BibleStudy.Site
 * @since    7.0.0
 */
class BiblestudyControllerSeriesdisplay extends JControllerLegacy
{
	// Holder.
}
