<?php
/**
 * Part of Proclaim Package
 *
 * @package    Proclaim.Admin
 * @copyright  2007 - 2018 (C) CWM Team All rights reserved
 * @license    http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link       https://www.christianwebministries.org
 * */
// No Direct Access
defined('_JEXEC') or die;

/**
 * Controller for the cPanel
 *
 * @package  Proclaim.Admin
 * @since    7.0.0
 */
class BiblestudyControllerCpanel extends JControllerForm
{
	// Holder for new controllers.
}
