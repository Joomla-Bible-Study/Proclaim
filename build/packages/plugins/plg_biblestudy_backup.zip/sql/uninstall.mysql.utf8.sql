DROP TABLE IF EXISTS `#__jbsbackup_timeset`;
DROP TABLE IF EXISTS `#__jbsbackup_update`;