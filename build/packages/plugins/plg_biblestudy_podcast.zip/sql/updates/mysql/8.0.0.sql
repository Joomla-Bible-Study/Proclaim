INSERT INTO `#__jbspodcast_update` (id,version) VALUES (7,'8.0.0')
ON DUPLICATE KEY UPDATE version= '8.0.0';
