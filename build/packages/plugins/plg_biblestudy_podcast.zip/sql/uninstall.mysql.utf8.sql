DROP TABLE IF EXISTS `#__jbspodcast_update`;
DROP TABLE IF EXISTS `#__jbspodcast_timeset`;