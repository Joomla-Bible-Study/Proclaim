<?php

/**
 * JBSMigration Holder File
 *
 * @package    BibleStudy
 * @subpackage JBSMigration.Site
 * @copyright  (C) 2007 - 2011 Joomla Bible Study Team All rights reserved
 * @license    http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link       http://www.JoomlaBibleStudy.org
 * */
defined('_JEXEC') or die();

JError::raiseError(404, JText::_('COMPONENT NOT FOUND'));