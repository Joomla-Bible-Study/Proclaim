<?php

/**
 * Helper for Template Code
 *
 * @package    BibleStudy.Admin
 * @copyright  (C) 2007 - 2013 Joomla Bible Study Team All rights reserved
 * @license    http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link       http://www.JoomlaBibleStudy.org
 * */
// No Direct Access
defined('_JEXEC') or die;

// Do not remove
foreach ($list as $study)
    {
      
      ?>
<div class="row-fluid span12" >
 
  <div class="span12">
    <a href="<?php echo $study->detailslink;?>"><strong><?php echo $study->studytitle;?></strong></a>
  
  </div>
 <div class="span10">
    <p style="color:black; font-family: arial;">
      <?php echo $study->studyintro;?>
    </p>
  </div>
  <div class="span10" style="color:black; font-family: arial;">
    <strong><?php echo $study->scripture1;?></strong><?php if ($study->series_text){ ?> - As part of our series: "<?php echo $study->series_text;?>"<?php } ?> with <?php echo $study->teachertitle.' '.$study->teachername;?>.
  </div>
</div>
   <?php }?>