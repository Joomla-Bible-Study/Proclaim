<?php

/**
 * Helper for mod_biblestudy.php
 *
 * @package         BibleStudy
 * @subpackage      Model.BibleStudy
 * @copyright   (C) 2007 - 2012 Joomla Bible Study Team All rights reserved
 * @license         http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link            http://www.JoomlaBibleStudy.org
 * */
defined('_JEXEC') or die;

/**
 * BibleStudy mod helper
 *
 * @package     BibleStudy
 * @subpackage  Model.BibleStudy
 * @since       7.1.0
 */
class ModJBSMHelper
{
}
