<?php

/**
 * Helper for Template Code
 *
 * * @package    BibleStudy.Admin
 * $author		Tom Fuller www.ChristianWebMinistries.org
 * @copyright  (C) 2007 - 2017 Christian Web Ministries Team All rights reserved
 * @license    http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link       http://www.ChristianWebMinistries.org
 * */
// No Direct Access
defined('_JEXEC') or die;

// Do not remove ?>
<table class="table">
  <thead>
    <tr>
      <th>Title</th>
      <th>Teacher</th>
      <th>Media</th>
    </tr>
  </thead>
  <tbody>
    <?php 
 foreach ($list as $study)
    {
      ?>
  <tr><td>   
    <a href="<?php echo $study->detailslink;?>"><strong><?php echo $study->studytitle;?></strong></a>
   </td>
  <td><?php echo $study->teachername; ?></td>
    <td><?php echo $study->media; ?></td>
    </tr>
   <?php }?>
  </tbody>
</table>

  <?php echo $link;?>