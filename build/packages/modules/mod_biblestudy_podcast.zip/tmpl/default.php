<?php
/**
 * Podcast Model default
 *
 * @package     BibleStudy
 * @subpackage  Model.Podcast
 * @copyright   2007 - 2016 (C) Joomla Bible Study Team All rights reserved
 * @license     http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link        http://www.JoomlaBibleStudy.org
 */
// No direct access
defined('_JEXEC') or die;
echo $subscribe;
