<?php
/**
 * Podcast Model default
 *
 * @package     Proclaim
 * @subpackage  Model.Podcast
 * @copyright   2007 - 2019 (C) CWM Team All rights reserved
 * @license     http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link        https://www.joomlabiblestudy.org
 */
// No direct access
defined('_JEXEC') or die;
echo $subscribe;
