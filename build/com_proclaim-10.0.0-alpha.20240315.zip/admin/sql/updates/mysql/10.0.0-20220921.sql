alter table `#__bsms_podcast`
    modify podcast_image_subscribe varchar(255) null;
alter table `#__bsms_podcast`
    modify podcastimage varchar(255) null;
alter table `#__bsms_podcast`
    modify image VARCHAR(255) null;
alter table `#__bsms_series`
    modify series_thumbnail VARCHAR(255) null;