# Security Policy

## Supported Versions

| Version | Supported                        |
|---------|----------------------------------|
| 10.x.x  | &check;                          |
| 9.x.x   | &check;                          |

## Reporting a Vulnerability

Info coming soon.
