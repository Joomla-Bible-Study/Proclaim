# Security Policy

## Supported Versions

| Version | Supported                        |
|---------|----------------------------------|
| 10.x.x  | &check;                          |
| 9.x.x   | &check;                          |
| < 7     | <span style="color:red">x</span> |

## Reporting a Vulnerability

Info coming soon.
