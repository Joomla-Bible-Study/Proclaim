INSERT INTO `#__jbspodcast_update` (id,version) VALUES (3,'7.0.2')
ON DUPLICATE KEY UPDATE version= '7.0.2';