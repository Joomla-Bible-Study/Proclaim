-- 7.0.1.1
UPDATE `#__bsms_update` SET  `version` =  '7.0.1.1' WHERE  `#__bsms_update`.`id` =3;