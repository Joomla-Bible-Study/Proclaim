-- 7.0.1
INSERT INTO #__bsms_update (id,version) VALUES (2, '7.0.1');