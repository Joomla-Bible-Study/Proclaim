DROP TABLE IF EXISTS #__bsms_install;
DROP TABLE IF EXISTS #__bsms_update;