<?php

//required on each page
defined('_JEXEC') or die;
//Do not remove

