<?php

/*
 * Default template code
 * Do not remove the line below. It is required for all Joomla based files. 
 * You will break your site security if you delete it. 
 * place a <?php before php code and then a ? followed by a > when you want to go back to html
 * See the Help link above for codes you can use for each view type
 * if you want to show something that is one item like a teacher view, type it like: echo $this->item->teachername. If you want to act
 * on a list like a studies list type something like: foreach ($this->teacherstudies as $study){echo $study->studydate;}
 * Remember the brackets and ; at the end of each line of code of you will get errors.
 */
//required on each page
defined('_JEXEC') or die;
//Do not remove

