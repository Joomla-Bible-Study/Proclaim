<?php

/**
 * Podcast Model default
 * @package BibleStudy
 * @subpackage Model.Podcast
 * @author Joomla Bible Study Team
 * @copyright 2012
 * @desc a module to display the podcast subscription table
 */
// no direct access
defined('_JEXEC') or die;
echo $subscribe;
